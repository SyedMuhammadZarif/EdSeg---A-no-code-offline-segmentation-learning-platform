# EdSeg — Stage 12: Packaging into a One-Click Desktop App

Turns EdSeg from "run `python backend/app.py` and open a browser" into
an actual double-click desktop application — a single `.exe` on Windows,
a `.app`/`.dmg` on Mac — using `pywebview` (native window) and
`PyInstaller` (bundling).

## An important, honest limitation of this stage

PyInstaller **cannot cross-compile**: it can only build an executable for
the operating system it's actually running on. I (Claude) only have
access to a Linux sandbox for this project — no Windows or Mac machine.
So the real `.exe` and `.app` **must be built by you**, on those actual
platforms, using the instructions in `BUILD_INSTRUCTIONS.md`. I can't
produce or personally test those files myself, and I want to be upfront
about that rather than imply otherwise.

What I *could* do, and did, from this Linux sandbox:

## What was built and genuinely verified here

- **`launcher.py`** — starts the Flask backend in a background thread,
  waits for it to respond, then opens a native OS window via `pywebview`
  pointing at it. Tested for real: installed the WebKit2GTK system
  libraries this sandbox was missing, ran the launcher under a virtual
  display (Xvfb), and captured an actual screenshot of the real EdSeg
  app running in a genuine native window — no browser chrome, sidebar and
  right-panel info cards rendering correctly, with the log confirming all
  the expected API calls fired on load.
- **A critical bug found and fixed before it could ever ship:** every
  backend module that saves data (checkpoints, saved models, reports,
  custom datasets) was computing its save location relative to its own
  source file. That's fine running from source, but PyInstaller's
  "onefile" mode actually runs the app from a **temporary folder deleted
  when the app closes** — meaning, unfixed, students would have silently
  lost every trained model the moment they closed the app. Fixed with a
  new `backend/paths.py` that separates read-only bundled resources
  (safe to load from the temp folder) from persistent user data (must be
  written next to the actual `.exe`/`.app`, which does persist). Updated
  `app.py`, `dataset_utils.py`, `train.py`, `model_library.py`, and
  `results.py` accordingly, then reran the entire backend regression
  suite to confirm nothing broke.
- **Proved the PyInstaller bundling mechanics work end-to-end**, with an
  honest caveat: this sandbox has a hard per-command time limit, and
  background processes don't reliably survive between tool calls here —
  together these make a multi-minute build bundling all of PyTorch
  (1.2GB+) impractical to complete in this environment. Rather than skip
  verification, I built a lightweight proof-of-concept using the *exact
  same* pattern (Flask-in-thread + pywebview + PyInstaller `--add-data`
  bundling), producing a real 44MB standalone Linux executable, ran it,
  and screenshotted it working — genuinely confirming the bundling,
  data-file extraction, and window-opening mechanics are sound before
  asking you to spend several minutes building the full version yourself.
- **`launcher.spec`** — the real PyInstaller build config for the full
  app, referencing the path-fixed backend, using `SPECPATH` (not
  `os.getcwd()`) so the build works regardless of which directory the
  `pyinstaller` command is run from.
- **`BUILD_INSTRUCTIONS.md`** — exact steps to build the real `.exe` and
  `.app`, including the CPU-only PyTorch install command (to keep the
  final app size down, since students' laptops aren't expected to have a
  CUDA GPU), expected build time, first-run SmartScreen/Gatekeeper
  guidance, and a testing checklist.

## How to build and test the real thing

Full details are in `BUILD_INSTRUCTIONS.md`. Short version:

```
python -m venv build_venv
# Windows: build_venv\Scripts\activate    Mac: source build_venv/bin/activate
pip install Flask Pillow numpy pywebview pyinstaller
pip install torch --index-url https://download.pytorch.org/whl/cpu
pyinstaller launcher.spec --noconfirm
```

The built app appears at `dist/EdSeg.exe` (Windows) or `dist/EdSeg.app`
(Mac). This will take several minutes — that's normal for bundling
PyTorch, not a sign of a problem.

## Acceptance check for this stage

- [ ] `pyinstaller launcher.spec --noconfirm` completes successfully on
      a real Windows machine, producing `dist/EdSeg.exe`
- [ ] The same completes on a real Mac, producing `dist/EdSeg.app`
- [ ] On each platform, double-clicking the built app opens a window with
      no visible terminal or browser chrome
- [ ] The full workflow works identically to the dev version: dataset →
      train → checkpoint → resume → results → save/load a model → test
      on a new image → compare runs
- [ ] After training, a `checkpoints/` folder appears **next to** the
      app file (not vanishing when the app closes) — confirms the
      persistent-data-path fix is working correctly in the packaged build
- [ ] Closing and reopening the app: previously saved models are still there

If all of these are true on both platforms, Stage 12 is complete and we
move to Stage 13 (hardware baseline validation) and Stage 14
(documentation & handover) — the final two stages in the production plan.

## Project structure so far

```
seglearn/
├── launcher.py                       # NEW — desktop entry point (Flask + pywebview)
├── launcher.spec                     # NEW — PyInstaller build config
├── BUILD_INSTRUCTIONS.md             # NEW — how to build the real .exe / .app
├── backend/
│   ├── paths.py                      # NEW — source vs. frozen path resolution
│   ├── app.py                        # UPDATED — uses paths.py for FRONTEND_DIR
│   ├── dataset_utils.py              # UPDATED — bundled vs. custom dataset roots split
│   ├── train.py                      # UPDATED — CHECKPOINTS_ROOT uses persistent path
│   ├── model_library.py              # UPDATED — MODELS_ROOT uses persistent path
│   ├── results.py                    # UPDATED — REPORTS_ROOT uses persistent path
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── job_manager.py
│   ├── tuning.py
│   ├── inference.py
│   └── scripts/  (all Stage 1-9 test scripts, unchanged)
├── frontend/
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── reports/
├── requirements.txt                  # UPDATED — adds pywebview, pyinstaller, CPU-torch note
└── README.md
```



# EdSeg (formerly "SegLearn")

The project was renamed from **SegLearn** to **EdSeg** at the user's
request, alongside the visual overhaul below. The rename is reflected
throughout the actual app (page title, header branding, sidebar footer).
The stage-by-stage history further down this README still refers to
"SegLearn" in places, since that was the project's name at the time each
stage was built — left as an accurate historical record rather than
rewritten, the same way a real changelog wouldn't retroactively edit past
entries. Wherever this README says "SegLearn," read it as "EdSeg."

---

# EdSeg — Rename, Light/Dark Theme, and Results Metric Definitions

Three follow-up changes requested after the visual overhaul above.

## 1. Renamed to EdSeg

Updated everywhere the name is user-visible: the browser tab title, the
topbar logo ("Ed" + gradient "Seg"), and the sidebar footer branding.

## 2. Light/dark theme toggle

A sun/moon button in the topbar switches between the dark theme (default)
and a new light theme. Implemented entirely with CSS custom properties —
the light theme overrides the same variables (`--bg`, `--surface`,
`--text`, etc.) under a `[data-theme="light"]` selector, so every
component that was already using those variables adapts automatically
with no per-component changes needed. The choice is saved to
`localStorage` and restored on next launch, so it persists across
sessions. (This uses `localStorage` deliberately — that's a real, standard
browser API appropriate for a real local desktop app; it's unrelated to
the "no localStorage" restriction that applies specifically to Claude.ai's
sandboxed Artifacts preview, which this app is not.)

## 3. Written metric definitions on the Results screen

Previously, what Precision/Recall/Dice/IoU/Accuracy actually mean was
only explained in a single dense paragraph under the bar chart, and
students had to go find those explanations separately from the numbers
in the summary cards above. Added a clear, one-line-each definition list
directly under the Results summary cards — Train loss, Val loss,
Precision, Recall, Dice, IoU, and Accuracy — so the meaning sits right
next to the numbers themselves rather than requiring a trip elsewhere.

## How I verified these changes

Given the flaky background-process behavior I'd been hitting in this
sandbox, I made sure to actually get a clean run this time: started the
server and ran a single combined Playwright script (server start and
test in the same command, with a longer startup delay to account for
Flask's debug-mode reloader restart) that confirmed the page title and
all branding read "EdSeg," toggled the theme and confirmed the
`data-theme` attribute actually changed, **reloaded the page and
confirmed the theme persisted** (proving the localStorage save/restore
actually works, not just the toggle itself), then trained a model and
confirmed all 7 metric definition terms render correctly on the Results
screen. I also screenshotted both the dark and light themes to visually
confirm legibility and correct icon states (sun showing in dark mode,
moon showing in light mode) rather than just checking for the absence of
errors. Zero browser console errors throughout, and the full backend
regression suite (Stages 3, 4, 5, 8, 9) still passes unchanged, since
none of this touched the backend.

## Acceptance check

- [ ] Browser tab title and all on-screen branding read "EdSeg"
- [ ] Clicking the sun/moon button switches between dark and light themes
- [ ] The chosen theme persists after closing and reopening the app
- [ ] Both themes are fully legible (text, cards, badges, charts)
- [ ] The Results screen shows a clear one-line definition for each of:
      Train loss, Val loss, Precision, Recall, Dice, IoU, Accuracy
- [ ] No errors in the browser console

If all of these are true, we're ready for Stage 12 (packaging into a
one-click desktop app).



# SegLearn — Visual Overhaul (Dark App-Shell Theme)

Complete visual redesign, done between Stage 11 and Stage 12 at the
user's request, based on a reference screenshot showing a dark,
dashboard-style layout. No functional/backend changes — this is purely
a frontend restyle and restructure, with all existing screen logic and
IDs preserved.

## Design approach

Following the reference direction closely (per the frontend-design
guidance: "where the brief pins down a visual direction, follow it
exactly"):
- **Color:** near-black navy base (`#0b0e14`), card surfaces (`#131822`),
  a blue→violet brand gradient (`#5b8def → #8b5cf6`) used for the logo,
  active states, and primary buttons, plus green/red/amber status colors
- **Type:** system font stack only — no web fonts, since the app must
  run fully offline after install and can't depend on a font CDN
- **Layout:** app shell — topbar (logo, live backend status), left
  sidebar (grouped navigation: Main Workflow / Advanced / Learn), main
  content (all existing screens, restyled in place), right sidebar with
  **live** info cards (Quick Status, Dataset Info, Supported
  Architectures, Compute Devices) that show real data, not placeholders
- **Icons:** a small set of hand-authored inline SVG icons (stroke-based,
  minimal), so there's zero external icon-font/CDN dependency

## What changed

- `style.css` — complete rewrite around the dark theme and app-shell layout
- `index.html` — restructured into topbar + sidebar-left + main-content +
  sidebar-right; all existing `<section id="step-...">` screens moved
  inside `main-content` unchanged in content, just restyled
- `script.js` — added an `ICONS` object + `renderIcons()`, sidebar
  navigation wiring (`handleSidebarNav()`, `setActiveNavItem()`), and
  right-panel population hooked into existing data flows (backend ping,
  dataset preview, architecture list, device detection) — no new API
  calls were needed, since Stage 5/6 already fetched all of this data

The sidebar lets you jump directly to any screen at any time (not just
move linearly through the wizard), with sensible guards — e.g. clicking
"Model Setup" before a dataset is selected prompts you to pick one first
rather than showing a broken/empty screen.

## Two real bugs found and fixed during this pass

1. **Pre-existing bug in `hideAllSections()`:** `step-compare` (the
   Compare Runs screen from Stage 11) had never been added to the list of
   sections that get hidden when navigating elsewhere. In practice this
   meant navigating away from Compare Runs wouldn't actually hide it —
   caught this while wiring up sidebar navigation and fixed it by adding
   it to the list.
2. **Icon sizing bug introduced during the redesign itself:** the
   `.nav-icon` sizing rule was only defined scoped under `.nav-item`, so
   an icon used outside a nav item (the flask icon on the "Run a
   hyperparameter sweep instead" button) rendered at the browser's
   default unconstrained SVG size — a huge, broken-looking icon filling
   most of the button. Caught this by actually screenshotting the page
   and reviewing it, not just checking for console errors. Fixed by
   adding a global `.nav-icon` sizing rule alongside the more specific one.

## How I verified this

Since I can't visually inspect a running browser myself, I used a real
headless-browser (Playwright) workflow specifically built around
screenshots: launched the app, navigated through Dataset, Preview,
Model Setup, the Concepts modal, Training, and Results, and saved a
screenshot at each step to actually look at rather than just checking
for the absence of thrown errors. This is how both bugs above were
caught — neither produced a JavaScript error, so a console-error check
alone would have missed them; only looking at the rendered result
surfaced them.

After fixing both, I re-screenshotted the affected areas to confirm the
fixes, then ran the full functional regression: every backend test
script (Stages 5, 8, 9) still passes unchanged, and a comprehensive
Playwright pass exercised the entire flow through the new sidebar
navigation — train a model, save it, jump via sidebar to Model Library,
to Compare Runs, back to Dataset (specifically re-checking the
`step-compare` visibility fix), to Model Setup, and to Concepts — with
the sidebar's active-item highlight staying correctly in sync at every
step, and zero browser console errors throughout.

## Acceptance check for this pass

- [ ] The app opens to a dark, sidebar-navigated layout matching the
      general direction of the reference screenshot
- [ ] The right sidebar's Dataset Info, Supported Architectures, and
      Compute Devices cards show real, accurate data (not placeholders)
- [ ] Every icon renders at a consistent, correctly-sized appearance
      (check the "Run a hyperparameter sweep instead" button specifically)
- [ ] Clicking sidebar nav items jumps directly to that screen, with the
      correct item highlighted as active
- [ ] Navigating away from Compare Runs actually hides it (doesn't leave
      it visible underneath the next screen)
- [ ] All prior functionality (training, resume, tuning, results,
      model library, inference, compare) still works exactly as before
- [ ] No errors in the browser console

If all of these are true, we're ready to move to Stage 12 (packaging
into a one-click desktop app).



# SegLearn — Stage 11: Educational Layer

Adds the pedagogical scaffolding on top of the now fully-functional app:
plain-language explanations next to every control, a browsable "Concepts"
glossary, and a Compare Runs screen for viewing two completed runs side
by side. No backend changes this stage — purely frontend.

## What was added

- **Tooltips on every control:** audited every screen and added a short
  plain-language hint under any control that didn't already have one —
  the dataset selector, model architecture dropdown, every compute-device
  picker (4 occurrences), the training/results charts (explaining what
  loss/Dice/IoU/confusion-matrix terms mean), the tuning parameter
  toggles, and the testing screen's file inputs. Combined with hints
  already present since Stage 6, every single interactive control now has
  an explanation of what it does and why it matters.
- **Concepts panel** (📚 "Learn the concepts" button on the start screen):
  a modal with 14 expandable topics — deep learning, segmentation, loss
  function, learning rate, epoch, batch size, overfitting, validation
  split, Dice score, IoU, confusion matrix, CPU vs GPU, checkpoints, and
  hyperparameter tuning — written for someone with no ML background,
  reusing language consistent with the inline hints so terms don't
  contradict each other across the app.
- **Compare Runs screen** (⚖ "Compare two runs" from the start screen):
  pick any two saved checkpoints and see them side by side — summary
  cards for each, both runs' loss curves plotted together on the same
  axes, and a grouped bar chart (Precision/Recall/Dice/IoU/Accuracy)
  with both runs on a **fixed 0–1 scale** so bar heights are always
  directly comparable regardless of which two runs you pick.

## How I verified this stage

A real headless-browser (Playwright) test opened the Concepts modal,
confirmed all 14 entries render and expand/collapse on click, and closes
correctly. For Compare Runs: trained two runs with deliberately different
learning rates, opened the comparison screen, and — important detail — my
first test run accidentally selected two checkpoints from the *same* run
(epoch 5 and 6) rather than two different runs, because checkpoints are
listed grouped by run. I caught this by checking the actual run IDs
returned, corrected the test to properly select two distinct runs, and
confirmed: both labels showed genuinely different run IDs, both summary
panels showed different (correct) metrics, and both charts rendered with
real, non-blank pixel data. I also tested the guard that rejects comparing
a checkpoint against itself. Zero browser console errors throughout.

## How to try it yourself

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/app.py
```

Click **"📚 Learn the concepts"** on the start screen to browse the
glossary. Train two models with different settings (e.g. different
learning rates), then click **"⚖ Compare two runs"** and pick two
different checkpoints to see them side by side.

## Acceptance check for this stage

- [ ] Every slider, dropdown, and device picker across every screen has
      a plain-language explanation visible nearby
- [ ] The Concepts panel opens, all entries expand/collapse correctly,
      and the explanations are accurate and readable without an ML background
- [ ] Comparing two different runs shows correct, distinct data for each
      (not the same run twice)
- [ ] Both comparison charts render with real data on matching scales
- [ ] Attempting to compare a checkpoint against itself is rejected clearly
- [ ] No errors in the browser console

If all of these are true, Stage 11 is complete and we move to Stage 12
(packaging into an actual one-click desktop app — `pywebview` +
`PyInstaller` — for Windows and Mac).

## Project structure so far

```
seglearn/
├── backend/                          (unchanged this stage)
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py
│   ├── tuning.py
│   ├── model_library.py
│   ├── inference.py
│   ├── results.py
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       ├── test_api.py
│       ├── test_results.py
│       └── test_tuning.py
├── frontend/
│   ├── index.html                    # UPDATED — tooltips everywhere, Concepts modal, Compare screen
│   ├── style.css                     # UPDATED — modal + comparison-column styles
│   └── script.js                     # UPDATED — concepts accordion + comparison logic
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── reports/
├── requirements.txt
└── README.md
```

# SegLearn — Stage 10: Model Library & Testing/Inference Screen

Completes the core workflow: save a trained model permanently, browse all
saved models, load any of them, and run them on a brand-new image — with
Dice/IoU computed automatically if you also provide the correct answer
(a ground-truth mask) for comparison.

## A gap I found and fixed while starting this stage

Before building the library/testing screens, I checked how a model
actually gets saved in the first place — and found that "Save as Model"
only existed on individual trials in the Hyperparameter Tuning results
screen (Stage 9). A student training normally (not via tuning) had no way
to save their model at all, which would make the whole "load any saved
model" premise of this stage pointless for the most common workflow. Fixed
by adding a **"Save as Model"** section directly to the Stage 8 Results
screen, using the same `/api/model/save` endpoint that tuning already used.

## What was added

- **Results screen:** a new "Save this model" section — name it, click
  Save, and it's permanently stored in `/models/`, independent of the
  training checkpoint that created it
- **Model Library screen** (`🗂 Test a saved model` from the start
  screen): lists every saved model with its architecture, source dataset,
  epochs trained, and final validation Dice/IoU
- **Testing/Inference screen:** pick an image file (and optionally a
  ground-truth mask), choose a compute device, click **Run Inference**,
  and see the input image, predicted mask, and — if a mask was
  provided — the ground truth alongside it plus computed Dice/IoU for
  that specific image. If no mask is provided, it still runs and shows
  just the prediction (no error, no fake metrics)

The backend for this (`model_library.py`, `inference.py`, and the
`/api/models`, `/api/model/save`, `/api/inference` endpoints) was already
built in Stage 5 — this stage is primarily the frontend that finally
exposes it.

## How I verified this stage

A real headless-browser (Playwright) test walked through the complete
flow: confirmed the Model Library correctly shows an empty state before
any model is saved, trained a model, saved it by name from the Results
screen, confirmed it appears correctly in the library with accurate
metadata, opened the Testing screen, ran inference with a real sample
image **and** its correct mask (confirmed Dice=0.6475/IoU=0.4787 were
computed and displayed, plus all three images — input, ground truth,
prediction), then ran it again **without** a mask and confirmed it still
works correctly, showing just the input and prediction with no fabricated
metrics. Zero browser console errors throughout.

## How to try it yourself

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/app.py
```

Train a model (Stage 6), open **View Full Results**, give it a name under
"Save this model" and click **Save as Model**. Then from the start screen,
click **"🗂 Test a saved model"**, select your model, upload any image
(try one of the sample images from `datasets/sample_shapes/images/`, and
optionally its matching file from `datasets/sample_shapes/masks/` as the
ground truth), and click **Run Inference**.

## Acceptance check for this stage

- [ ] Before saving any model, the Model Library shows a clear empty-state message
- [ ] "Save as Model" on the Results screen works and the model appears
      in the library afterward with correct metadata
- [ ] Running inference with an image + matching ground-truth mask shows
      all three images and computes Dice/IoU
- [ ] Running inference with just an image (no mask) still works, showing
      only the input and prediction, no errors
- [ ] The predicted mask looks like a reasonable segmentation of the input
      image, not blank or broken
- [ ] No errors in the browser console

If all of these are true, Stage 10 is complete — this was the last of the
core functional stages. Remaining stages (11-14) are the educational
polish layer, packaging into a one-click desktop app, hardware validation,
and final documentation.

## Project structure so far

```
seglearn/
├── backend/                          (unchanged this stage — already built in Stage 5)
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py
│   ├── tuning.py
│   ├── model_library.py
│   ├── inference.py
│   ├── results.py
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       ├── test_api.py
│       ├── test_results.py
│       └── test_tuning.py
├── frontend/
│   ├── index.html                    # UPDATED — Model Library + Testing screens, Save-Model on Results
│   ├── style.css
│   └── script.js                     # UPDATED — model library, inference, save-model logic
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/                            # saved models land here
├── checkpoints/
├── reports/
├── requirements.txt
└── README.md
```

# SegLearn — Stage 9: Hyperparameter Tuning Mode (with Grid Search)

Adds an automated hyperparameter sweep, upgraded to support tuning
**multiple parameters at once**: pick one or more of learning rate, batch
size, dataset subset size, and model architecture, choose several values
for each, and the app trains a short run for **every combination** —
a proper grid search — then shows them all side by side.

## Grid search: what changed from the original single-parameter version

The initial version of this stage only let you sweep one parameter at a
time. This was upgraded to let you select **up to 3 parameters together**,
each with its own set of values (up to 4 each), running every combination
sequentially — e.g. 2 learning rates × 2 batch sizes = 4 trials; 3
learning rates × 2 batch sizes × 2 subset sizes = 12 requested, clamped
down to the cap.

**New/adjusted hard caps** (since combinations multiply fast, this is the
main risk with grid search specifically):
- **Up to 3 parameters** can be swept together
- **Up to 4 values** per parameter
- **Up to 9 total trials** regardless of how many parameters/values are
  requested — combinations beyond this are silently dropped rather than
  producing a runaway job
- **Up to 15 epochs per trial** (unchanged from the original version)

## What was added/changed

- `backend/tuning.py` — rewritten around `compute_grid_combinations()`,
  which takes a list of `{"param": ..., "values": [...]}` entries and
  returns the full Cartesian product (plus info on what got clamped).
  This is exposed as its own function specifically so the combination
  math can be unit-tested in isolation from the training logic.
- `job_manager.py` / API — `POST /api/tuning/start` now accepts
  `sweep_params` (a list) instead of a single `sweep_param`/`sweep_values`
  pair; each trial's status now reports a `sweep_values` **dict** (e.g.
  `{"learning_rate": 0.001, "batch_size": 4}`) instead of one bare value.
- **Frontend Tuning Setup screen** — redesigned to let you toggle on
  multiple parameters (respecting the 3-parameter cap), with a separate
  value-picker block appearing for each one you select, and a live
  "Grid search: 2 × 2 = 4 trials total" readout that updates as you
  change your selections.
- **Tuning Results screen** — each trial card now shows all of its swept
  values together (e.g. "learning_rate=0.001, batch_size=4 — Done"), and
  the comparison bar chart labels combine all swept values per trial.

## A bug I found and fixed while building this

While testing the new multi-parameter UI, I noticed only the *first*
value of each parameter was getting pre-selected by default instead of
the intended first two. The cause: the pre-selection check compared the
selection set's size to zero *inside* the loop that was also adding to
that same set — so after the first value was added, the set was no longer
empty, and the check failed for the second value. Fixed by snapshotting
"was this parameter's selection empty when we started rendering it"
*before* the loop runs, rather than re-checking a value that the loop
itself was mutating. Verified via a real browser test that both parameters
now correctly pre-select 2 values each (confirmed a real 2×2=4 grid run
afterward, with all 4 trials showing the correct, distinct combinations).

## How I verified this stage

Backend: an independent script checks the Cartesian product math against
a hand-computed expected result for a known 2×2 input (exact match
required, not just "close enough"), runs a real 2×2 grid sweep and
confirms all 4 trials have distinct run IDs, existing checkpoint files,
and the correct parameter combination actually applied to each; separately
verifies the parameter-count cap, the total-trial-count cap, the
per-trial epoch cap, and that stopping a sweep partway through actually
stops it — 7 checks in total, all passing.

Frontend: a real headless-browser (Playwright) test selected two
parameters, confirmed both got a value-picker block, confirmed the live
trial-count readout was correct, confirmed attempting a 4th parameter was
correctly blocked by the cap, ran an actual 2×2 sweep end to end, and
confirmed all 4 resulting trial cards showed the correct, distinct
combinations of both swept parameters. Zero browser console errors.

## How to run the verification yourself

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_tuning.py
```

## What you should see

A hand-verified Cartesian product check, a real 2×2 grid sweep with 4
individually-inspectable trials, and cap-clamping checks for parameter
count, total trials, and epochs — ending in `ALL CHECKS PASSED`.

In the app: on the Model & Hyperparameters screen, click **"⚙ Run a
hyperparameter sweep instead"**, toggle on two or more parameters (e.g.
Learning rate and Batch size), pick a few values for each, and watch the
live "N × M = total trials" readout before starting.

## Acceptance check for this stage

- [ ] `test_tuning.py` passes all 7 checks, ending in `ALL CHECKS PASSED`
- [ ] Selecting 2 parameters in the app shows a separate value-picker for each
- [ ] The trial-count readout correctly shows the multiplied total (e.g. "2 × 2 = 4")
- [ ] Trying to select a 4th parameter is blocked (cap is 3)
- [ ] Running a 2-parameter sweep produces trials with every combination,
      each individually inspectable via "View Full Results"
- [ ] No errors in the browser console

If all of these are true, Stage 9 is complete and we move to Stage 10
(the Testing/Inference screen).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py                        # tuning endpoints updated for sweep_params
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py                # tuning job tracking updated for grid trials
│   ├── tuning.py                     # UPDATED — full grid search + tighter caps
│   ├── model_library.py
│   ├── inference.py
│   ├── results.py
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       ├── test_api.py
│       ├── test_results.py
│       └── test_tuning.py            # UPDATED — verifies grid math + caps + runtime
├── frontend/
│   ├── index.html                    # UPDATED — multi-parameter tuning setup UI
│   ├── style.css                     # UPDATED — per-parameter value blocks
│   └── script.js                     # UPDATED — grid search selection + display logic
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── reports/
├── requirements.txt
└── README.md
```

# SegLearn — Stage 8: Results Screen

Adds a full post-training Results screen: a metrics summary, a pixel-level
confusion matrix computed over the entire validation set, a bar chart
comparing Precision/Recall/Dice/IoU/Accuracy, side-by-side predicted vs.
ground-truth sample images, and the ability to save a JSON report to disk.

## What was added

- `backend/results.py`:
  - `compute_confusion_matrix()` — re-evaluates the model fresh from its
    saved weights over the **entire** validation set (not just one batch)
    and accumulates true/false positive/negative pixel counts, plus
    derived precision/recall/dice/iou/accuracy computed directly from
    those totals
  - `get_sample_predictions()` — a handful of (image, ground truth,
    prediction) triples for the side-by-side comparison view
  - `save_report()` — writes a JSON file (config + full metrics history +
    confusion matrix) to `/reports/`
- New API endpoints:
  - `GET /api/results?checkpoint_path=...` — everything the Results
    screen needs in one call
  - `POST /api/results/save_report` — saves a report file, returns its filename
  - `GET /api/reports/<filename>` — downloads a saved report
- **Frontend:** a new Results screen, reachable via a "View Full Results"
  button that appears once training finishes:
  - Summary cards (final train/val loss, overall Dice/IoU, precision, recall)
  - A confusion matrix rendered as a color-coded 2×2 table (TP/TN/FP/FN)
    with total pixel count and overall accuracy
  - A bar chart (hand-drawn on `<canvas>`, same offline-friendly approach
    as Stage 6's line charts) comparing the five key metrics side by side
  - A grid of sample validation images showing input / ground truth /
    predicted mask together
  - A "Save Report" button that saves the JSON file and shows a working
    download link

## How I verified the confusion matrix is actually correct

This is the part worth being careful about, so here's exactly what I did:
I wrote a **second, completely independent implementation** of the
confusion-matrix computation from scratch — different code, different
approach, in the test script itself rather than reusing `results.py`'s
logic — and ran it against the exact same trained model and validation
set. The two independently-written versions produced **bit-for-bit
identical** true/false positive/negative counts. I also checked that
`tp + tn + fp + fn` exactly equals the real total pixel count of the
validation set (catches any batch-aggregation bugs), and hand-verified
the precision/recall/dice/iou/accuracy formulas against the raw totals.
Finally, I confirmed the saved JSON report's numbers match **exactly**
what was computed live — no drift between what you see on screen and
what gets saved to disk.

On top of that, I used a real headless-browser (Playwright) test to click
through the whole flow: train a model, open Results, confirm the summary
cards/confusion matrix/bar chart/sample images all render with real data,
save a report, and follow the download link — all with zero browser
console errors.

## How to run the verification yourself

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_results.py
```

## What you should see

A quick training run, followed by 5 checks: the independent confusion
matrix cross-check, the pixel-count sanity check, the derived-metrics
formula check, valid sample prediction images, and the saved report
exactly matching the live numbers — ending in `ALL CHECKS PASSED`.

To see it in the actual app: train a model (Stage 6), click **"View Full
Results"** once it finishes, and explore the summary/confusion
matrix/chart/samples, then try **Save Report** and click the download link.

## Acceptance check for this stage

- [ ] `test_results.py` runs cleanly, all 5 checks pass, ending in
      `ALL CHECKS PASSED`
- [ ] After training in the app, "View Full Results" appears and opens
      a screen with real numbers (not blank/zero everywhere)
- [ ] The confusion matrix table shows sensible TP/TN/FP/FN counts that
      add up to the total pixel count shown
- [ ] The bar chart renders and roughly matches the summary card numbers
- [ ] Sample prediction images actually look like segmentation masks,
      not blank/broken images
- [ ] "Save Report" produces a working download link, and the downloaded
      file's numbers match what's shown on screen
- [ ] No errors in the browser console

If all of these are true, Stage 8 is complete and we move to Stage 9
(hyperparameter tuning mode — automated sweeps over multiple configurations).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py                        # now also serves Results endpoints
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py
│   ├── model_library.py
│   ├── inference.py
│   ├── results.py                    # NEW — confusion matrix, samples, reports
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       ├── test_api.py
│       └── test_results.py           # NEW — verifies confusion matrix correctness
├── frontend/
│   ├── index.html                    # UPDATED — adds Results screen
│   ├── style.css                     # UPDATED — summary cards, confusion table
│   └── script.js                     # UPDATED — results rendering, bar chart
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── reports/                           # NEW — saved JSON reports land here
├── requirements.txt
└── README.md
```

# SegLearn — Stage 7: Resume Training Screen

Adds a "Resume from a saved checkpoint" flow to the UI, matching the
backend resume logic from Stage 4/5. Students can browse every checkpoint
saved during any previous run, pick one, confirm (or deliberately change)
its architecture/dataset, choose how many more epochs to run, and
continue training — reusing the exact same live training view from
Stage 6.

## What was added

- **Frontend:** a new "Resume Training" screen, reachable via a
  "↻ Resume from a saved checkpoint instead" button on the dataset step:
  - Lists all saved checkpoints (pulled from `/api/checkpoints`) as cards
    showing run ID, epoch reached, architecture, dataset, learning rate,
    and latest training loss
  - Selecting a checkpoint pre-fills the architecture and dataset dropdowns
    to match what that checkpoint was actually trained with — but leaves
    them editable, so a student can deliberately pick the wrong one to see
    what happens
  - A slider for how many additional epochs to run, plus the same
    CPU/GPU device picker as Step 2
  - Submitting a mismatched architecture/dataset shows a clear, specific
    error inline (without crashing or losing your place); submitting a
    valid match switches straight into the live training view, correctly
    labeled ("Resuming from epoch N...") and tracking progress against the
    additional epochs requested rather than restarting the counter
- **Backend fix:** run names now use a readable, timestamp-based scheme
  instead of `job_<random hex>` — see below.
- **Delete button:** each checkpoint card on the Resume screen now has a
  small "×" delete button. Clicking it asks for confirmation, then removes
  that specific checkpoint file via a new `POST /api/checkpoints/delete`
  endpoint. If that was the last checkpoint in its run, the (now empty)
  run folder is cleaned up automatically. The endpoint validates the path
  is actually inside the checkpoints folder before deleting anything, so
  it can't be tricked into deleting arbitrary files on your system.

## Fix: readable, timestamp-based run names

Originally, training runs were named `job_<random hex>` (e.g.
`job_86d3798f`), which made the checkpoint list hard to scan — no way to
tell what a run was or when it happened without clicking into it. Run
names now follow the pattern:

```
<architecture>_<dataset>_<YYYY-MM-DD_HH-MM-SS>_<4-char suffix>
```

for example `mini_unet_sample_shapes_2026-09-06_02-15-36_f0ba`. The tiny
random suffix only guards against two runs starting in the exact same
second — it's not meant to be read; the architecture, dataset, and
timestamp are what make each run identifiable at a glance, and
checkpoints naturally sort chronologically by name.

Also worth knowing: every checkpoint is kept permanently by design — the
whole point of Resume is being able to go back to *any* past run. If your
checkpoint list gets cluttered (e.g. from testing), you can safely clear
it out any time with `rm -rf checkpoints/*` (keep the folder itself).

## How to run it

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/app.py
```

Open `http://127.0.0.1:5000`. Train a model first (any short run works —
this is what creates a checkpoint), then click **"↻ Resume from a saved
checkpoint instead"** on the dataset screen to try resuming it.

## What you should see

- With no checkpoints yet, the resume screen shows a clear "no checkpoints
  found" message instead of an empty blank list
- After training once, going to the resume screen shows that run as a
  checkpoint card with correct metadata
- Selecting it pre-fills architecture/dataset to match
- Deliberately changing the architecture dropdown to something else and
  clicking "Resume Training" shows a clear red error message and keeps
  you on the resume screen
- Fixing the architecture back and resuming switches to the training view,
  labeled "Resuming from epoch N...", and completes correctly

## How I verified this stage

Same approach as Stage 6 — a real headless-browser (Playwright) test that
clicks through the whole flow: confirmed the empty state, trained a model
to create a real checkpoint, confirmed it appears with correct metadata,
confirmed architecture/dataset pre-fill correctly, deliberately triggered
a mismatch and confirmed the exact error text appears without navigating
away or crashing, then fixed it and confirmed the resumed run completes
correctly. Zero browser console errors throughout. As before, you should
still click through it yourself to judge how it feels.

## Acceptance check for this stage

- [ ] With no checkpoints, the resume screen shows a clear empty-state message
- [ ] After training once, the checkpoint appears with correct metadata
- [ ] Selecting a checkpoint pre-fills architecture/dataset correctly
- [ ] A deliberately wrong architecture/dataset shows a clear error and
      does not crash or navigate away
- [ ] A valid resume switches to the training view and completes correctly
- [ ] Clicking the "×" delete button on a checkpoint asks for confirmation,
      then removes it from the list
- [ ] No errors in the browser console

If all of these are true, Stage 7 is complete and we move to Stage 8
(the Results screen — confusion matrix, bar charts of metrics, and
side-by-side predicted vs. ground-truth comparisons).

## Project structure so far

```
seglearn/
├── backend/                          (unchanged this stage)
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py
│   ├── model_library.py
│   ├── inference.py
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       └── test_api.py
├── frontend/
│   ├── index.html                    # UPDATED — adds Resume Training screen
│   ├── style.css                     # UPDATED — checkpoint card styles
│   └── script.js                     # UPDATED — resume screen logic
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── requirements.txt
└── README.md
```

# SegLearn — Stage 6: Frontend Setup & Training Screens

This is the big one: a real, working browser UI wired to the Stage 5 API.
A 3-step wizard — Dataset → Model/Hyperparameter Setup → Live Training —
where you can actually select a dataset, adjust hyperparameter sliders,
start a real training run, and watch it train live: a progress bar, live
loss/Dice/IoU charts, and a live "prediction improving over time" preview
panel. A Stop button interrupts a run cleanly mid-training.

## What was added

- **Backend:** live prediction previews during training. Every epoch, the
  validation pass now optionally captures one sample's (input image,
  ground truth mask, predicted mask) as small PNGs — but only for the live
  UI callback, never stored in the checkpoint/metrics history, so
  checkpoints stay exactly the same lightweight format as before. Fully
  backward compatible — Stage 3/4/5 test scripts still pass unchanged.
- **Frontend:** a complete rewrite of `index.html`/`style.css`/`script.js`
  into a 3-step wizard:
  1. **Dataset** (same as Stage 1, now feeding into the next steps)
  2. **Model & Hyperparameters** — architecture dropdown (with a warning
     note if you pick the large Full U-Net), sliders for learning rate,
     epochs, batch size, validation split, and dataset subset size, plus
     a compute-device picker (Auto/CPU/GPU) that greys out GPU options
     your machine doesn't actually have
  3. **Training** — Start/Stop buttons, a progress bar, two live-updating
     charts (loss, and Dice/IoU) drawn with plain `<canvas>` — no external
     charting library, so the app stays fully usable offline — and a live
     preview panel showing the model's prediction on a validation image
     improving epoch by epoch

## How to run it

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/app.py
```

Open `http://127.0.0.1:5000` in your browser and walk through the wizard:
select the bundled dataset, preview it, continue to setup, adjust the
sliders (try lowering epochs/subset size for a faster first run), pick a
device, and click **Start Training**.

## What you should see

- Selecting the dataset and clicking "Preview dataset" shows thumbnails
  (same as Stage 1), and unlocks "Continue to Model Setup"
- On the setup screen, moving each slider updates its displayed value
  live; the device picker greys out GPU options if you don't have one
- Clicking "Start Training" switches to the training screen and the
  progress bar / epoch counter climb as training runs
- Both charts draw and update every ~0.7 seconds
- The live preview panel shows three small images (input / ground truth /
  prediction) that update each epoch — the prediction should visibly
  start looking more like the ground truth as training progresses
- Clicking "Stop" during a run ends it early ("Training stopped early")
  rather than continuing to the full epoch count
- After finishing (or stopping), a "Train Another" button appears and
  takes you back to Step 1

## How I verified this stage

Since I can't click through a browser myself in this environment, I used
a real headless-browser (Playwright/Chromium) test to click through the
entire flow exactly as a student would — select dataset, preview, move
sliders, start training, poll live updates, verify the chart canvases
actually have drawn pixels (not blank), verify live preview images are
real base64 PNGs, test the Stop button mid-run, and test "Train Another"
resets back to Step 1. All of this passed with zero browser console
errors. You should still click through it yourself to confirm the visual
experience feels right — that's a judgment call I can't fully make for you.

## Acceptance check for this stage

- [ ] Select dataset → preview shows thumbnails → "Continue" unlocks
- [ ] All hyperparameter sliders show their current value and update live
- [ ] Device picker shows your real available devices (GPU options greyed
      out if you don't have one)
- [ ] Starting training switches to the training screen and progress
      visibly advances
- [ ] Both charts draw and update as training progresses
- [ ] Live preview images appear and the prediction visibly improves
- [ ] Clicking Stop ends the run early, cleanly, with no errors
- [ ] "Train Another" returns you to Step 1
- [ ] No errors in the browser console (right-click → Inspect → Console)

If all of these are true, Stage 6 is complete and we move to Stage 7
(the Resume Training screen, using the checkpoints this stage's runs
create).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py                      # now also generates live previews
│   ├── job_manager.py                # now also tracks latest_preview
│   ├── model_library.py
│   ├── inference.py
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       └── test_api.py
├── frontend/
│   ├── index.html                    # REWRITTEN — 3-step wizard
│   ├── style.css                     # REWRITTEN — wizard/slider/chart styles
│   └── script.js                     # REWRITTEN — full wizard + polling + charts
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/
├── checkpoints/
├── requirements.txt
└── README.md
```

# SegLearn — Stage 5: API Layer

Wraps everything built in Stages 1-4 (datasets, models, training,
checkpointing, resume) into HTTP endpoints, so the frontend (built from
Stage 6 onward) has something real to call. Training now runs in a
background thread so the server stays responsive for status polling and
stop requests while a run is in progress — this is what makes a live
progress bar and stop button possible later.

## What was added

- `backend/job_manager.py` — runs training/resume in a background thread,
  tracks status (`running` / `completed` / `stopped` / `error`), supports
  stopping a run early (the epoch loop in `train.py` was extended with a
  `stop_event` check, and now force-saves a checkpoint at the last
  completed epoch if stopped early, so no progress is lost)
- `backend/model_library.py` — lets a checkpoint be saved as a named,
  permanent model (`/models/<name>.pt`), separate from the working
  `checkpoints/` folder used during training
- `backend/inference.py` — runs a saved model on a new image, with
  optional Dice/IoU if a ground-truth mask is also provided
- `backend/app.py` — all the new endpoints listed below
- `backend/scripts/test_api.py` — verification script (see below)

## New endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/models/architectures` | List selectable model architectures |
| GET | `/api/devices` | Report which compute devices (cpu/cuda/mps) are available |
| POST | `/api/train/start` | Start a fresh training run (returns immediately with a `run_id`) |
| GET | `/api/train/status/<run_id>` | Poll progress/result of a run |
| POST | `/api/train/stop/<run_id>` | Stop an in-progress run |
| GET | `/api/checkpoints` | List all saved checkpoints across all runs |
| POST | `/api/train/resume` | Resume training from a checkpoint |
| POST | `/api/model/save` | Save a checkpoint as a named model |
| GET | `/api/models` | List saved models |
| POST | `/api/inference` | Run a saved model on a new uploaded image |

## How to run the verification

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_api.py
```

This uses Flask's test client (no need to separately start the server) and
exercises the full lifecycle: start a job, poll it to completion, start and
stop a second job early, resume from a checkpoint (both a valid case and a
deliberate mismatch), save a model, list it, and run inference with it.

If you'd like to see it work as a live server too, you can instead run:
```
python backend/app.py
```
and use `curl` or a browser to hit `http://127.0.0.1:5000/api/ping` etc.
while it's running.

## Acceptance check for this stage

- [ ] `test_api.py` runs with no errors
- [ ] All 14 checks report `PASS`
- [ ] Ends with `ALL CHECKS PASSED`
- [ ] (Optional) Run `python backend/app.py`, then in another terminal use
      `curl` to start a training job and poll its status a few times — you
      should see `status: running` with an increasing epoch count, then
      `status: completed`

If all of these are true, Stage 5 is complete and we move to Stage 6
(the real frontend — dataset selection, hyperparameter sliders, and a
live training view, wired to this API).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py                        # Flask app + all API endpoints
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py
│   ├── job_manager.py                # NEW — background training jobs
│   ├── model_library.py              # NEW — save/load named models
│   ├── inference.py                  # NEW — run a model on a new image
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       ├── test_resume.py
│       └── test_api.py               # NEW — verifies all API endpoints
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/               # saved models land here (via /api/model/save)
├── checkpoints/          # populated during training runs
├── requirements.txt
└── README.md
```

# SegLearn — Stage 4: Resume-from-Checkpoint Logic

Adds the ability to resume a training run from any saved checkpoint —
continuing model weights and optimizer state rather than starting over —
plus validation that rejects a resume attempt if the selected
architecture/dataset doesn't match what the checkpoint was actually
trained with. Still backend-only (no UI) — Stage 7 builds the actual
"Resume Training" screen on top of this.

## What was added

- `backend/train.py` — refactored to share a single epoch-loop between
  fresh runs and resumed runs, plus:
  - `resume_training()` — loads a checkpoint, restores model + optimizer
    state, continues training from `epoch + 1` onward in the *same* run
    folder (so checkpoints accumulate together)
  - `CheckpointMismatchError` — raised with a clear message if the
    architecture or dataset selected for resuming doesn't match the
    checkpoint's stored config
  - `list_checkpoints()` — scans all saved checkpoints across all runs
    and returns their metadata (used by Stage 5's API and Stage 7's UI)
- `backend/scripts/test_resume.py` — verification script (see below)

## How to run the verification

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_resume.py
```

## What you should see

1. A fresh 5-epoch training run
2. A resume from the epoch-5 checkpoint for 5 more epochs, with training
   loss continuing to drop smoothly (not jumping back up like a restart would)
3. Two deliberate mismatch attempts (wrong architecture, wrong dataset),
   each correctly rejected with a clear error message

Ending with `ALL CHECKS PASSED`.

## Acceptance check for this stage

- [ ] Script runs with no errors
- [ ] Combined metrics history has all 10 epochs, numbered 1-10 (not
      restarting at epoch 1 after resume)
- [ ] Training loss at epoch 10 is lower than at epoch 5 (proof it's a true
      continuation, not a fresh restart)
- [ ] The wrong-architecture resume attempt is rejected with a clear message
- [ ] The wrong-dataset resume attempt is rejected with a clear message
- [ ] Ends with `ALL CHECKS PASSED`

If all of these are true, Stage 4 is complete and we move to Stage 5
(the API layer wrapping everything built so far).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py
│   ├── losses_metrics.py
│   ├── device_utils.py
│   ├── models.py
│   ├── train.py                      # training + resume + checkpoint listing
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       ├── test_training.py
│       └── test_resume.py            # NEW — verifies resume logic
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/               # empty for now — used for final saved models later
├── checkpoints/          # populated during training runs
├── requirements.txt
└── README.md
```

# SegLearn — Stage 3: Core Training Loop & Checkpointing

Adds a real, working PyTorch training loop: dataset + model + hyperparameters
in, trained weights + metrics out, with checkpoints saved every 5 epochs
(and always at the final epoch). Still backend-only (no UI) — the goal here
is to prove training and checkpointing are numerically correct before
building the resume logic (Stage 4) and API layer (Stage 5) on top.

## What was added

- `backend/segmentation_dataset.py` — PyTorch `Dataset`/`DataLoader` wrapper
  that loads validated image/mask pairs, resizes them, and splits into
  train/validation sets (with optional dataset subsetting)
- `backend/losses_metrics.py` — combined BCE + Dice loss, plus Dice
  coefficient, IoU, and pixel-level confusion-matrix counts (the last of
  these is prepped for Stage 8's confusion matrix view)
- `backend/device_utils.py` — CPU/CUDA/MPS detection and selection, with
  safe fallback to CPU if a requested GPU isn't available
- `backend/train.py` — the training loop itself, including checkpoint
  saving (`checkpoints/<run_id>/epoch_<n>.pt`) with full config + optimizer
  state + metrics history embedded, ready for Stage 4's resume logic
- `backend/scripts/test_training.py` — verification script (see below)

## How to run the verification

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_training.py
```

## What you should see

A real training run (Mini U-Net, 10 epochs, small subset of the bundled
dataset) with per-epoch output, followed by three checks:

1. Training loss decreased from epoch 1 to epoch 10
2. Checkpoint files exist at epoch 5 and epoch 10
3. The epoch-5 checkpoint contains the correct keys, epoch number, and
   architecture/dataset metadata

Ending with `ALL CHECKS PASSED`.

**Note on the numbers you'll see:** this test intentionally uses a very
small subset (16 images) so it runs fast — this is just enough to prove
the pipeline is wired correctly. With this small synthetic dataset you
should actually see quite strong Dice/IoU scores by epoch 10 (often
0.85-0.99), since the synthetic blobs are an "easy" segmentation task.
Random weight initialization means exact numbers vary run to run — that's
expected. The script also checks that Dice and IoU move consistently with
each other (Dice should always be >= IoU) — both are computed on
thresholded predictions for reporting, while training internally uses a
differentiable soft-Dice loss.

## Acceptance check for this stage

- [ ] Script runs with no errors
- [ ] Training loss visibly decreases across epochs in the printed log
- [ ] All four checks report `PASS` (including the Dice >= IoU consistency check)
- [ ] Ends with `ALL CHECKS PASSED`
- [ ] (Optional) Look inside `checkpoints/stage3_verification_run/` — you should
      see `epoch_5.pt` and `epoch_10.pt` (this folder is deleted automatically
      each time you re-run the script, so don't worry about leftover files)

If all of these are true, Stage 3 is complete and we move to Stage 4
(resume-from-checkpoint logic).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py
│   ├── dataset_utils.py
│   ├── segmentation_dataset.py       # NEW — PyTorch Dataset/DataLoader
│   ├── losses_metrics.py             # NEW — BCE+Dice loss, Dice/IoU, confusion counts
│   ├── device_utils.py               # NEW — CPU/CUDA/MPS detection
│   ├── models.py
│   ├── train.py                      # NEW — training loop + checkpointing
│   └── scripts/
│       ├── generate_sample_dataset.py
│       ├── test_models.py
│       └── test_training.py          # NEW — verifies training + checkpoints
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/               # empty for now — used for final saved models later
├── checkpoints/          # populated during training runs
├── requirements.txt
└── README.md
```

# SegLearn — Stage 2: Model Architectures

Adds four selectable PyTorch segmentation model architectures. This
stage is backend-only (no UI changes) — the goal is purely to confirm the
models themselves are correct before wiring them into training.

## What was added

- `backend/models.py` — four architectures:
  - **Mini U-Net** (small, ~30K params) — fastest, recommended default
  - **Standard Mini U-Net** (medium, ~480K params) — more capacity, still small
  - **Simple CNN Encoder-Decoder** (no skip connections, ~106K params) — included
    so students can compare against the U-Net variants and see what skip
    connections actually do for segmentation quality
  - **Full U-Net** (large, ~31 million params) — the original full-scale U-Net
    architecture, unscaled. Included so students can directly compare a
    production-size model against the lightweight ones, both in segmentation
    quality and in training time. This one is genuinely slow on CPU —
    based on direct testing, a single training run can take anywhere from
    ~10 minutes (small dataset, low resolution) to 30-40+ minutes (larger
    dataset/resolution), versus well under a minute for the lightweight
    models. This is expected and part of the teaching point — later stages
    will surface a clear time-estimate warning before a student starts a
    Full U-Net run.
- `backend/scripts/test_models.py` — verification script (see below)

## How to run the verification

```
source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
pip install -r requirements.txt
python backend/scripts/test_models.py
```

## What you should see

For each of the four models, a `PASS` line showing:
- Output shape matches input shape (128x128 in, 128x128 out)
- Parameter count printed, with a size category label:
  - "lightweight (CPU-fast)" for the three small models
  - "large (expect slower training)" for the Full U-Net

Ending with `ALL MODELS PASSED`.

## Acceptance check for this stage

- [ ] Script runs with no errors
- [ ] All four models show `PASS` for output shape
- [ ] The three small models report parameter counts well under 5M
- [ ] The Full U-Net reports roughly 31 million parameters
- [ ] (Optional) forward pass for the three small models feels instant;
      the Full U-Net will be noticeably slower but should still complete

If all of these are true, Stage 2 is complete and we move to Stage 3
(the core training loop with checkpointing).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py
│   ├── dataset_utils.py
│   ├── models.py                     # 4 segmentation architectures
│   └── scripts/
│       ├── generate_sample_dataset.py
│       └── test_models.py            # verifies models before training
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── datasets/
│   ├── sample_shapes/
│   └── custom/
├── models/               # empty for now — used for saved trained models later
├── checkpoints/          # empty for now — used in Stage 3
├── requirements.txt
└── README.md
```

# SegLearn — Stage 1: Dataset Handling

Adds dataset selection, custom dataset upload, and preview on top of the
Stage 0 skeleton. Still no models or training yet — that's Stage 2/3.

**Note on the bundled dataset:** since this was built without internet
access to real medical imaging data, the bundled "Sample Shapes" dataset
is synthetic (simple blob shapes with matching masks) — it exists purely
to exercise the loading/validation/preview pipeline. The code works
identically with real X-ray/CT/MRI slice datasets; you can drop a real
one into `datasets/<name>/images` and `datasets/<name>/masks` (or upload
a zip through the UI) with zero code changes.

## How to run it

1. Create and activate a virtual environment (recommended):

   ```
   python -m venv venv
   source venv/bin/activate      # on Windows (Git Bash): source venv/Scripts/activate
   ```

2. Install dependencies:

   ```
   pip install -r requirements.txt
   ```

3. Run the backend:

   ```
   python backend/app.py
   ```

4. Open your browser to:

   ```
   http://127.0.0.1:5000
   ```

## What you should see

- The green backend-connected status box (from Stage 0)
- A dropdown listing the bundled "Sample Shapes" dataset — selecting it and
  clicking **Preview dataset** shows a small grid of image/mask thumbnail pairs
- An upload section where you can upload a `.zip` file containing `images/`
  and `masks/` subfolders as a custom dataset

## Testing custom upload yourself

1. Make a folder with two subfolders: `images/` and `masks/`, each containing
   a few `.png` files with **matching filenames** (e.g. `images/scan1.png`
   and `masks/scan1.png`).
2. Zip that folder (so the zip contains `images/` and `masks/` at its top level,
   or inside one single wrapper folder — both are supported).
3. In the app, type a name for the dataset, choose the zip file, click **Upload**.
4. You should see a green success message with the pair count, and the new
   dataset should appear in the dropdown above.

To confirm error handling works: try zipping a folder where an image has no
matching mask filename. You should get a clear red error message and the
dataset should **not** appear in the dropdown.

## Acceptance check for this stage

- [ ] Backend status box is green (Stage 0 still works)
- [ ] Bundled "Sample Shapes" dataset appears in the dropdown
- [ ] Clicking "Preview dataset" shows real image/mask thumbnail pairs
- [ ] Uploading a valid custom zip succeeds and appears in the dropdown
- [ ] Uploading a broken zip (mismatched filenames) shows a clear error and
      does NOT appear in the dropdown
- [ ] No errors in the browser console

If all of these are true, Stage 1 is complete and we move to Stage 2
(model architectures).

## Project structure so far

```
seglearn/
├── backend/
│   ├── app.py                        # Flask server + dataset API routes
│   ├── dataset_utils.py              # validation, loading, preview, upload handling
│   └── scripts/
│       └── generate_sample_dataset.py  # (re)generates the bundled synthetic dataset
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── datasets/
│   ├── sample_shapes/                # bundled synthetic dataset (images/ + masks/)
│   └── custom/                       # uploaded custom datasets land here
├── models/               # empty for now — used in later stages
├── checkpoints/          # empty for now — used in Stage 3
├── requirements.txt
└── README.md
```
