# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for EdSeg — ONEDIR build.

Build with:
    pyinstaller launcher.spec --noconfirm

This produces a FOLDER (dist/EdSeg/) containing a small EdSeg.exe plus
all its supporting files (Python runtime, PyTorch libraries, bundled
frontend/dataset) sitting alongside it — not compressed into one file.

On macOS specifically, this also produces a real dist/EdSeg.app bundle
(via the BUNDLE() step below) — a plain onedir folder is not a real,
launchable Mac application on its own.

Why onedir instead of onefile:
  - Onefile bundles have to silently re-extract their ENTIRE contents
    into a temp folder every single time the app is launched — with
    PyTorch in the mix, that can add many seconds (sometimes much more
    with a CUDA build) to every single startup, not just the first.
  - Onedir launches almost immediately, since every file is already
    sitting on disk in its final location — nothing to unpack.
  - The tradeoff: instead of handing someone one file, you hand them a
    folder. They still just double-click EdSeg.exe inside it, but the
    whole folder needs to stay together (zip it to share/distribute).

This bundles:
  - launcher.py (entry point: starts Flask + opens the pywebview window)
  - backend/ (all Python modules — added to pathex so imports like
    `import train`, `import models` resolve exactly as they do when
    running `python backend/app.py` directly during development)
  - frontend/ (HTML/CSS/JS served by Flask)
  - datasets/sample_shapes/ (the bundled synthetic dataset)

NOT bundled: checkpoints/, models/, reports/, datasets/custom/ — these
are created at runtime as the student uses the app, not shipped empty.
"""

import os
import sys

block_cipher = None

# SPECPATH is injected by PyInstaller into the spec file's execution
# context — it's the directory containing this .spec file itself. Using
# it (instead of os.getcwd()) means the build works correctly regardless
# of which directory the `pyinstaller` command is actually run from.
BACKEND_DIR = os.path.join(SPECPATH, "backend")
FRONTEND_DIR = os.path.join(SPECPATH, "frontend")
SAMPLE_DATASET_DIR = os.path.join(SPECPATH, "datasets", "sample_shapes")

# Windows needs a .ico, macOS needs a .icns — PyInstaller errors out if
# you hand it the wrong format for the current platform, so pick based
# on sys.platform rather than hardcoding one.
if sys.platform == "darwin":
    ICON_PATH = os.path.join(SPECPATH, "icon.icns")
elif sys.platform == "win32":
    ICON_PATH = os.path.join(SPECPATH, "icon.ico")
else:
    ICON_PATH = None

a = Analysis(
    [os.path.join(SPECPATH, "launcher.py")],
    pathex=[BACKEND_DIR],
    binaries=[],
    datas=[
        (FRONTEND_DIR, "frontend"),
        (SAMPLE_DATASET_DIR, os.path.join("datasets", "sample_shapes")),
    ],
    hiddenimports=[
        "app", "dataset_utils", "segmentation_dataset", "losses_metrics",
        "device_utils", "models", "train", "job_manager", "tuning",
        "model_library", "inference", "results",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# EXE() here only builds the small bootloader executable — a.binaries,
# a.zipfiles, and a.datas are deliberately NOT passed to it (unlike a
# onefile build). They go to COLLECT() below instead, which lays them
# out as plain files in the output folder next to the exe.
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="EdSeg",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=ICON_PATH,
)

# COLLECT() assembles the dist/EdSeg/ folder: the small exe from above,
# plus every supporting binary/library/data file as loose files alongside
# it (fast to load, no self-extraction needed at launch). On Windows,
# this folder — containing EdSeg.exe — IS the final distributable.
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="EdSeg",
)

# On macOS, COLLECT()'s plain folder is NOT a real, launchable Mac app —
# it's just a folder containing a raw Unix executable, which Finder and
# Gatekeeper treat as an ordinary command-line binary, not an
# application (no icon, no proper double-click launch, and it's part of
# why an unsigned raw binary downloaded from the internet gets flagged
# so aggressively). BUNDLE() wraps COLLECT()'s output into the actual
# EdSeg.app structure (Info.plist, Contents/MacOS, Contents/Resources,
# icon) that macOS recognizes as a real application. This step has no
# effect on Windows and is skipped there.
if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="EdSeg.app",
        icon=ICON_PATH,
        bundle_identifier="com.edseg.app",
        info_plist={
            "CFBundleName": "EdSeg",
            "CFBundleDisplayName": "EdSeg",
            "CFBundleShortVersionString": "1.0.0",
            "NSHighResolutionCapable": True,
        },
    )
