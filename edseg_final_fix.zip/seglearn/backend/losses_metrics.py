"""
Loss functions and evaluation metrics for binary segmentation.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def dice_coefficient(pred_probs, target, eps=1e-6):
    """
    SOFT Dice coefficient, computed directly on probabilities (not
    thresholded). Used internally by DiceLoss because it needs to be
    differentiable. Do not use this for reporting a "Dice score" metric
    to students — see dice_score() below for that.
    """
    pred_flat = pred_probs.reshape(pred_probs.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)

    intersection = (pred_flat * target_flat).sum(dim=1)
    union = pred_flat.sum(dim=1) + target_flat.sum(dim=1)

    dice = (2 * intersection + eps) / (union + eps)
    return dice.mean()


def dice_score(pred_probs, target, threshold=0.5, eps=1e-6):
    """
    HARD (thresholded) Dice score — the version to report as a metric.

    Unlike dice_coefficient(), this thresholds predictions first, just
    like iou_score() does. This matters: early in training, or with a
    small dataset, predicted probabilities are often unconfident (e.g.
    hovering around 0.3-0.5 everywhere) rather than confidently near 0/1.
    The soft Dice coefficient is very sensitive to that lack of
    confidence and can look misleadingly low even when the thresholded
    prediction closely matches the target. Reporting the hard version
    here keeps Dice and IoU consistent with each other for students
    interpreting the results.
    """
    pred_binary = (pred_probs > threshold).float()
    pred_flat = pred_binary.reshape(pred_binary.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)

    intersection = (pred_flat * target_flat).sum(dim=1)
    union = pred_flat.sum(dim=1) + target_flat.sum(dim=1)

    dice = (2 * intersection + eps) / (union + eps)
    return dice.mean()


def iou_score(pred_probs, target, threshold=0.5, eps=1e-6):
    """
    Intersection-over-Union using a hard threshold on predicted probabilities.
    """
    pred_binary = (pred_probs > threshold).float()
    pred_flat = pred_binary.reshape(pred_binary.shape[0], -1)
    target_flat = target.reshape(target.shape[0], -1)

    intersection = (pred_flat * target_flat).sum(dim=1)
    union = pred_flat.sum(dim=1) + target_flat.sum(dim=1) - intersection

    iou = (intersection + eps) / (union + eps)
    return iou.mean()


class DiceLoss(nn.Module):
    """1 - Dice coefficient, computed on sigmoid probabilities."""

    def forward(self, logits, target):
        probs = torch.sigmoid(logits)
        return 1.0 - dice_coefficient(probs, target)


class BCEDiceLoss(nn.Module):
    """
    Combined loss: BCEWithLogits + Dice. A standard, robust choice for
    binary segmentation — BCE gives stable pixel-wise gradients, Dice
    directly optimizes for mask overlap (helpful with class imbalance,
    e.g. small structures on a large background).
    """

    def __init__(self, bce_weight=0.5):
        super().__init__()
        self.bce_weight = bce_weight
        self.bce = nn.BCEWithLogitsLoss()
        self.dice = DiceLoss()

    def forward(self, logits, target):
        bce_loss = self.bce(logits, target)
        dice_loss = self.dice(logits, target)
        return self.bce_weight * bce_loss + (1 - self.bce_weight) * dice_loss


def compute_confusion_counts(pred_probs, target, threshold=0.5):
    """
    Pixel-level confusion matrix counts across a batch: true positive,
    true negative, false positive, false negative. Used for the Stage 8
    confusion matrix visualization, exposed here so it can be reused
    during training/validation too if useful.
    """
    pred_binary = (pred_probs > threshold).float()

    tp = ((pred_binary == 1) & (target == 1)).sum().item()
    tn = ((pred_binary == 0) & (target == 0)).sum().item()
    fp = ((pred_binary == 1) & (target == 0)).sum().item()
    fn = ((pred_binary == 0) & (target == 1)).sum().item()

    return {"tp": tp, "tn": tn, "fp": fp, "fn": fn}
