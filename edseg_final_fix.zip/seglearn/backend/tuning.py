"""
Hyperparameter tuning for SegLearn — Stage 9 (with grid search).

Supports sweeping over ONE OR MORE hyperparameters at once (learning rate,
batch size, dataset subset size, model architecture). When more than one
parameter is swept, every combination of their values is tried (a full
grid search) — e.g. 2 learning rates x 2 batch sizes = 4 trials.

Because combinations multiply quickly, this enforces hard caps on the
number of parameters that can be swept together, the number of values per
parameter, and above all the TOTAL number of trials that will actually
run — trials beyond that cap are silently dropped rather than producing a
runaway job. This is the main risk this feature is designed to guard
against.
"""

import re
import uuid
import itertools
from datetime import datetime

from train import train_model

MAX_PARAMS_TO_SWEEP = 3        # how many different hyperparameters can be combined
MAX_VALUES_PER_PARAM = 4       # how many values each individual parameter can offer
MAX_TOTAL_TRIALS = 20          # hard ceiling on the full grid, regardless of the above
MAX_EPOCHS_PER_TRIAL = 15

# Kept for backward compatibility / display purposes and for the API's
# "what can I sweep" listing.
MAX_TRIALS = MAX_TOTAL_TRIALS

# Maps the sweep parameter name (as used in the UI/API) to the keyword
# argument name train_model() actually expects.
SWEEPABLE_PARAMS = {
    "learning_rate": {"display_name": "Learning rate", "train_kwarg": "learning_rate"},
    "batch_size": {"display_name": "Batch size", "train_kwarg": "batch_size"},
    "subset_size": {"display_name": "Dataset subset size", "train_kwarg": "subset_size"},
    "architecture": {"display_name": "Model architecture", "train_kwarg": "model_name"},
}


def _safe_value_str(value):
    """Turn a sweep value into something filename-safe for the run_id."""
    return re.sub(r"[^a-zA-Z0-9_.-]", "", str(value))


def compute_grid_combinations(sweep_params):
    """
    sweep_params: list of {"param": <name>, "values": [...]}.

    Returns the full Cartesian product as a list of dicts, e.g.
    [{"learning_rate": 0.001, "batch_size": 4}, {"learning_rate": 0.001, "batch_size": 8}, ...]
    along with info on whether anything had to be clamped to the hard caps.

    This is exposed as its own function (not just inlined into run_sweep)
    specifically so it can be unit-tested in isolation — grid/combinatorial
    logic is exactly the kind of thing that's easy to get subtly wrong.
    """
    requested_param_count = len(sweep_params)
    clamped_params = sweep_params[:MAX_PARAMS_TO_SWEEP]
    params_were_clamped = requested_param_count > MAX_PARAMS_TO_SWEEP

    values_were_clamped = False
    param_names = []
    value_lists = []
    for entry in clamped_params:
        name = entry["param"]
        values = entry["values"]
        if len(values) > MAX_VALUES_PER_PARAM:
            values_were_clamped = True
        values = values[:MAX_VALUES_PER_PARAM]
        param_names.append(name)
        value_lists.append(values)

    all_combinations = [
        dict(zip(param_names, combo))
        for combo in itertools.product(*value_lists)
    ] if value_lists else []

    requested_total = len(all_combinations)
    clamped_combinations = all_combinations[:MAX_TOTAL_TRIALS]
    trials_were_clamped = requested_total > MAX_TOTAL_TRIALS

    return {
        "combinations": clamped_combinations,
        "requested_param_count": requested_param_count,
        "params_were_clamped": params_were_clamped,
        "values_were_clamped": values_were_clamped,
        "requested_total_trials": requested_total,
        "trials_were_clamped": trials_were_clamped,
    }


def run_sweep(base_config, sweep_params,
              on_trial_start=None, on_epoch_progress=None, on_trial_complete=None,
              stop_event=None):
    """
    base_config: dict with dataset_name, dataset_source, model_name,
                 learning_rate, epochs, batch_size, val_split, subset_size,
                 device_preference — the FIXED settings for every trial,
                 except whichever parameter(s) are being swept.
    sweep_params: list of {"param": <name>, "values": [...]}, where each
                  <name> is a key in SWEEPABLE_PARAMS. One entry sweeps a
                  single parameter; multiple entries run a full grid search
                  across every combination of their values.

    Returns a dict with the list of trial results plus info on whether
    parameters, values-per-parameter, total trials, or epochs had to be
    clamped down to the hard caps.
    """
    unknown = [e["param"] for e in sweep_params if e["param"] not in SWEEPABLE_PARAMS]
    if unknown:
        raise ValueError(f"Unknown sweep parameter(s): {unknown}. Must be one of: {list(SWEEPABLE_PARAMS)}")

    grid_info = compute_grid_combinations(sweep_params)
    combinations = grid_info["combinations"]

    requested_epochs = base_config.get("epochs", 10)
    epochs = min(requested_epochs, MAX_EPOCHS_PER_TRIAL)
    epochs_were_clamped = requested_epochs > MAX_EPOCHS_PER_TRIAL

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    trials = []

    for i, combo in enumerate(combinations):
        if stop_event is not None and stop_event.is_set():
            break

        trial_kwargs = {
            "dataset_name": base_config["dataset_name"],
            "dataset_source": base_config["dataset_source"],
            "model_name": base_config["model_name"],
            "learning_rate": base_config.get("learning_rate", 1e-3),
            "epochs": epochs,
            "batch_size": base_config.get("batch_size", 8),
            "val_split": base_config.get("val_split", 0.2),
            "subset_size": base_config.get("subset_size"),
            "device_preference": base_config.get("device_preference", "auto"),
        }

        # Apply every swept parameter's value for this combination
        for param_name, value in combo.items():
            train_kwarg = SWEEPABLE_PARAMS[param_name]["train_kwarg"]
            trial_kwargs[train_kwarg] = value

        run_id_parts = "_".join(f"{p}{_safe_value_str(v)}" for p, v in combo.items())
        run_id = f"tune_{run_id_parts}_{timestamp}_{uuid.uuid4().hex[:4]}"

        if on_trial_start:
            on_trial_start(i, combo, run_id)

        def _progress(epoch_metrics, trial_index=i):
            if on_epoch_progress:
                on_epoch_progress(trial_index, epoch_metrics)

        result = train_model(
            **trial_kwargs,
            checkpoint_every=5,
            run_id=run_id,
            progress_callback=_progress,
            stop_event=stop_event,
        )

        final_metrics = result["metrics_history"][-1] if result["metrics_history"] else {}
        trial_result = {
            "trial_index": i,
            "sweep_values": combo,  # dict, e.g. {"learning_rate": 0.001, "batch_size": 4}
            "run_id": run_id,
            "checkpoint_path": result["checkpoint_paths"][-1] if result["checkpoint_paths"] else None,
            "final_metrics": final_metrics,
        }
        trials.append(trial_result)

        if on_trial_complete:
            on_trial_complete(i, trial_result)

    return {
        "trials": trials,
        "epochs_used": epochs,
        "requested_epochs": requested_epochs,
        "epochs_were_clamped": epochs_were_clamped,
        "requested_total_trials": grid_info["requested_total_trials"],
        "trials_were_clamped": grid_info["trials_were_clamped"],
        "requested_param_count": grid_info["requested_param_count"],
        "params_were_clamped": grid_info["params_were_clamped"],
        "values_were_clamped": grid_info["values_were_clamped"],
    }
