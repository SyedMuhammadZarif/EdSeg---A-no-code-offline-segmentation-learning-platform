"""
PyTorch Dataset for 2D segmentation image/mask pairs.

Builds on top of dataset_utils (Stage 1) — reuses the same validation
logic so training always operates on already-confirmed-valid data.
"""

import os
import random
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader

import dataset_utils


class SegmentationDataset(Dataset):
    """
    Loads (image, mask) pairs from a validated dataset folder, resizing to
    a fixed square size and normalizing to [0, 1]. Masks are binarized
    (threshold 0.5) so this currently supports binary segmentation.
    """

    def __init__(self, dataset_path, pairs, image_size=128):
        self.dataset_path = dataset_path
        self.pairs = pairs
        self.image_size = image_size
        self.images_dir = os.path.join(dataset_path, "images")
        self.masks_dir = os.path.join(dataset_path, "masks")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img_name, mask_name = self.pairs[idx]

        img = Image.open(os.path.join(self.images_dir, img_name)).convert("L")
        mask = Image.open(os.path.join(self.masks_dir, mask_name)).convert("L")

        img = img.resize((self.image_size, self.image_size), Image.BILINEAR)
        mask = mask.resize((self.image_size, self.image_size), Image.NEAREST)

        img_arr = np.asarray(img, dtype=np.float32) / 255.0
        mask_arr = (np.asarray(mask, dtype=np.float32) / 255.0 > 0.5).astype(np.float32)

        img_tensor = torch.from_numpy(img_arr).unsqueeze(0)   # (1, H, W)
        mask_tensor = torch.from_numpy(mask_arr).unsqueeze(0)  # (1, H, W)

        return img_tensor, mask_tensor


def build_dataloaders(dataset_name, dataset_source, image_size=128, batch_size=8,
                       val_split=0.2, subset_size=None, seed=42):
    """
    Resolve a dataset by name/source, optionally take a random subset,
    split into train/val, and return (train_loader, val_loader, total_pairs_used).
    """
    dataset_path = dataset_utils.resolve_dataset_path(dataset_name, dataset_source)
    pairs = dataset_utils.validate_dataset_folder(dataset_path)  # raises if invalid

    rng = random.Random(seed)
    shuffled = pairs[:]
    rng.shuffle(shuffled)

    if subset_size is not None and subset_size < len(shuffled):
        shuffled = shuffled[:subset_size]

    val_count = max(1, int(len(shuffled) * val_split)) if len(shuffled) > 1 else 0
    val_pairs = shuffled[:val_count]
    train_pairs = shuffled[val_count:]

    if len(train_pairs) == 0:
        raise ValueError("Not enough images to form a training set after applying the validation split.")

    train_ds = SegmentationDataset(dataset_path, train_pairs, image_size=image_size)
    val_ds = SegmentationDataset(dataset_path, val_pairs, image_size=image_size) if val_pairs else None

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False) if val_ds else None

    return train_loader, val_loader, len(shuffled)
