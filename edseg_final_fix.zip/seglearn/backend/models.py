"""
Model architectures for SegLearn — Stage 2.

Three deliberately small/lightweight 2D segmentation architectures,
selectable by students in the UI. All take a single-channel grayscale
image and output a single-channel mask (values before sigmoid — loss
functions in later stages will apply BCEWithLogits or similar).

Kept intentionally small (well under a few million parameters each) so
they train quickly on a CPU, per the project's core design constraint.
"""

import torch
import torch.nn as nn


def _conv_block(in_channels, out_channels):
    """Two 3x3 convolutions with ReLU, padding='same' to preserve spatial size."""
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True),
        nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True),
    )


class MiniUNet(nn.Module):
    """
    Smallest option: a 3-level U-Net (2 downsamples) with narrow channel
    widths. Good default for first-time students — fastest to train.
    """
    name = "mini_unet"
    display_name = "Mini U-Net (small, fastest)"

    def __init__(self, in_channels=1, out_channels=1, base_channels=8):
        super().__init__()
        c = base_channels

        self.enc1 = _conv_block(in_channels, c)
        self.enc2 = _conv_block(c, c * 2)
        self.pool = nn.MaxPool2d(2)

        self.bottleneck = _conv_block(c * 2, c * 4)

        self.up2 = nn.ConvTranspose2d(c * 4, c * 2, kernel_size=2, stride=2)
        self.dec2 = _conv_block(c * 4, c * 2)  # concat with enc2 skip
        self.up1 = nn.ConvTranspose2d(c * 2, c, kernel_size=2, stride=2)
        self.dec1 = _conv_block(c * 2, c)  # concat with enc1 skip

        self.out_conv = nn.Conv2d(c, out_channels, kernel_size=1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))

        b = self.bottleneck(self.pool(e2))

        d2 = self.up2(b)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self.up1(d2)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        return self.out_conv(d1)


class StandardMiniUNet(nn.Module):
    """
    Medium option: a 4-level U-Net (3 downsamples) with wider channels.
    More capacity than MiniUNet, still small and CPU-friendly.
    """
    name = "standard_mini_unet"
    display_name = "Standard Mini U-Net (medium)"

    def __init__(self, in_channels=1, out_channels=1, base_channels=16):
        super().__init__()
        c = base_channels

        self.enc1 = _conv_block(in_channels, c)
        self.enc2 = _conv_block(c, c * 2)
        self.enc3 = _conv_block(c * 2, c * 4)
        self.pool = nn.MaxPool2d(2)

        self.bottleneck = _conv_block(c * 4, c * 8)

        self.up3 = nn.ConvTranspose2d(c * 8, c * 4, kernel_size=2, stride=2)
        self.dec3 = _conv_block(c * 8, c * 4)
        self.up2 = nn.ConvTranspose2d(c * 4, c * 2, kernel_size=2, stride=2)
        self.dec2 = _conv_block(c * 4, c * 2)
        self.up1 = nn.ConvTranspose2d(c * 2, c, kernel_size=2, stride=2)
        self.dec1 = _conv_block(c * 2, c)

        self.out_conv = nn.Conv2d(c, out_channels, kernel_size=1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))

        b = self.bottleneck(self.pool(e3))

        d3 = self.up3(b)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d2 = self.up2(d3)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self.up1(d2)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        return self.out_conv(d1)


class SimpleCNNEncoderDecoder(nn.Module):
    """
    A plain encoder-decoder CNN with NO skip connections — deliberately
    included so students can compare against the U-Net variants and see
    the effect skip connections have on segmentation quality.
    """
    name = "simple_cnn"
    display_name = "Simple CNN Encoder-Decoder (no skip connections)"

    def __init__(self, in_channels=1, out_channels=1, base_channels=16):
        super().__init__()
        c = base_channels

        self.encoder = nn.Sequential(
            _conv_block(in_channels, c),
            nn.MaxPool2d(2),
            _conv_block(c, c * 2),
            nn.MaxPool2d(2),
            _conv_block(c * 2, c * 4),
        )

        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(c * 4, c * 2, kernel_size=2, stride=2),
            _conv_block(c * 2, c * 2),
            nn.ConvTranspose2d(c * 2, c, kernel_size=2, stride=2),
            _conv_block(c, c),
        )

        self.out_conv = nn.Conv2d(c, out_channels, kernel_size=1)

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return self.out_conv(decoded)


class RealUNet(nn.Module):
    """
    The original U-Net architecture (Ronneberger et al.) at full width
    (64 -> 128 -> 256 -> 512 -> 1024 channels). ~31 million parameters.

    Included as an "advanced" option so students can directly compare a
    production-scale model against the lightweight options above — both
    in segmentation quality AND in training time. This is deliberately
    NOT scaled down, so expect training to take noticeably longer
    (potentially many minutes per run rather than under a minute).
    """
    name = "real_unet"
    display_name = "Full U-Net (large, slow — several minutes to train)"

    def __init__(self, in_channels=1, out_channels=1, base_channels=64):
        super().__init__()
        c = base_channels

        self.enc1 = _conv_block(in_channels, c)
        self.enc2 = _conv_block(c, c * 2)
        self.enc3 = _conv_block(c * 2, c * 4)
        self.enc4 = _conv_block(c * 4, c * 8)
        self.pool = nn.MaxPool2d(2)

        self.bottleneck = _conv_block(c * 8, c * 16)

        self.up4 = nn.ConvTranspose2d(c * 16, c * 8, kernel_size=2, stride=2)
        self.dec4 = _conv_block(c * 16, c * 8)
        self.up3 = nn.ConvTranspose2d(c * 8, c * 4, kernel_size=2, stride=2)
        self.dec3 = _conv_block(c * 8, c * 4)
        self.up2 = nn.ConvTranspose2d(c * 4, c * 2, kernel_size=2, stride=2)
        self.dec2 = _conv_block(c * 4, c * 2)
        self.up1 = nn.ConvTranspose2d(c * 2, c, kernel_size=2, stride=2)
        self.dec1 = _conv_block(c * 2, c)

        self.out_conv = nn.Conv2d(c, out_channels, kernel_size=1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))

        b = self.bottleneck(self.pool(e4))

        d4 = self.up4(b)
        d4 = self.dec4(torch.cat([d4, e4], dim=1))
        d3 = self.up3(d4)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d2 = self.up2(d3)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self.up1(d2)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        return self.out_conv(d1)


# Registry so the rest of the app can look models up by name (used by the
# API layer and the resume-from-checkpoint logic in later stages).
MODEL_REGISTRY = {
    MiniUNet.name: MiniUNet,
    StandardMiniUNet.name: StandardMiniUNet,
    SimpleCNNEncoderDecoder.name: SimpleCNNEncoderDecoder,
    RealUNet.name: RealUNet,
}


def build_model(name, in_channels=1, out_channels=1):
    """Instantiate a model by its registry name."""
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model name '{name}'. Available: {list(MODEL_REGISTRY.keys())}")
    return MODEL_REGISTRY[name](in_channels=in_channels, out_channels=out_channels)


def count_parameters(model):
    """Return total trainable parameter count for a model."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
