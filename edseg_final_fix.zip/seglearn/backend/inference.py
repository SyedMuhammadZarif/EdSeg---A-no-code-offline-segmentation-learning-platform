"""
Inference on a single new image using a saved model — SegLearn Stage 5.

This is a minimal version of what Stage 10's full testing screen will
build on: given a saved model name and an uploaded image, run a forward
pass and return the predicted mask as a base64 PNG. If the student also
supplies a ground-truth mask, compute Dice/IoU for that single image too.
"""

import io
import base64
import numpy as np
from PIL import Image
import torch

from model_library import load_model_for_inference
from device_utils import resolve_device
from losses_metrics import dice_score, iou_score


def _pil_to_base64(im):
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def run_inference(model_name, image_file, mask_file=None, device_preference="auto"):
    """
    image_file / mask_file: file-like objects (e.g. Flask's request.files[...]).
    Returns a dict with the predicted mask (base64 PNG) and, if a ground
    truth mask was provided, single-image Dice/IoU metrics.
    """
    device, device_label = resolve_device(device_preference)
    model, config = load_model_for_inference(model_name, device)

    image_size = config["image_size"]

    img = Image.open(image_file).convert("L").resize((image_size, image_size), Image.BILINEAR)
    img_arr = np.asarray(img, dtype=np.float32) / 255.0
    img_tensor = torch.from_numpy(img_arr).unsqueeze(0).unsqueeze(0).to(device)  # (1,1,H,W)

    with torch.no_grad():
        logits = model(img_tensor)
        probs = torch.sigmoid(logits)

    pred_mask_arr = (probs[0, 0].cpu().numpy() > 0.5).astype(np.uint8) * 255
    pred_mask_img = Image.fromarray(pred_mask_arr, mode="L")

    result = {
        "predicted_mask": _pil_to_base64(pred_mask_img),
        "device_used": device_label,
        "architecture": config["architecture"],
    }

    if mask_file is not None:
        gt_mask = Image.open(mask_file).convert("L").resize((image_size, image_size), Image.NEAREST)
        gt_arr = (np.asarray(gt_mask, dtype=np.float32) / 255.0 > 0.5).astype(np.float32)
        gt_tensor = torch.from_numpy(gt_arr).unsqueeze(0).unsqueeze(0).to(device)

        result["dice"] = dice_score(probs, gt_tensor).item()
        result["iou"] = iou_score(probs, gt_tensor).item()

    return result
