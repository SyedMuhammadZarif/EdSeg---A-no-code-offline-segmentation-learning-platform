"""
Inference on a single new image using a saved model — SegLearn Stage 5.

This is a minimal version of what Stage 10's full testing screen will
build on: given a saved model name and an uploaded image, run a forward
pass and return the predicted mask as a base64 PNG. If the student also
supplies a ground-truth mask, compute Dice/IoU for that single image too.

Also supports running a saved model across an ENTIRE dataset at once
(run_inference_on_dataset) rather than just one uploaded image — useful
for checking how a model generalizes across a full held-out dataset, not
just a single spot-check image.
"""

import os
import io
import base64
import numpy as np
from PIL import Image
import torch

from model_library import load_model_for_inference
from device_utils import resolve_device
from losses_metrics import dice_score, iou_score, compute_confusion_counts
import dataset_utils

# Cap on how many individual predictions are returned for the gallery
# view when testing on a full dataset — keeps the response payload
# reasonable even if someone points this at an unusually large dataset,
# while comfortably covering the "tens to a couple hundred images" size
# this app is actually designed around.
MAX_GALLERY_PREDICTIONS = 300


def _pil_to_base64(im):
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def run_inference(model_name, image_file, mask_file=None, device_preference="auto"):
    """
    image_file / mask_file: file-like objects (e.g. Flask's request.files[...]).
    Returns a dict with the predicted mask (base64 PNG) and, if a ground
    truth mask was provided, single-image Dice/IoU metrics.
    """
    device, device_label = resolve_device(device_preference)
    model, config = load_model_for_inference(model_name, device)

    image_size = config["image_size"]

    img = Image.open(image_file).convert("L").resize((image_size, image_size), Image.BILINEAR)
    img_arr = np.asarray(img, dtype=np.float32) / 255.0
    img_tensor = torch.from_numpy(img_arr).unsqueeze(0).unsqueeze(0).to(device)  # (1,1,H,W)

    with torch.no_grad():
        logits = model(img_tensor)
        probs = torch.sigmoid(logits)

    pred_mask_arr = (probs[0, 0].cpu().numpy() > 0.5).astype(np.uint8) * 255
    pred_mask_img = Image.fromarray(pred_mask_arr, mode="L")

    result = {
        "predicted_mask": _pil_to_base64(pred_mask_img),
        "device_used": device_label,
        "architecture": config["architecture"],
    }

    if mask_file is not None:
        gt_mask = Image.open(mask_file).convert("L").resize((image_size, image_size), Image.NEAREST)
        gt_arr = (np.asarray(gt_mask, dtype=np.float32) / 255.0 > 0.5).astype(np.float32)
        gt_tensor = torch.from_numpy(gt_arr).unsqueeze(0).unsqueeze(0).to(device)

        result["dice"] = dice_score(probs, gt_tensor).item()
        result["iou"] = iou_score(probs, gt_tensor).item()

    return result


def _array_to_base64(arr_uint8, thumb_size=(150, 150)):
    im = Image.fromarray(arr_uint8.astype(np.uint8), mode="L").resize(thumb_size, Image.NEAREST)
    return _pil_to_base64(im)


def run_inference_on_dataset(model_name, dataset_name, dataset_source, device_preference="auto"):
    """
    Run a saved model on EVERY image/mask pair in a dataset — not just one
    uploaded image — accumulating a pixel-level confusion matrix across
    the whole dataset (same aggregate metrics as the training Results
    screen) and collecting per-image predictions for the "View All Test
    Predictions" gallery.

    Unlike training's held-out validation split, this tests against
    every pair in the chosen dataset — useful for checking how a saved
    model generalizes to a dataset it may never have even been trained
    on at all, not just the slice held back during its own training run.
    """
    device, device_label = resolve_device(device_preference)
    model, config = load_model_for_inference(model_name, device)
    image_size = config["image_size"]

    dataset_path = dataset_utils.resolve_dataset_path(dataset_name, dataset_source)
    pairs = dataset_utils.validate_dataset_folder(dataset_path)

    images_dir = os.path.join(dataset_path, "images")
    masks_dir = os.path.join(dataset_path, "masks")

    total_counts = {"tp": 0, "tn": 0, "fp": 0, "fn": 0}
    predictions = []

    model.eval()
    with torch.no_grad():
        for img_name, mask_name in pairs:
            img_path = os.path.join(images_dir, img_name)
            mask_path = os.path.join(masks_dir, mask_name)

            img = Image.open(img_path).convert("L").resize((image_size, image_size), Image.BILINEAR)
            img_arr = np.asarray(img, dtype=np.float32) / 255.0
            img_tensor = torch.from_numpy(img_arr).unsqueeze(0).unsqueeze(0).to(device)

            gt_mask = Image.open(mask_path).convert("L").resize((image_size, image_size), Image.NEAREST)
            gt_arr = (np.asarray(gt_mask, dtype=np.float32) / 255.0 > 0.5).astype(np.float32)
            gt_tensor = torch.from_numpy(gt_arr).unsqueeze(0).unsqueeze(0).to(device)

            logits = model(img_tensor)
            probs = torch.sigmoid(logits)

            counts = compute_confusion_counts(probs, gt_tensor)
            for k in total_counts:
                total_counts[k] += counts[k]

            if len(predictions) < MAX_GALLERY_PREDICTIONS:
                pred_mask_arr = (probs[0, 0].cpu().numpy() > 0.5).astype(np.uint8) * 255
                predictions.append({
                    "filename": img_name,
                    "image": _array_to_base64(img_arr * 255),
                    "ground_truth": _array_to_base64(gt_arr * 255),
                    "prediction": _array_to_base64(pred_mask_arr),
                })

    tp, tn, fp, fn = total_counts["tp"], total_counts["tn"], total_counts["fp"], total_counts["fn"]
    total_pixels = tp + tn + fp + fn
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    dice = (2 * tp) / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else 0.0
    iou = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0.0
    accuracy = (tp + tn) / total_pixels if total_pixels > 0 else 0.0

    return {
        "device_used": device_label,
        "architecture": config["architecture"],
        "dataset_name": dataset_name,
        "dataset_source": dataset_source,
        "total_images_tested": len(pairs),
        "gallery_images_included": len(predictions),
        "confusion_matrix": {
            "tp": tp, "tn": tn, "fp": fp, "fn": fn, "total_pixels": total_pixels,
            "precision": precision, "recall": recall, "dice": dice, "iou": iou, "accuracy": accuracy,
        },
        "predictions": predictions,
    }
