"""
Results computation for SegLearn — Stage 8.

Given a checkpoint, computes:
  - a full-validation-set pixel-level confusion matrix (not just one batch)
  - a handful of sample predicted-vs-ground-truth image pairs for display
  - a summary report (config + metrics history + confusion matrix) that
    can be saved to disk as JSON

This intentionally re-evaluates the model fresh from its saved weights
rather than trusting any single epoch's validation metrics, so the
confusion matrix reflects the ENTIRE validation set accurately.
"""

import os
import io
import json
import base64
import numpy as np
from PIL import Image
import torch

import models as model_defs
from segmentation_dataset import build_dataloaders
from losses_metrics import compute_confusion_counts
from device_utils import resolve_device

from paths import get_persistent_data_root

REPORTS_ROOT = os.path.join(get_persistent_data_root(), "reports")


def _load_model_and_config(checkpoint_path, device):
    checkpoint = torch.load(checkpoint_path, weights_only=False, map_location="cpu")
    config = checkpoint["config"]
    model = model_defs.build_model(config["architecture"]).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, config, checkpoint


def compute_confusion_matrix(checkpoint_path, device_preference="auto"):
    """
    Run the model over its ENTIRE validation set and accumulate a pixel-level
    confusion matrix (true positive / true negative / false positive /
    false negative), plus derived precision/recall/dice/iou computed
    directly from those totals.
    """
    device, device_label = resolve_device(device_preference)
    model, config, _ = _load_model_and_config(checkpoint_path, device)

    _, val_loader, _ = build_dataloaders(
        config["dataset_name"], config["dataset_source"],
        image_size=config["image_size"], batch_size=config["batch_size"],
        val_split=config["val_split"], subset_size=config["subset_size"],
    )

    totals = {"tp": 0, "tn": 0, "fp": 0, "fn": 0}

    if val_loader is not None:
        with torch.no_grad():
            for images, masks in val_loader:
                images, masks = images.to(device), masks.to(device)
                logits = model(images)
                probs = torch.sigmoid(logits)
                counts = compute_confusion_counts(probs, masks)
                for k in totals:
                    totals[k] += counts[k]

    tp, tn, fp, fn = totals["tp"], totals["tn"], totals["fp"], totals["fn"]
    total_pixels = tp + tn + fp + fn

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    dice = (2 * tp) / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else 0.0
    iou = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0.0
    accuracy = (tp + tn) / total_pixels if total_pixels > 0 else 0.0

    return {
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "total_pixels": total_pixels,
        "precision": precision,
        "recall": recall,
        "dice": dice,
        "iou": iou,
        "accuracy": accuracy,
        "device_used": device_label,
    }


def _tensor_to_base64(tensor_2d, thumb_size=(150, 150)):
    arr = (tensor_2d.detach().cpu().numpy() * 255).clip(0, 255).astype(np.uint8)
    im = Image.fromarray(arr, mode="L")
    im.thumbnail(thumb_size)
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def get_sample_predictions(checkpoint_path, count=4, device_preference="auto"):
    """
    Return up to `count` (image, ground_truth, prediction) triples from
    the validation set, for the side-by-side comparison view.
    """
    device, _ = resolve_device(device_preference)
    model, config, _ = _load_model_and_config(checkpoint_path, device)

    _, val_loader, _ = build_dataloaders(
        config["dataset_name"], config["dataset_source"],
        image_size=config["image_size"], batch_size=config["batch_size"],
        val_split=config["val_split"], subset_size=config["subset_size"],
    )

    samples = []
    if val_loader is not None:
        with torch.no_grad():
            for images, masks in val_loader:
                images, masks = images.to(device), masks.to(device)
                logits = model(images)
                probs = torch.sigmoid(logits)
                pred_binary = (probs > 0.5).float()

                for i in range(images.shape[0]):
                    if len(samples) >= count:
                        break
                    samples.append({
                        "image": _tensor_to_base64(images[i, 0]),
                        "ground_truth": _tensor_to_base64(masks[i, 0]),
                        "prediction": _tensor_to_base64(pred_binary[i, 0]),
                    })
                if len(samples) >= count:
                    break

    return samples


def build_results_summary(checkpoint_path, sample_count=4, device_preference="auto"):
    """Everything the Results screen needs in one call."""
    checkpoint = torch.load(checkpoint_path, weights_only=False, map_location="cpu")
    config = checkpoint["config"]
    metrics_history = checkpoint["metrics_history"]

    confusion = compute_confusion_matrix(checkpoint_path, device_preference)
    samples = get_sample_predictions(checkpoint_path, sample_count, device_preference)

    return {
        "checkpoint_path": checkpoint_path,
        "epoch": checkpoint["epoch"],
        "config": config,
        "metrics_history": metrics_history,
        "confusion_matrix": confusion,
        "sample_predictions": samples,
    }


def save_report(checkpoint_path, device_preference="auto"):
    """
    Compute the results summary (excluding heavy sample images — a report
    is meant to be a lightweight record of config + metrics + confusion
    matrix, not an image dump) and save it as a JSON file in /reports/.
    Returns the filename and full path.
    """
    checkpoint = torch.load(checkpoint_path, weights_only=False, map_location="cpu")
    config = checkpoint["config"]
    metrics_history = checkpoint["metrics_history"]
    confusion = compute_confusion_matrix(checkpoint_path, device_preference)

    run_id = os.path.basename(os.path.dirname(checkpoint_path))
    epoch = checkpoint["epoch"]
    filename = f"{run_id}_epoch{epoch}_report.json"

    os.makedirs(REPORTS_ROOT, exist_ok=True)
    report_path = os.path.join(REPORTS_ROOT, filename)

    report = {
        "run_id": run_id,
        "epoch": epoch,
        "config": config,
        "metrics_history": metrics_history,
        "confusion_matrix": confusion,
    }

    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    return {"filename": filename, "path": report_path}
