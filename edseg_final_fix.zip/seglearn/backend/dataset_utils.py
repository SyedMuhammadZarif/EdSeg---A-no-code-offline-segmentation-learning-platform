"""
Dataset handling for SegLearn.

Responsibilities:
  - Discover bundled datasets under /datasets/<name>/{images,masks}
  - Validate an uploaded custom dataset (zip file) has the correct structure
  - Extract custom datasets into /datasets/custom/<name>/
  - Produce small base64-encoded previews of image/mask pairs for the UI

No PyTorch or training logic lives here — this stage is purely about
getting datasets in, validated, and previewable.
"""

import os
import io
import base64
import zipfile
import shutil
from PIL import Image

VALID_EXTENSIONS = {".png", ".jpg", ".jpeg"}

from paths import get_bundled_resource_root, get_persistent_data_root

DATASETS_ROOT = os.path.join(get_bundled_resource_root(), "datasets")
CUSTOM_ROOT = os.path.join(get_persistent_data_root(), "datasets", "custom")


class DatasetValidationError(Exception):
    """Raised when a dataset (bundled or custom) fails structural validation."""
    pass


def _list_valid_files(folder):
    """Return sorted list of valid image filenames in a folder."""
    if not os.path.isdir(folder):
        return []
    files = [
        f for f in os.listdir(folder)
        if os.path.splitext(f)[1].lower() in VALID_EXTENSIONS
    ]
    return sorted(files)


def validate_dataset_folder(dataset_path):
    """
    Validate that dataset_path contains images/ and masks/ subfolders
    with matching filenames (same basename, extension may differ).

    Returns: list of (image_filename, mask_filename) matched pairs.
    Raises: DatasetValidationError with a clear message if invalid.
    """
    images_dir = os.path.join(dataset_path, "images")
    masks_dir = os.path.join(dataset_path, "masks")

    if not os.path.isdir(images_dir):
        raise DatasetValidationError("Missing an 'images' folder.")
    if not os.path.isdir(masks_dir):
        raise DatasetValidationError("Missing a 'masks' folder.")

    image_files = _list_valid_files(images_dir)
    mask_files = _list_valid_files(masks_dir)

    if len(image_files) == 0:
        raise DatasetValidationError("The 'images' folder contains no valid image files (.png/.jpg/.jpeg).")
    if len(mask_files) == 0:
        raise DatasetValidationError("The 'masks' folder contains no valid image files (.png/.jpg/.jpeg).")

    # Match by basename (filename without extension) so images/masks.png vs .jpg both work
    image_basenames = {os.path.splitext(f)[0]: f for f in image_files}
    mask_basenames = {os.path.splitext(f)[0]: f for f in mask_files}

    image_only = sorted(set(image_basenames) - set(mask_basenames))
    mask_only = sorted(set(mask_basenames) - set(image_basenames))

    if image_only or mask_only:
        details = []
        if image_only:
            details.append(f"{len(image_only)} image(s) have no matching mask (e.g. '{image_only[0]}')")
        if mask_only:
            details.append(f"{len(mask_only)} mask(s) have no matching image (e.g. '{mask_only[0]}')")
        raise DatasetValidationError(
            "Images and masks don't match up: " + "; ".join(details) + "."
        )

    matched_basenames = sorted(set(image_basenames) & set(mask_basenames))
    pairs = [(image_basenames[b], mask_basenames[b]) for b in matched_basenames]

    # Confirm every file actually opens as an image (catches corrupt/renamed files)
    for img_name, mask_name in pairs:
        for name, folder in [(img_name, images_dir), (mask_name, masks_dir)]:
            path = os.path.join(folder, name)
            try:
                with Image.open(path) as im:
                    im.verify()
            except Exception:
                raise DatasetValidationError(f"'{name}' could not be read as a valid image file.")

    return pairs


def list_bundled_datasets():
    """
    Return metadata for all bundled datasets (folders directly under /datasets,
    excluding the 'custom' folder which holds uploads).
    """
    results = []
    if not os.path.isdir(DATASETS_ROOT):
        return results

    for entry in sorted(os.listdir(DATASETS_ROOT)):
        full_path = os.path.join(DATASETS_ROOT, entry)
        if entry == "custom" or not os.path.isdir(full_path):
            continue
        try:
            pairs = validate_dataset_folder(full_path)
            results.append({
                "name": entry,
                "display_name": entry.replace("_", " ").title(),
                "count": len(pairs),
                "source": "bundled",
            })
        except DatasetValidationError:
            # Skip broken bundled datasets rather than crashing the listing
            continue
    return results


def list_custom_datasets():
    """Return metadata for all previously uploaded custom datasets."""
    results = []
    if not os.path.isdir(CUSTOM_ROOT):
        return results

    for entry in sorted(os.listdir(CUSTOM_ROOT)):
        full_path = os.path.join(CUSTOM_ROOT, entry)
        if not os.path.isdir(full_path):
            continue
        try:
            pairs = validate_dataset_folder(full_path)
            results.append({
                "name": entry,
                "display_name": entry.replace("_", " ").title(),
                "count": len(pairs),
                "source": "custom",
            })
        except DatasetValidationError:
            continue
    return results


def resolve_dataset_path(name, source):
    """Given a dataset name and source ('bundled' or 'custom'), return its folder path."""
    if source == "custom":
        return os.path.join(CUSTOM_ROOT, name)
    return os.path.join(DATASETS_ROOT, name)


def get_preview(name, source, max_count=4):
    """
    Return a list of small base64-encoded (image, mask) pairs for display in the UI.
    """
    dataset_path = resolve_dataset_path(name, source)
    pairs = validate_dataset_folder(dataset_path)  # raises if invalid

    images_dir = os.path.join(dataset_path, "images")
    masks_dir = os.path.join(dataset_path, "masks")

    preview = []
    for img_name, mask_name in pairs[:max_count]:
        img_b64 = _image_to_base64(os.path.join(images_dir, img_name))
        mask_b64 = _image_to_base64(os.path.join(masks_dir, mask_name))
        preview.append({"image": img_b64, "mask": mask_b64, "filename": img_name})

    return {"pairs": preview, "total_count": len(pairs)}


def _image_to_base64(path, thumb_size=(150, 150)):
    """Load an image, downscale for preview, return as a base64 data URL."""
    with Image.open(path) as im:
        im = im.convert("L")
        im.thumbnail(thumb_size)
        buffer = io.BytesIO()
        im.save(buffer, format="PNG")
        encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
        return f"data:image/png;base64,{encoded}"


# Cap on total UNCOMPRESSED size a dataset zip is allowed to expand to.
# Checked independently of the compressed file size (which MAX_CONTENT_LENGTH
# already limits) specifically to catch "zip bombs" — a small compressed
# file crafted to decompress into something enormous, which could fill
# available disk space even though the upload itself looked small.
MAX_UNCOMPRESSED_ZIP_SIZE = 500 * 1024 * 1024  # 500MB


def _validate_zip_entries_are_safe(zf, target_dir):
    """
    Guard against two classic zip-upload risks before any extraction happens:

    1. "Zip slip" — a malicious zip whose internal entry names contain
       path-traversal sequences (e.g. "../../../Startup/evil.bat") that
       would make zipfile.extractall() write files OUTSIDE the intended
       target_dir, potentially overwriting arbitrary files on the
       student's computer. Python's zipfile module does not fully
       protect against this on its own.
    2. "Zip bombs" — a small compressed file crafted to decompress into
       an enormous amount of data, which could fill available disk space.
       Checked via the zip's own recorded uncompressed sizes (metadata
       read, not actual decompression) before extracting anything.

    If anything looks unsafe, the whole upload is rejected rather than
    partially extracted.
    """
    target_dir_abs = os.path.abspath(target_dir)
    total_uncompressed_size = 0

    for info in zf.infolist():
        member_path_abs = os.path.abspath(os.path.join(target_dir, info.filename))
        if not (member_path_abs == target_dir_abs or member_path_abs.startswith(target_dir_abs + os.sep)):
            raise DatasetValidationError(
                "This zip file contains an entry with an unsafe path and was rejected "
                "for your safety. Please re-zip your dataset with only images/ and masks/ "
                "folders at the top level."
            )
        total_uncompressed_size += info.file_size

    if total_uncompressed_size > MAX_UNCOMPRESSED_ZIP_SIZE:
        raise DatasetValidationError(
            f"This zip would expand to more than "
            f"{MAX_UNCOMPRESSED_ZIP_SIZE // (1024*1024)}MB, which is larger than "
            f"this app expects for a training dataset. Please use a smaller dataset."
        )


def save_uploaded_zip(file_storage, dataset_name):
    """
    Extract an uploaded zip file (Flask FileStorage) into
    /datasets/custom/<dataset_name>/, validate it, and return its metadata.

    Raises DatasetValidationError if the zip's contents are invalid, and
    cleans up the extracted folder in that case so the app doesn't accumulate
    broken datasets.
    """
    safe_name = "".join(c for c in dataset_name if c.isalnum() or c in ("-", "_")).strip()
    if not safe_name:
        raise DatasetValidationError("Dataset name must contain at least one letter or number.")

    os.makedirs(CUSTOM_ROOT, exist_ok=True)
    target_dir = os.path.join(CUSTOM_ROOT, safe_name)

    if os.path.exists(target_dir):
        raise DatasetValidationError(
            f"A dataset named '{safe_name}' already exists. Choose a different name, "
            f"or delete the existing one first if you meant to replace it."
        )
    os.makedirs(target_dir)

    try:
        with zipfile.ZipFile(file_storage) as zf:
            _validate_zip_entries_are_safe(zf, target_dir)
            zf.extractall(target_dir)
    except zipfile.BadZipFile:
        shutil.rmtree(target_dir, ignore_errors=True)
        raise DatasetValidationError("The uploaded file is not a valid .zip archive.")
    except DatasetValidationError:
        shutil.rmtree(target_dir, ignore_errors=True)
        raise

    # Handle the common case where the zip contains a single wrapper folder,
    # e.g. myDataset.zip -> myDataset/images/... instead of images/... at the root.
    entries = [e for e in os.listdir(target_dir) if not e.startswith("__MACOSX")]
    if len(entries) == 1 and os.path.isdir(os.path.join(target_dir, entries[0])):
        wrapper = os.path.join(target_dir, entries[0])
        if os.path.isdir(os.path.join(wrapper, "images")) and os.path.isdir(os.path.join(wrapper, "masks")):
            for item in os.listdir(wrapper):
                shutil.move(os.path.join(wrapper, item), os.path.join(target_dir, item))
            shutil.rmtree(wrapper, ignore_errors=True)

    try:
        pairs = validate_dataset_folder(target_dir)
    except DatasetValidationError:
        shutil.rmtree(target_dir, ignore_errors=True)
        raise

    return {
        "name": safe_name,
        "display_name": safe_name.replace("_", " ").title(),
        "count": len(pairs),
        "source": "custom",
    }
