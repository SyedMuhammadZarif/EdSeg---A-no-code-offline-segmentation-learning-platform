"""
Sweep persistence for EdSeg.

Hyperparameter sweeps (Stage 9) previously only existed in job_manager's
in-memory _TUNING_JOBS dict — they vanished the moment the app restarted,
and there was no way to browse a past sweep once you navigated away from
its live results screen. This module fixes that by writing a JSON record
of every sweep to disk (next to checkpoints/models/reports, using the
same persistent-data-root convention from paths.py), so sweeps survive
restarts and can be listed/reopened like saved models.

Note: a sweep's record is written once it finishes (completes, stops, or
errors) — if the app crashes mid-sweep, the grouping record for that
specific sweep is lost, but every individual trial's checkpoint is still
safe on disk regardless (checkpoints are saved independently per-trial
as they always have been).
"""

import os
import json
from datetime import datetime

from paths import get_persistent_data_root

SWEEPS_ROOT = os.path.join(get_persistent_data_root(), "sweeps")


def save_sweep_record(tuning_id, sweep_params, trials, status, meta=None):
    """
    Write a sweep's full record to disk. Called once a sweep finishes
    (completed/stopped/error), from job_manager's tuning job runner.
    """
    os.makedirs(SWEEPS_ROOT, exist_ok=True)

    record = {
        "sweep_id": tuning_id,
        "sweep_params": sweep_params,
        "status": status,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "trials": trials,
        "meta": meta or {},
    }

    path = os.path.join(SWEEPS_ROOT, f"{tuning_id}.json")
    with open(path, "w") as f:
        json.dump(record, f, indent=2)

    return path


def list_sweeps():
    """List all saved sweeps, most recent first, with light summary info."""
    if not os.path.isdir(SWEEPS_ROOT):
        return []

    results = []
    for filename in sorted(os.listdir(SWEEPS_ROOT), reverse=True):
        if not filename.endswith(".json"):
            continue
        try:
            with open(os.path.join(SWEEPS_ROOT, filename)) as f:
                record = json.load(f)
            completed = [t for t in record["trials"] if t.get("status") == "completed"]
            best_dice = None
            if completed:
                dices = [t["final_metrics"].get("val_dice") for t in completed if t.get("final_metrics")]
                dices = [d for d in dices if d is not None]
                if dices:
                    best_dice = max(dices)
            results.append({
                "sweep_id": record["sweep_id"],
                "sweep_params": record["sweep_params"],
                "status": record["status"],
                "created_at": record["created_at"],
                "trial_count": len(record["trials"]),
                "best_val_dice": best_dice,
            })
        except Exception:
            continue  # skip unreadable/corrupt sweep files
    return results


def _resolve_sweep_path(sweep_id):
    """
    Resolve a sweep_id to its JSON file path, validating the result stays
    inside SWEEPS_ROOT. Flask's default URL routing already rejects a
    literal "/" in this parameter, but that protection is incidental to
    the web framework, not this function — validating explicitly here
    (the same pattern already used for checkpoint deletion) means this
    stays safe even if called some other way, and isn't silently
    dependent on a routing detail that could change. In particular, a
    sweep_id containing backslashes wouldn't be caught by Flask's
    forward-slash-only routing protection but WOULD be interpreted as a
    path separator by the filesystem on Windows.
    """
    path = os.path.abspath(os.path.join(SWEEPS_ROOT, f"{sweep_id}.json"))
    sweeps_root_abs = os.path.abspath(SWEEPS_ROOT)
    if not path.startswith(sweeps_root_abs + os.sep):
        raise ValueError("Invalid sweep id.")
    return path


def get_sweep(sweep_id):
    """Load one sweep's full record, or None if it doesn't exist."""
    path = _resolve_sweep_path(sweep_id)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def delete_sweep(sweep_id):
    """Delete a sweep's record (does NOT delete the underlying trial checkpoints)."""
    path = _resolve_sweep_path(sweep_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Sweep record not found: {sweep_id}")
    os.remove(path)
