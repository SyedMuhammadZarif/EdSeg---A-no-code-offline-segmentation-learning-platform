"""
Stage 3 verification script.

Runs a real training job on the bundled sample_shapes dataset using the
smallest model (Mini U-Net) for 10 epochs, and checks:
  - Training completes without error
  - Training loss decreases from epoch 1 to epoch 10 (sanity check that
    learning is actually happening, not just running)
  - Checkpoint files exist at epoch 5 and epoch 10
  - Each checkpoint contains the expected keys and metadata

Run with:
    python backend/scripts/test_training.py
"""

import sys
import os
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from train import train_model, CHECKPOINTS_ROOT

TEST_RUN_ID = "stage3_verification_run"


def main():
    # Clean up any previous test run so this is a fresh check
    test_run_dir = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID)
    if os.path.exists(test_run_dir):
        shutil.rmtree(test_run_dir)

    print("Starting a real training run: mini_unet on sample_shapes, 10 epochs...")
    print("(This uses a small subset of images to keep the test itself fast.)\n")

    def print_progress(epoch_metrics):
        print(
            f"  Epoch {epoch_metrics['epoch']:2d} | "
            f"train_loss={epoch_metrics['train_loss']:.4f} | "
            f"val_loss={epoch_metrics['val_loss']:.4f} | "
            f"val_dice={epoch_metrics['val_dice']:.4f} | "
            f"val_iou={epoch_metrics['val_iou']:.4f} | "
            f"{epoch_metrics['epoch_seconds']:.2f}s"
        )

    result = train_model(
        dataset_name="sample_shapes",
        dataset_source="bundled",
        model_name="mini_unet",
        learning_rate=1e-3,
        epochs=10,
        batch_size=4,
        val_split=0.25,
        subset_size=16,
        device_preference="cpu",
        checkpoint_every=5,
        run_id=TEST_RUN_ID,
        progress_callback=print_progress,
    )

    print(f"\nTraining complete. Device used: {result['device_used']}")
    print(f"Run ID: {result['run_id']}")

    checks_passed = True

    # Check 1: loss decreased
    first_loss = result["metrics_history"][0]["train_loss"]
    last_loss = result["metrics_history"][-1]["train_loss"]
    loss_decreased = last_loss < first_loss
    print(f"\n[Check 1] Training loss decreased: {first_loss:.4f} -> {last_loss:.4f} "
          f"-> {'PASS' if loss_decreased else 'FAIL'}")
    checks_passed &= loss_decreased

    # Check 2: checkpoint files exist at epoch 5 and 10
    epoch5_path = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID, "epoch_5.pt")
    epoch10_path = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID, "epoch_10.pt")
    epoch5_exists = os.path.exists(epoch5_path)
    epoch10_exists = os.path.exists(epoch10_path)
    print(f"[Check 2] Checkpoint at epoch 5 exists: {'PASS' if epoch5_exists else 'FAIL'}")
    print(f"[Check 2] Checkpoint at epoch 10 exists: {'PASS' if epoch10_exists else 'FAIL'}")
    checks_passed &= epoch5_exists and epoch10_exists

    # Check 3: checkpoint contents are correct
    if epoch5_exists:
        ckpt = torch.load(epoch5_path, weights_only=False)
        has_keys = all(k in ckpt for k in ["epoch", "model_state_dict", "optimizer_state_dict", "config", "metrics_history"])
        correct_epoch = ckpt["epoch"] == 5
        correct_arch = ckpt["config"]["architecture"] == "mini_unet"
        correct_dataset = ckpt["config"]["dataset_name"] == "sample_shapes"
        print(f"[Check 3] Epoch-5 checkpoint has all expected keys: {'PASS' if has_keys else 'FAIL'}")
        print(f"[Check 3] Epoch-5 checkpoint records epoch=5: {'PASS' if correct_epoch else 'FAIL'}")
        print(f"[Check 3] Epoch-5 checkpoint records correct architecture/dataset: "
              f"{'PASS' if (correct_arch and correct_dataset) else 'FAIL'}")
        checks_passed &= has_keys and correct_epoch and correct_arch and correct_dataset

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")

    # Check 4: Dice and IoU should move consistently with each other, since
    # both are now computed on thresholded predictions. This is really a
    # sanity check on the metric implementations rather than the training
    # run itself. Dice is mathematically always >= IoU, and they should be
    # close to each other especially as IoU is not extreme.
    last_metrics = result["metrics_history"][-1]
    dice_val, iou_val = last_metrics["val_dice"], last_metrics["val_iou"]
    dice_ge_iou = dice_val >= iou_val - 1e-6
    print(f"\n[Check 4] Final-epoch Dice ({dice_val:.4f}) >= IoU ({iou_val:.4f}) "
          f"(should always hold mathematically): {'PASS' if dice_ge_iou else 'FAIL'}")


if __name__ == "__main__":
    main()
