"""
Generates a small synthetic "sample_shapes" dataset to stand in for a real
medical imaging dataset (chest X-ray / CT / MRI slice) during development.

Each image is a 128x128 grayscale image with a random blob (circle or
ellipse) on a noisy background. Each mask is a binary image marking exactly
where that blob is. This mimics the real structure a medical dataset would
have (one image, one matching binary segmentation mask) without needing
real clinical data or internet access.

Run this once to (re)generate the bundled dataset:
    python backend/scripts/generate_sample_dataset.py
"""

import os
import random
from PIL import Image, ImageDraw
import numpy as np

IMG_SIZE = 128
NUM_SAMPLES = 24

OUTPUT_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "datasets", "sample_shapes"
)
IMAGES_DIR = os.path.join(OUTPUT_ROOT, "images")
MASKS_DIR = os.path.join(OUTPUT_ROOT, "masks")


def generate_pair(seed):
    rng = random.Random(seed)

    # Noisy grayscale background (simulates tissue/background texture)
    noise = (np.random.default_rng(seed).normal(loc=60, scale=15, size=(IMG_SIZE, IMG_SIZE)))
    noise = np.clip(noise, 0, 255).astype(np.uint8)
    image = Image.fromarray(noise, mode="L")
    draw = ImageDraw.Draw(image)

    mask = Image.new("L", (IMG_SIZE, IMG_SIZE), 0)
    mask_draw = ImageDraw.Draw(mask)

    # Random blob (ellipse) location/size, brighter than background
    cx = rng.randint(35, IMG_SIZE - 35)
    cy = rng.randint(35, IMG_SIZE - 35)
    rx = rng.randint(15, 30)
    ry = rng.randint(15, 30)
    brightness = rng.randint(170, 230)

    bbox = [cx - rx, cy - ry, cx + rx, cy + ry]
    draw.ellipse(bbox, fill=brightness)
    mask_draw.ellipse(bbox, fill=255)

    return image, mask


def main():
    os.makedirs(IMAGES_DIR, exist_ok=True)
    os.makedirs(MASKS_DIR, exist_ok=True)

    for i in range(NUM_SAMPLES):
        image, mask = generate_pair(seed=i)
        filename = f"sample_{i:03d}.png"
        image.save(os.path.join(IMAGES_DIR, filename))
        mask.save(os.path.join(MASKS_DIR, filename))

    print(f"Generated {NUM_SAMPLES} image/mask pairs in:\n  {IMAGES_DIR}\n  {MASKS_DIR}")


if __name__ == "__main__":
    main()
