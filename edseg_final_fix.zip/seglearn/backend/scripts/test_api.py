"""
Stage 5 verification script.

Exercises every API endpoint built in this stage, using Flask's test
client (in-process — no need to run a separate server). Covers:
  - dataset listing/preview (Stage 1, sanity check it's still wired)
  - architecture + device listing
  - starting a training job, polling status until completion
  - stopping a job early
  - listing checkpoints
  - resuming from a checkpoint via the API
  - saving a checkpoint as a named model, listing saved models
  - running inference with a saved model

Run with:
    python backend/scripts/test_api.py
"""

import sys
import os
import time
import shutil
import io

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app
from train import CHECKPOINTS_ROOT
from model_library import MODELS_ROOT

TEST_RUN_PREFIX = "stage5_test"


def cleanup():
    for entry in os.listdir(CHECKPOINTS_ROOT) if os.path.isdir(CHECKPOINTS_ROOT) else []:
        if TEST_RUN_PREFIX in entry or entry.startswith("job_"):
            shutil.rmtree(os.path.join(CHECKPOINTS_ROOT, entry), ignore_errors=True)
    for entry in os.listdir(MODELS_ROOT) if os.path.isdir(MODELS_ROOT) else []:
        if entry.startswith("stage5"):
            os.remove(os.path.join(MODELS_ROOT, entry))


def wait_for_completion(client, run_id, timeout=60):
    start = time.time()
    while time.time() - start < timeout:
        resp = client.get(f"/api/train/status/{run_id}")
        data = resp.get_json()
        if data["status"] in ("completed", "stopped", "error"):
            return data
        time.sleep(0.2)
    raise TimeoutError(f"Run {run_id} did not finish within {timeout}s")


def main():
    cleanup()
    checks_passed = True
    client = app.test_client()

    # --- Basic connectivity ---
    resp = client.get("/api/ping")
    ok = resp.status_code == 200 and resp.get_json()["status"] == "ok"
    print(f"[Check 1] /api/ping -> {'PASS' if ok else 'FAIL'}")
    checks_passed &= ok

    # --- Datasets still wired ---
    resp = client.get("/api/datasets")
    datasets = resp.get_json()["datasets"]
    has_sample = any(d["name"] == "sample_shapes" for d in datasets)
    print(f"[Check 2] /api/datasets includes bundled 'sample_shapes' -> {'PASS' if has_sample else 'FAIL'}")
    checks_passed &= has_sample

    # --- Architectures & devices ---
    resp = client.get("/api/models/architectures")
    architectures = resp.get_json()["architectures"]
    has_four = len(architectures) == 4
    print(f"[Check 3] /api/models/architectures returns 4 models -> {'PASS' if has_four else 'FAIL'}")
    checks_passed &= has_four

    resp = client.get("/api/devices")
    devices = resp.get_json()
    has_cpu = devices.get("cpu") is True
    print(f"[Check 4] /api/devices reports cpu=True -> {'PASS' if has_cpu else 'FAIL'}")
    checks_passed &= has_cpu

    # --- Start a training job and poll until completion ---
    print("\nStarting a training job via the API (mini_unet, sample_shapes, 6 epochs)...")
    resp = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes",
        "dataset_source": "bundled",
        "model_name": "mini_unet",
        "learning_rate": 1e-3,
        "epochs": 6,
        "batch_size": 4,
        "val_split": 0.25,
        "subset_size": 16,
        "device_preference": "cpu",
        "checkpoint_every": 5,
    })
    start_ok = resp.status_code == 200 and "run_id" in resp.get_json()
    run_id = resp.get_json().get("run_id")
    print(f"[Check 5] /api/train/start returns a run_id -> {'PASS' if start_ok else 'FAIL'} (run_id={run_id})")
    checks_passed &= start_ok

    final_status = wait_for_completion(client, run_id)
    completed_ok = final_status["status"] == "completed" and len(final_status["metrics_so_far"]) == 6
    print(f"[Check 6] Job completes with 6 epochs of metrics recorded -> {'PASS' if completed_ok else 'FAIL'}")
    checks_passed &= completed_ok

    # --- Checkpoints list includes this run ---
    resp = client.get("/api/checkpoints")
    checkpoints = resp.get_json()["checkpoints"]
    this_run_checkpoints = [c for c in checkpoints if c["run_id"] == run_id]
    has_checkpoint = len(this_run_checkpoints) >= 1
    print(f"[Check 7] /api/checkpoints includes a checkpoint for this run -> {'PASS' if has_checkpoint else 'FAIL'}")
    checks_passed &= has_checkpoint

    checkpoint_path = this_run_checkpoints[0]["path"] if this_run_checkpoints else None

    # --- Start a second job and stop it early ---
    print("\nStarting a second job to test stopping mid-run...")
    resp = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes",
        "dataset_source": "bundled",
        "model_name": "mini_unet",
        "epochs": 20,
        "batch_size": 4,
        "subset_size": 16,
        "device_preference": "cpu",
    })
    stop_run_id = resp.get_json()["run_id"]
    time.sleep(0.5)  # let it start training
    resp = client.post(f"/api/train/stop/{stop_run_id}")
    stop_request_ok = resp.status_code == 200
    stopped_status = wait_for_completion(client, stop_run_id, timeout=30)
    stopped_ok = stopped_status["status"] == "stopped" and len(stopped_status["metrics_so_far"]) < 20
    print(f"[Check 8] Stop request accepted and job status becomes 'stopped' before all epochs run -> "
          f"{'PASS' if (stop_request_ok and stopped_ok) else 'FAIL'} "
          f"(completed {len(stopped_status['metrics_so_far'])}/20 epochs)")
    checks_passed &= stop_request_ok and stopped_ok

    # --- Resume from checkpoint via API ---
    if checkpoint_path:
        print(f"\nResuming from checkpoint via API: {checkpoint_path}")
        resp = client.post("/api/train/resume", json={
            "checkpoint_path": checkpoint_path,
            "additional_epochs": 2,
            "expected_architecture": "mini_unet",
            "expected_dataset_name": "sample_shapes",
            "expected_dataset_source": "bundled",
            "device_preference": "cpu",
        })
        resume_ok = resp.status_code == 200 and "run_id" in resp.get_json()
        resume_run_id = resp.get_json().get("run_id") if resume_ok else None
        print(f"[Check 9] /api/train/resume returns a run_id -> {'PASS' if resume_ok else 'FAIL'}")
        checks_passed &= resume_ok

        if resume_ok:
            resume_status = wait_for_completion(client, resume_run_id)
            resume_completed_ok = resume_status["status"] == "completed"
            print(f"[Check 10] Resumed job completes successfully -> {'PASS' if resume_completed_ok else 'FAIL'}")
            checks_passed &= resume_completed_ok

        # --- Mismatch case via API ---
        print("\nAttempting a mismatched resume via API (wrong architecture)...")
        resp = client.post("/api/train/resume", json={
            "checkpoint_path": checkpoint_path,
            "additional_epochs": 2,
            "expected_architecture": "standard_mini_unet",
        })
        mismatch_rejected = resp.status_code == 400
        print(f"[Check 11] Mismatched resume rejected with 400 -> {'PASS' if mismatch_rejected else 'FAIL'} "
              f"(message: {resp.get_json().get('error')})")
        checks_passed &= mismatch_rejected

    # --- Save a model, list models ---
    if checkpoint_path:
        print("\nSaving the checkpoint as a named model...")
        resp = client.post("/api/model/save", json={
            "checkpoint_path": checkpoint_path,
            "name": "stage5_test_model",
        })
        save_ok = resp.status_code == 200 and "model" in resp.get_json()
        print(f"[Check 12] /api/model/save succeeds -> {'PASS' if save_ok else 'FAIL'}")
        checks_passed &= save_ok

        resp = client.get("/api/models")
        models = resp.get_json()["models"]
        has_saved_model = any(m["name"] == "stage5_test_model" for m in models)
        print(f"[Check 13] /api/models lists the saved model -> {'PASS' if has_saved_model else 'FAIL'}")
        checks_passed &= has_saved_model

        # --- Inference on a new image ---
        print("\nRunning inference with the saved model on a sample image...")
        sample_image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "..", "datasets", "sample_shapes", "images", "sample_000.png"
        )
        sample_mask_path = sample_image_path.replace("images", "masks")

        with open(sample_image_path, "rb") as img_f, open(sample_mask_path, "rb") as mask_f:
            resp = client.post("/api/inference", data={
                "model_name": "stage5_test_model",
                "image": (io.BytesIO(img_f.read()), "test_image.png"),
                "mask": (io.BytesIO(mask_f.read()), "test_mask.png"),
                "device_preference": "cpu",
            }, content_type="multipart/form-data")

        inference_data = resp.get_json()
        inference_ok = resp.status_code == 200 and "predicted_mask" in inference_data and "dice" in inference_data
        print(f"[Check 14] /api/inference returns a predicted mask + Dice/IoU -> "
              f"{'PASS' if inference_ok else 'FAIL'}")
        if inference_ok:
            print(f"    dice={inference_data['dice']:.4f}, iou={inference_data['iou']:.4f}")
        checks_passed &= inference_ok

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")

    cleanup()


if __name__ == "__main__":
    main()
