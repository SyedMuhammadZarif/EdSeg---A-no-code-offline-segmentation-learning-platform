"""
Stage 9 verification script (grid search version).

Tests:
  1. compute_grid_combinations() produces the mathematically correct
     Cartesian product for a known multi-parameter input (checked by hand).
  2. A small 2-parameter grid sweep (2 learning rates x 2 batch sizes = 4
     trials) actually runs 4 trials, each individually inspectable with
     its own checkpoint and the correct combination of values applied.
  3. Requesting more parameters than MAX_PARAMS_TO_SWEEP gets clamped.
  4. Requesting more total trials than MAX_TOTAL_TRIALS gets clamped
     (tested with a combination count that would otherwise exceed it).
  5. Requesting more epochs than MAX_EPOCHS_PER_TRIAL gets clamped.
  6. Total wall-clock runtime for a small grid stays within a reasonable
     bound — the main risk with grid search specifically, since
     combinations multiply fast.
  7. Stopping a sweep mid-run actually stops it early.

Run with:
    python backend/scripts/test_tuning.py
"""

import sys
import os
import time
import shutil
import threading

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tuning import (
    run_sweep, compute_grid_combinations,
    MAX_PARAMS_TO_SWEEP, MAX_VALUES_PER_PARAM, MAX_TOTAL_TRIALS, MAX_EPOCHS_PER_TRIAL,
)
from train import CHECKPOINTS_ROOT


def cleanup_tuning_checkpoints():
    if not os.path.isdir(CHECKPOINTS_ROOT):
        return
    for entry in os.listdir(CHECKPOINTS_ROOT):
        if entry.startswith("tune_"):
            shutil.rmtree(os.path.join(CHECKPOINTS_ROOT, entry), ignore_errors=True)


def main():
    cleanup_tuning_checkpoints()
    checks_passed = True

    # --- Check 1: Cartesian product math is correct ---
    print("Checking grid combination math against a hand-computed expectation...")
    grid_info = compute_grid_combinations([
        {"param": "learning_rate", "values": [0.001, 0.005]},
        {"param": "batch_size", "values": [4, 8]},
    ])
    combos = grid_info["combinations"]
    expected_combos = [
        {"learning_rate": 0.001, "batch_size": 4},
        {"learning_rate": 0.001, "batch_size": 8},
        {"learning_rate": 0.005, "batch_size": 4},
        {"learning_rate": 0.005, "batch_size": 8},
    ]
    combos_correct = combos == expected_combos
    print(f"  Got:      {combos}")
    print(f"  Expected: {expected_combos}")
    print(f"[Check 1] 2x2 grid produces the exact expected 4 combinations, in order -> "
          f"{'PASS' if combos_correct else 'FAIL'}")
    checks_passed &= combos_correct

    base_config = {
        "dataset_name": "sample_shapes",
        "dataset_source": "bundled",
        "model_name": "mini_unet",
        "batch_size": 4,
        "val_split": 0.25,
        "subset_size": 16,
        "device_preference": "cpu",
        "epochs": 4,
    }

    # --- Check 2: a real 2x2 grid sweep runs 4 distinct, inspectable trials ---
    print("\nRunning a real 2x2 grid sweep (2 learning rates x 2 batch sizes)...")
    start_time = time.time()
    summary = run_sweep(
        base_config,
        sweep_params=[
            {"param": "learning_rate", "values": [0.001, 0.005]},
            {"param": "batch_size", "values": [4, 8]},
        ],
    )
    elapsed = time.time() - start_time

    trials = summary["trials"]
    correct_trial_count = len(trials) == 4
    distinct_run_ids = len({t["run_id"] for t in trials}) == 4
    all_have_checkpoints = all(t["checkpoint_path"] and os.path.exists(t["checkpoint_path"]) for t in trials)
    correct_combos_applied = [t["sweep_values"] for t in trials] == expected_combos

    print(f"[Check 2] Ran 4 trials -> {'PASS' if correct_trial_count else 'FAIL'}")
    print(f"[Check 2] Each trial has a distinct run_id -> {'PASS' if distinct_run_ids else 'FAIL'}")
    print(f"[Check 2] Each trial's checkpoint file exists on disk -> {'PASS' if all_have_checkpoints else 'FAIL'}")
    print(f"[Check 2] Each trial's applied combination matches the grid exactly -> "
          f"{'PASS' if correct_combos_applied else 'FAIL'}")
    checks_passed &= correct_trial_count and distinct_run_ids and all_have_checkpoints and correct_combos_applied

    for t in trials:
        fm = t["final_metrics"]
        print(f"    {t['sweep_values']}: final train_loss={fm.get('train_loss'):.4f}")

    # --- Check 3: total runtime for the grid stays bounded ---
    RUNTIME_BUDGET_SECONDS = 90  # generous for 4 tiny trials of 4 epochs each
    runtime_ok = elapsed < RUNTIME_BUDGET_SECONDS
    print(f"\n[Check 3] Total grid sweep runtime ({elapsed:.1f}s) stays under budget "
          f"({RUNTIME_BUDGET_SECONDS}s) -> {'PASS' if runtime_ok else 'FAIL'}")
    checks_passed &= runtime_ok
    cleanup_tuning_checkpoints()

    # --- Check 4: too many swept parameters gets clamped ---
    print(f"\nRequesting {MAX_PARAMS_TO_SWEEP + 2} parameters to sweep at once (cap is {MAX_PARAMS_TO_SWEEP})...")
    too_many_params = [
        {"param": "learning_rate", "values": [0.001]},
        {"param": "batch_size", "values": [4]},
        {"param": "subset_size", "values": [8]},
        {"param": "architecture", "values": ["mini_unet"]},
        {"param": "learning_rate", "values": [0.005]},  # deliberately excessive
    ]
    grid_info2 = compute_grid_combinations(too_many_params)
    params_clamped_correctly = (
        grid_info2["params_were_clamped"] is True and
        grid_info2["requested_param_count"] == len(too_many_params)
    )
    print(f"[Check 4] Excess sweep parameters correctly flagged as clamped -> "
          f"{'PASS' if params_clamped_correctly else 'FAIL'}")
    checks_passed &= params_clamped_correctly

    # --- Check 5: total trial count gets clamped even with valid param count ---
    print(f"\nRequesting a grid that would produce more than {MAX_TOTAL_TRIALS} total trials...")
    big_grid_params = [
        {"param": "learning_rate", "values": [0.0001, 0.0005, 0.001, 0.005]},  # 4 values
        {"param": "batch_size", "values": [4, 8, 16]},  # 3 values -> 12 combos, over the cap of 9
    ]
    grid_info3 = compute_grid_combinations(big_grid_params)
    trial_clamp_correct = (
        len(grid_info3["combinations"]) == MAX_TOTAL_TRIALS and
        grid_info3["trials_were_clamped"] is True and
        grid_info3["requested_total_trials"] == 12
    )
    print(f"[Check 5] Total trials clamped to {MAX_TOTAL_TRIALS} (requested 12) -> "
          f"{'PASS' if trial_clamp_correct else 'FAIL'} "
          f"(actual: {len(grid_info3['combinations'])} combinations)")
    checks_passed &= trial_clamp_correct

    # --- Check 6: epoch count gets clamped ---
    print(f"\nRequesting {MAX_EPOCHS_PER_TRIAL + 20} epochs per trial (cap is {MAX_EPOCHS_PER_TRIAL})...")
    summary3 = run_sweep(
        {**base_config, "epochs": MAX_EPOCHS_PER_TRIAL + 20},
        sweep_params=[{"param": "batch_size", "values": [4]}],  # just one trial, keep this fast
    )
    epoch_clamped_correctly = (
        summary3["epochs_used"] == MAX_EPOCHS_PER_TRIAL and
        summary3["epochs_were_clamped"] is True and
        summary3["trials"][0]["final_metrics"]["epoch"] == MAX_EPOCHS_PER_TRIAL
    )
    print(f"[Check 6] Epochs-per-trial clamped to {MAX_EPOCHS_PER_TRIAL} -> "
          f"{'PASS' if epoch_clamped_correctly else 'FAIL'}")
    checks_passed &= epoch_clamped_correctly
    cleanup_tuning_checkpoints()

    # --- Check 7: stopping a sweep partway through actually stops it ---
    print("\nStarting a sweep and stopping it after the first trial...")
    stop_event = threading.Event()

    def on_trial_complete(i, trial_result):
        if i == 0:
            stop_event.set()

    summary4 = run_sweep(
        {**base_config, "epochs": 3},
        sweep_params=[{"param": "learning_rate", "values": [0.001, 0.005, 0.01]}],  # 3 requested
        on_trial_complete=on_trial_complete,
        stop_event=stop_event,
    )
    stopped_correctly = 1 <= len(summary4["trials"]) < 3
    print(f"[Check 7] Sweep stopped early (ran {len(summary4['trials'])}/3 requested trials) -> "
          f"{'PASS' if stopped_correctly else 'FAIL'}")
    checks_passed &= stopped_correctly
    cleanup_tuning_checkpoints()

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")


if __name__ == "__main__":
    main()
