"""
Stage 8 verification script.

Trains a quick model, then verifies:
  1. The confusion matrix's tp+tn+fp+fn equals the total pixel count of
     the whole validation set (sanity check on aggregation).
  2. An INDEPENDENTLY re-implemented confusion-matrix computation (written
     fresh here, not reusing losses_metrics.compute_confusion_counts)
     produces IDENTICAL tp/tn/fp/fn numbers to results.compute_confusion_matrix.
     This directly tests the acceptance criterion: "confirm confusion
     matrix values are correct (spot-check against manual pixel counts)".
  3. Derived metrics (precision, recall, dice, iou, accuracy) are
     correctly computed from the confusion totals using their standard
     formulas, checked by hand here too.
  4. get_sample_predictions returns valid, correctly shaped image data.
  5. save_report writes a JSON file whose confusion matrix numbers exactly
     match what compute_confusion_matrix returned directly (no drift
     between what's shown live and what's saved to disk).

Run with:
    python backend/scripts/test_results.py
"""

import sys
import os
import shutil
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from train import train_model, CHECKPOINTS_ROOT
from segmentation_dataset import build_dataloaders
from device_utils import resolve_device
import models as model_defs
import results as results_module

TEST_RUN_ID = "stage8_verification_run"


def independent_confusion_matrix(checkpoint_path):
    """
    A from-scratch re-implementation of the confusion matrix computation,
    deliberately written differently (manual pixel loop reasoning via
    boolean masks, iterating batches independently) from results.py's
    version, to catch any bugs that a copy-pasted check would miss.
    """
    checkpoint = torch.load(checkpoint_path, weights_only=False, map_location="cpu")
    config = checkpoint["config"]
    device, _ = resolve_device("cpu")

    model = model_defs.build_model(config["architecture"]).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    _, val_loader, _ = build_dataloaders(
        config["dataset_name"], config["dataset_source"],
        image_size=config["image_size"], batch_size=config["batch_size"],
        val_split=config["val_split"], subset_size=config["subset_size"],
    )

    tp = tn = fp = fn = 0
    total_pixels_seen = 0

    with torch.no_grad():
        for images, masks in val_loader:
            logits = model(images)
            probs = torch.sigmoid(logits)
            predicted_positive = probs > 0.5
            actual_positive = masks > 0.5

            tp += int(torch.sum(predicted_positive & actual_positive).item())
            tn += int(torch.sum((~predicted_positive) & (~actual_positive)).item())
            fp += int(torch.sum(predicted_positive & (~actual_positive)).item())
            fn += int(torch.sum((~predicted_positive) & actual_positive).item())
            total_pixels_seen += masks.numel()

    return {"tp": tp, "tn": tn, "fp": fp, "fn": fn, "total_pixels_seen": total_pixels_seen}


def main():
    test_run_dir = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID)
    if os.path.exists(test_run_dir):
        shutil.rmtree(test_run_dir)

    checks_passed = True

    print("Training a quick model (mini_unet, sample_shapes, 8 epochs)...")
    result = train_model(
        dataset_name="sample_shapes",
        dataset_source="bundled",
        model_name="mini_unet",
        learning_rate=1e-3,
        epochs=8,
        batch_size=4,
        val_split=0.25,
        subset_size=16,
        device_preference="cpu",
        checkpoint_every=5,
        run_id=TEST_RUN_ID,
    )
    checkpoint_path = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID, "epoch_8.pt")
    print(f"Training complete. Checkpoint: {checkpoint_path}\n")

    # --- Check 1 & 2: confusion matrix correctness ---
    print("Computing confusion matrix via results.py...")
    official = results_module.compute_confusion_matrix(checkpoint_path, device_preference="cpu")

    print("Independently re-computing confusion matrix from scratch...")
    manual = independent_confusion_matrix(checkpoint_path)

    tp_match = official["tp"] == manual["tp"]
    tn_match = official["tn"] == manual["tn"]
    fp_match = official["fp"] == manual["fp"]
    fn_match = official["fn"] == manual["fn"]
    all_match = tp_match and tn_match and fp_match and fn_match

    print(f"\n  results.py:    tp={official['tp']}, tn={official['tn']}, fp={official['fp']}, fn={official['fn']}")
    print(f"  independent:   tp={manual['tp']}, tn={manual['tn']}, fp={manual['fp']}, fn={manual['fn']}")
    print(f"[Check 1] Independent confusion matrix EXACTLY matches results.py -> {'PASS' if all_match else 'FAIL'}")
    checks_passed &= all_match

    # --- Check 2: totals equal actual pixel count of the validation set ---
    computed_total = official["tp"] + official["tn"] + official["fp"] + official["fn"]
    totals_match = computed_total == manual["total_pixels_seen"] == official["total_pixels"]
    print(f"[Check 2] tp+tn+fp+fn ({computed_total}) equals actual total validation pixels "
          f"({manual['total_pixels_seen']}) -> {'PASS' if totals_match else 'FAIL'}")
    checks_passed &= totals_match

    # --- Check 3: derived metrics formulas are correct ---
    tp, tn, fp, fn = official["tp"], official["tn"], official["fp"], official["fn"]
    expected_precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    expected_recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    expected_dice = (2 * tp) / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else 0.0
    expected_iou = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0.0
    expected_accuracy = (tp + tn) / (tp + tn + fp + fn)

    metrics_correct = (
        abs(official["precision"] - expected_precision) < 1e-9 and
        abs(official["recall"] - expected_recall) < 1e-9 and
        abs(official["dice"] - expected_dice) < 1e-9 and
        abs(official["iou"] - expected_iou) < 1e-9 and
        abs(official["accuracy"] - expected_accuracy) < 1e-9
    )
    print(f"\n[Check 3] Precision/Recall/Dice/IoU/Accuracy match hand-computed formulas -> "
          f"{'PASS' if metrics_correct else 'FAIL'}")
    print(f"    precision={official['precision']:.4f}, recall={official['recall']:.4f}, "
          f"dice={official['dice']:.4f}, iou={official['iou']:.4f}, accuracy={official['accuracy']:.4f}")
    checks_passed &= metrics_correct

    # --- Check 4: sample predictions ---
    samples = results_module.get_sample_predictions(checkpoint_path, count=4, device_preference="cpu")
    samples_ok = (
        len(samples) > 0 and
        all(s["image"].startswith("data:image/png;base64,") for s in samples) and
        all(s["ground_truth"].startswith("data:image/png;base64,") for s in samples) and
        all(s["prediction"].startswith("data:image/png;base64,") for s in samples)
    )
    print(f"\n[Check 4] get_sample_predictions returns valid base64 image triples "
          f"({len(samples)} samples) -> {'PASS' if samples_ok else 'FAIL'}")
    checks_passed &= samples_ok

    # --- Check 5: saved report matches live-computed confusion matrix exactly ---
    report_info = results_module.save_report(checkpoint_path, device_preference="cpu")
    with open(report_info["path"]) as f:
        saved_report = json.load(f)

    saved_confusion = saved_report["confusion_matrix"]
    report_matches = (
        saved_confusion["tp"] == official["tp"] and
        saved_confusion["tn"] == official["tn"] and
        saved_confusion["fp"] == official["fp"] and
        saved_confusion["fn"] == official["fn"] and
        abs(saved_confusion["dice"] - official["dice"]) < 1e-9
    )
    print(f"\n[Check 5] Saved report file ({report_info['filename']}) confusion matrix "
          f"exactly matches what was shown live -> {'PASS' if report_matches else 'FAIL'}")
    checks_passed &= report_matches

    # Check the report also contains the full metrics history and config
    report_complete = (
        "metrics_history" in saved_report and len(saved_report["metrics_history"]) == 8 and
        "config" in saved_report and saved_report["config"]["architecture"] == "mini_unet"
    )
    print(f"[Check 5] Saved report also includes full metrics history (8 epochs) and config -> "
          f"{'PASS' if report_complete else 'FAIL'}")
    checks_passed &= report_complete

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")

    # Cleanup
    shutil.rmtree(test_run_dir, ignore_errors=True)
    os.remove(report_info["path"])


if __name__ == "__main__":
    main()
