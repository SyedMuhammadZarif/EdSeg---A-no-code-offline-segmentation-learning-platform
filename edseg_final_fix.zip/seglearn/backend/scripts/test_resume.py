"""
Stage 4 verification script.

Tests resume-from-checkpoint logic:
  1. Happy path: train 10 epochs, resume from the epoch-5 checkpoint for
     5 more epochs, confirm the resumed run continues sensibly (not
     restarting from scratch) and produces a correct epoch-10 checkpoint.
  2. Mismatch path: attempt to resume the same checkpoint with a
     deliberately wrong architecture and a deliberately wrong dataset,
     confirm both are rejected with a clear error.

Run with:
    python backend/scripts/test_resume.py
"""

import sys
import os
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from train import train_model, resume_training, CheckpointMismatchError, CHECKPOINTS_ROOT

TEST_RUN_ID = "stage4_verification_run"


def main():
    test_run_dir = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID)
    if os.path.exists(test_run_dir):
        shutil.rmtree(test_run_dir)

    checks_passed = True

    # --- Step 1: initial training run, stop at epoch 5 only ---
    print("Step 1: training mini_unet on sample_shapes for 5 epochs...")
    first_result = train_model(
        dataset_name="sample_shapes",
        dataset_source="bundled",
        model_name="mini_unet",
        learning_rate=1e-3,
        epochs=5,
        batch_size=4,
        val_split=0.25,
        subset_size=16,
        device_preference="cpu",
        checkpoint_every=5,
        run_id=TEST_RUN_ID,
    )
    epoch5_train_loss = first_result["metrics_history"][-1]["train_loss"]
    print(f"  Finished at epoch 5. Train loss: {epoch5_train_loss:.4f}\n")

    epoch5_checkpoint = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID, "epoch_5.pt")

    # --- Step 2: resume from epoch 5 for 5 more epochs (happy path) ---
    print("Step 2: resuming from epoch-5 checkpoint for 5 more epochs (correct architecture/dataset)...")

    def print_progress(m):
        print(f"    Epoch {m['epoch']:2d} | train_loss={m['train_loss']:.4f}")

    resumed_result = resume_training(
        checkpoint_path=epoch5_checkpoint,
        additional_epochs=5,
        expected_architecture="mini_unet",
        expected_dataset_name="sample_shapes",
        expected_dataset_source="bundled",
        device_preference="cpu",
        checkpoint_every=5,
        progress_callback=print_progress,
    )

    # Check 1: metrics history now has 10 entries total, continuing epoch numbers 1-10
    history = resumed_result["metrics_history"]
    epoch_numbers = [m["epoch"] for m in history]
    correct_length = len(history) == 10
    correct_sequence = epoch_numbers == list(range(1, 11))
    print(f"\n[Check 1] Combined metrics history has 10 entries (5 original + 5 resumed): "
          f"{'PASS' if correct_length else 'FAIL'}")
    print(f"[Check 1] Epoch numbers continue sequentially 1-10 (not restarting at 1): "
          f"{'PASS' if correct_sequence else 'FAIL'}")
    checks_passed &= correct_length and correct_sequence

    # Check 2: training loss at epoch 10 is lower than at epoch 5 (learning continued, didn't reset)
    epoch10_train_loss = history[-1]["train_loss"]
    continued_learning = epoch10_train_loss < epoch5_train_loss
    print(f"[Check 2] Loss continued decreasing after resume: "
          f"epoch5={epoch5_train_loss:.4f} -> epoch10={epoch10_train_loss:.4f} "
          f"-> {'PASS' if continued_learning else 'FAIL'}")
    checks_passed &= continued_learning

    # Check 3: a new epoch_10.pt checkpoint was created in the SAME run folder
    epoch10_checkpoint = os.path.join(CHECKPOINTS_ROOT, TEST_RUN_ID, "epoch_10.pt")
    checkpoint_created = os.path.exists(epoch10_checkpoint)
    same_run_id = resumed_result["run_id"] == TEST_RUN_ID
    print(f"[Check 3] New epoch-10 checkpoint created in the same run folder: "
          f"{'PASS' if (checkpoint_created and same_run_id) else 'FAIL'}")
    checks_passed &= checkpoint_created and same_run_id

    # --- Step 3: mismatch path — wrong architecture ---
    print("\nStep 3: attempting to resume with a deliberately WRONG architecture...")
    try:
        resume_training(
            checkpoint_path=epoch5_checkpoint,
            additional_epochs=2,
            expected_architecture="standard_mini_unet",  # wrong on purpose
            expected_dataset_name="sample_shapes",
            expected_dataset_source="bundled",
            device_preference="cpu",
        )
        print("[Check 4] Wrong architecture was NOT rejected -> FAIL (this should have raised an error)")
        checks_passed = False
    except CheckpointMismatchError as e:
        print(f"[Check 4] Wrong architecture correctly rejected -> PASS\n    Message: {e}")

    # --- Step 4: mismatch path — wrong dataset ---
    print("\nStep 4: attempting to resume with a deliberately WRONG dataset...")
    try:
        resume_training(
            checkpoint_path=epoch5_checkpoint,
            additional_epochs=2,
            expected_architecture="mini_unet",
            expected_dataset_name="some_other_dataset",  # wrong on purpose
            expected_dataset_source="bundled",
            device_preference="cpu",
        )
        print("[Check 5] Wrong dataset was NOT rejected -> FAIL (this should have raised an error)")
        checks_passed = False
    except CheckpointMismatchError as e:
        print(f"[Check 5] Wrong dataset correctly rejected -> PASS\n    Message: {e}")

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")


if __name__ == "__main__":
    main()
