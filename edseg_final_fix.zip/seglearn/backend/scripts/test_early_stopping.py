"""
Verification script for:
  1. Early stopping — training should stop automatically once validation
     loss hasn't improved for `patience` consecutive epochs, and the
     FINAL saved checkpoint should reflect the BEST epoch's weights, not
     just whatever epoch training happened to stop at.
  2. The MAX_EPOCHS=100 server-side cap — requesting more epochs than
     that should be silently clamped, not silently ignored or crashed on.

Run with:
    python backend/scripts/test_early_stopping.py
"""

import sys
import os
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from train import train_model, MAX_EPOCHS, CHECKPOINTS_ROOT

TEST_RUN_ID = "early_stopping_verification_run"
CAP_TEST_RUN_ID = "epoch_cap_verification_run"


def cleanup():
    for run_id in (TEST_RUN_ID, CAP_TEST_RUN_ID):
        path = os.path.join(CHECKPOINTS_ROOT, run_id)
        if os.path.exists(path):
            shutil.rmtree(path)


def main():
    cleanup()
    checks_passed = True

    # --- Check 1: early stopping actually stops before the requested epoch count ---
    print(f"Training with early stopping enabled (patience=3), requesting 30 epochs...")
    result = train_model(
        dataset_name="sample_shapes",
        dataset_source="bundled",
        model_name="mini_unet",
        learning_rate=1e-3,
        epochs=30,
        batch_size=4,
        val_split=0.25,
        subset_size=16,
        device_preference="cpu",
        checkpoint_every=5,
        run_id=TEST_RUN_ID,
        early_stopping_enabled=True,
        early_stopping_patience=3,
    )

    epochs_actually_run = len(result["metrics_history"])
    stopped_before_30 = epochs_actually_run < 30
    print(f"  Epochs actually run: {epochs_actually_run} (requested 30)")
    print(f"[Check 1] Early stopping triggered before reaching the full 30 epochs -> "
          f"{'PASS' if stopped_before_30 else 'FAIL (may need a different patience/dataset to trigger reliably)'}")
    # Note: this isn't strictly guaranteed to trigger on every random init with such
    # a tiny/easy synthetic dataset (the model might keep improving the whole time),
    # so this check is informative rather than a hard failure if it doesn't trigger.

    # --- Check 2: the saved checkpoint reflects the BEST epoch, not an arbitrary later one ---
    final_checkpoint_path = result["checkpoint_paths"][-1]
    final_checkpoint = torch.load(final_checkpoint_path, weights_only=False)
    saved_epoch = final_checkpoint["epoch"]
    saved_epoch_metrics = next(m for m in result["metrics_history"] if m["epoch"] == saved_epoch)

    # Find which epoch in the full history actually had the best (lowest) val_loss
    val_losses = [(m["epoch"], m["val_loss"]) for m in result["metrics_history"] if m["val_loss"] is not None]
    best_epoch_by_val_loss = min(val_losses, key=lambda x: x[1])[0] if val_losses else None

    print(f"\n  Final saved checkpoint is at epoch: {saved_epoch}")
    print(f"  Best val_loss across all trained epochs was at epoch: {best_epoch_by_val_loss}")
    matches_best = (best_epoch_by_val_loss is None) or (saved_epoch == best_epoch_by_val_loss)
    print(f"[Check 2] Final saved checkpoint matches the best-val-loss epoch (restore-best-weights) -> "
          f"{'PASS' if matches_best else 'FAIL'}")
    checks_passed &= matches_best

    # --- Check 3: config records that early stopping was used ---
    config_correct = (
        final_checkpoint["config"]["early_stopping_enabled"] is True and
        final_checkpoint["config"]["early_stopping_patience"] == 3
    )
    print(f"[Check 3] Checkpoint config correctly records early stopping settings -> "
          f"{'PASS' if config_correct else 'FAIL'}")
    checks_passed &= config_correct

    cleanup()

    # --- Check 4: requesting more than MAX_EPOCHS gets clamped, not crashed ---
    print(f"\nRequesting {MAX_EPOCHS + 50} epochs (cap is {MAX_EPOCHS})...")
    result2 = train_model(
        dataset_name="sample_shapes",
        dataset_source="bundled",
        model_name="mini_unet",
        learning_rate=1e-3,
        epochs=MAX_EPOCHS + 50,
        batch_size=4,
        val_split=0.25,
        subset_size=16,
        device_preference="cpu",
        checkpoint_every=25,
        run_id=CAP_TEST_RUN_ID,
    )
    # NOTE: this will actually run MAX_EPOCHS (100) epochs, which is slow for a
    # verification script — reduce subset/epochs expectation isn't practical here
    # since we need to prove the real cap. Kept deliberately small dataset/model
    # to keep even 100 epochs fast on CPU.
    final_epoch_reached = result2["metrics_history"][-1]["epoch"]
    clamped_correctly = (
        final_epoch_reached == MAX_EPOCHS and
        result2["epochs_were_clamped"] is True
    )
    print(f"  Final epoch reached: {final_epoch_reached} (should be exactly {MAX_EPOCHS})")
    print(f"[Check 4] Epoch count correctly clamped to MAX_EPOCHS -> {'PASS' if clamped_correctly else 'FAIL'}")
    checks_passed &= clamped_correctly

    cleanup()

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")


if __name__ == "__main__":
    main()
