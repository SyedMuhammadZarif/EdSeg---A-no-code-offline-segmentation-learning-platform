"""
Stage 2 verification script.

Instantiates each registered model, runs a dummy image through it, and
reports:
  - whether the forward pass succeeds
  - whether output shape matches input shape (same H/W, 1 output channel)
  - the parameter count (should be comfortably in the "small" range)

Run with:
    python backend/scripts/test_models.py
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
from models import MODEL_REGISTRY, build_model, count_parameters

IMG_SIZE = 128
BATCH_SIZE = 2


def main():
    print(f"Testing {len(MODEL_REGISTRY)} model architectures")
    print(f"Dummy input: batch={BATCH_SIZE}, channels=1, {IMG_SIZE}x{IMG_SIZE}\n")

    dummy_input = torch.randn(BATCH_SIZE, 1, IMG_SIZE, IMG_SIZE)
    all_passed = True

    for name, cls in MODEL_REGISTRY.items():
        print(f"--- {cls.display_name} ({name}) ---")
        try:
            model = build_model(name)
            model.eval()

            with torch.no_grad():
                output = model(dummy_input)

            expected_shape = (BATCH_SIZE, 1, IMG_SIZE, IMG_SIZE)
            shape_ok = tuple(output.shape) == expected_shape
            param_count = count_parameters(model)

            status = "PASS" if shape_ok else "FAIL"
            if not shape_ok:
                all_passed = False

            print(f"  Output shape: {tuple(output.shape)} (expected {expected_shape}) -> {status}")
            print(f"  Parameter count: {param_count:,}")
            size_note = "lightweight (CPU-fast)" if param_count < 5_000_000 else "large (expect slower training)"
            print(f"  Size category: {size_note}")
        except Exception as e:
            all_passed = False
            print(f"  ERROR: forward pass failed -> {e}")
        print()

    print("=" * 50)
    print("ALL MODELS PASSED" if all_passed else "SOME MODELS FAILED — see above")


if __name__ == "__main__":
    main()
