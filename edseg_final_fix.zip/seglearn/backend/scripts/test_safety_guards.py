"""
Verification script for issues found during a broader safety audit:
  1. Starting a second training run while one is already in progress
     should be rejected with a clear error, not silently allowed to run
     both simultaneously (which would just compete for CPU/GPU).
  2. The same protection should apply to resuming and to tuning sweeps,
     and across job TYPES (e.g. a tuning sweep should block a fresh
     training start, and vice versa).
  3. Uploading a custom dataset with a name that already exists should be
     rejected, not silently delete the existing one.
  4. Saving a model with a name that already exists should be rejected,
     not silently overwrite the existing one.

Run with:
    python backend/scripts/test_safety_guards.py
"""

import sys
import os
import time
import shutil
import io

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app
from train import CHECKPOINTS_ROOT
from model_library import MODELS_ROOT
from dataset_utils import CUSTOM_ROOT


def cleanup():
    for root, prefix in [(CHECKPOINTS_ROOT, "")]:
        if os.path.isdir(root):
            for entry in os.listdir(root):
                shutil.rmtree(os.path.join(root, entry), ignore_errors=True)
    if os.path.isdir(MODELS_ROOT):
        for entry in os.listdir(MODELS_ROOT):
            if entry.endswith(".pt"):
                os.remove(os.path.join(MODELS_ROOT, entry))
    if os.path.isdir(CUSTOM_ROOT):
        for entry in os.listdir(CUSTOM_ROOT):
            shutil.rmtree(os.path.join(CUSTOM_ROOT, entry), ignore_errors=True)


def wait_for_completion(client, run_id, timeout=30):
    start = time.time()
    while time.time() - start < timeout:
        resp = client.get(f"/api/train/status/{run_id}")
        data = resp.get_json()
        if data["status"] in ("completed", "stopped", "error"):
            return data
        time.sleep(0.2)
    raise TimeoutError(f"Run {run_id} did not finish within {timeout}s")


def main():
    cleanup()
    checks_passed = True
    client = app.test_client()

    # --- Check 1: starting a 2nd training run while the 1st is in progress is rejected ---
    print("Starting a training run, then immediately trying to start a second one...")
    resp1 = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
        "epochs": 10, "batch_size": 4, "subset_size": 16, "device_preference": "cpu",
    })
    run_id_1 = resp1.get_json()["run_id"]

    resp2 = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
        "epochs": 10, "batch_size": 4, "subset_size": 16, "device_preference": "cpu",
    })
    rejected_correctly = resp2.status_code == 409 and "already in progress" in resp2.get_json().get("error", "")
    print(f"[Check 1] Second concurrent training run rejected with 409 -> {'PASS' if rejected_correctly else 'FAIL'}")
    print(f"    Status: {resp2.status_code}, message: {resp2.get_json().get('error')}")
    checks_passed &= rejected_correctly

    # --- Check 2: a tuning sweep is ALSO rejected while that training run is still going ---
    resp3 = client.post("/api/tuning/start", json={
        "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
        "epochs": 3, "batch_size": 4, "subset_size": 16, "device_preference": "cpu",
        "sweep_params": [{"param": "learning_rate", "values": [0.001, 0.005]}],
    })
    cross_type_rejected = resp3.status_code == 409
    print(f"[Check 2] Tuning sweep also rejected while a training run is active (cross-type guard) -> "
          f"{'PASS' if cross_type_rejected else 'FAIL'}")
    checks_passed &= cross_type_rejected

    # Let the first run finish before continuing
    wait_for_completion(client, run_id_1)

    # --- Check 3: once finished, a new run is allowed again ---
    resp4 = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
        "epochs": 3, "batch_size": 4, "subset_size": 16, "device_preference": "cpu",
    })
    allowed_after_finish = resp4.status_code == 200
    print(f"[Check 3] New run allowed once the previous one finished -> {'PASS' if allowed_after_finish else 'FAIL'}")
    checks_passed &= allowed_after_finish
    if allowed_after_finish:
        wait_for_completion(client, resp4.get_json()["run_id"])

    cleanup()

    # --- Check 4: uploading a dataset with a name that already exists is rejected ---
    print("\nUploading a custom dataset, then trying to upload another with the SAME name...")
    import zipfile as zf_module

    def make_test_zip():
        from PIL import Image
        buf = io.BytesIO()
        with zf_module.ZipFile(buf, "w") as zf:
            img_buf = io.BytesIO()
            Image.new("L", (8, 8), color=128).save(img_buf, format="PNG")
            zf.writestr("images/a.png", img_buf.getvalue())

            mask_buf = io.BytesIO()
            Image.new("L", (8, 8), color=255).save(mask_buf, format="PNG")
            zf.writestr("masks/a.png", mask_buf.getvalue())
        buf.seek(0)
        return buf

    resp5 = client.post("/api/datasets/upload", data={
        "file": (make_test_zip(), "test.zip"),
        "name": "duplicate_test_dataset",
    }, content_type="multipart/form-data")
    first_upload_ok = resp5.status_code == 200
    print(f"  First upload succeeded: {first_upload_ok}")

    resp6 = client.post("/api/datasets/upload", data={
        "file": (make_test_zip(), "test.zip"),
        "name": "duplicate_test_dataset",
    }, content_type="multipart/form-data")
    duplicate_rejected = resp6.status_code == 400 and "already exists" in resp6.get_json().get("error", "")
    print(f"[Check 4] Duplicate dataset name rejected (not silently overwritten) -> "
          f"{'PASS' if duplicate_rejected else 'FAIL'}")
    print(f"    Message: {resp6.get_json().get('error')}")
    checks_passed &= first_upload_ok and duplicate_rejected

    cleanup()

    # --- Check 5: saving a model with a name that already exists is rejected ---
    print("\nTraining a model, saving it, then trying to save ANOTHER checkpoint under the SAME name...")
    resp7 = client.post("/api/train/start", json={
        "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
        "epochs": 5, "batch_size": 4, "subset_size": 16, "device_preference": "cpu", "checkpoint_every": 5,
    })
    run_id_5 = resp7.get_json()["run_id"]
    wait_for_completion(client, run_id_5)

    checkpoints = client.get("/api/checkpoints").get_json()["checkpoints"]
    checkpoint_path = [c for c in checkpoints if c["run_id"] == run_id_5][0]["path"]

    resp8 = client.post("/api/model/save", json={"checkpoint_path": checkpoint_path, "name": "duplicate_test_model"})
    first_save_ok = resp8.status_code == 200
    print(f"  First save succeeded: {first_save_ok}")

    resp9 = client.post("/api/model/save", json={"checkpoint_path": checkpoint_path, "name": "duplicate_test_model"})
    model_duplicate_rejected = resp9.status_code == 400 and "already exists" in resp9.get_json().get("error", "")
    print(f"[Check 5] Duplicate model name rejected (not silently overwritten) -> "
          f"{'PASS' if model_duplicate_rejected else 'FAIL'}")
    print(f"    Message: {resp9.get_json().get('error')}")
    checks_passed &= first_save_ok and model_duplicate_rejected

    cleanup()

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")


if __name__ == "__main__":
    main()
