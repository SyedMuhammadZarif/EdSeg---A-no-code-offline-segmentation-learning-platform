"""
Training job manager for SegLearn — Stage 5.

Wraps train_model()/resume_training() so they can run in a background
thread while the Flask server stays responsive to status-polling and
stop requests. This is intentionally simple (in-memory dict, one process)
since the app only ever serves one student on their own machine — no
need for a real task queue/broker.
"""

import threading
import traceback
import uuid
from datetime import datetime

from train import train_model, resume_training, CheckpointMismatchError
import tuning as tuning_module
from tuning import run_sweep
import sweeps as sweeps_module

# run_id -> job dict. Kept in memory; cleared on server restart (fine —
# completed runs are still recoverable from their checkpoint files on disk).
_JOBS = {}
_TUNING_JOBS = {}
_LOCK = threading.Lock()


class JobAlreadyRunningError(Exception):
    """Raised when trying to start a new training/tuning job while one is already in progress."""
    pass


def _get_running_job_description():
    """
    Check both training and tuning jobs for anything currently running.
    Returns a short description string if something is running, else None.
    Must be called while holding _LOCK.
    """
    for job in _JOBS.values():
        if job["status"] == "running":
            return f"a training run ({job['run_id']})"
    for job in _TUNING_JOBS.values():
        if job["status"] == "running":
            return f"a hyperparameter sweep ({job['tuning_id']})"
    return None


def _generate_run_id(model_name, dataset_name):
    """
    Build a readable, timestamp-based run ID, e.g.
    'mini_unet_sample_shapes_2026-09-06_14-32-05'. A short random suffix
    is appended only to guard against the rare case of two runs starting
    within the same second — it's not meant to be the primary identifier.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    suffix = uuid.uuid4().hex[:4]
    return f"{model_name}_{dataset_name}_{timestamp}_{suffix}"


def _new_job_entry(run_id):
    return {
        "run_id": run_id,
        "status": "running",       # running | completed | stopped | error
        "metrics_so_far": [],
        "latest_preview": None,
        "final_result": None,
        "error": None,
        "stop_event": threading.Event(),
    }


def _progress_callback_factory(run_id):
    def _callback(epoch_metrics):
        with _LOCK:
            if run_id not in _JOBS:
                return
            preview = epoch_metrics.pop("preview", None)
            _JOBS[run_id]["metrics_so_far"].append(epoch_metrics)
            if preview is not None:
                _JOBS[run_id]["latest_preview"] = preview
    return _callback


def start_training_job(**train_model_kwargs):
    """
    Start a fresh training run in a background thread.
    Returns the run_id immediately (does not block until training finishes).

    Raises JobAlreadyRunningError if a training run or tuning sweep is
    already in progress — running two at once would just have them
    compete for the same CPU/GPU, silently slowing both down and
    confusing anyone watching two different screens update at once.
    """
    with _LOCK:
        running = _get_running_job_description()
        if running:
            raise JobAlreadyRunningError(
                f"Can't start a new training run — {running} is already in progress. "
                f"Wait for it to finish, or stop it first."
            )

    run_id = train_model_kwargs.get("run_id") or _generate_run_id(
        train_model_kwargs.get("model_name", "model"),
        train_model_kwargs.get("dataset_name", "dataset"),
    )
    train_model_kwargs["run_id"] = run_id

    with _LOCK:
        _JOBS[run_id] = _new_job_entry(run_id)

    stop_event = _JOBS[run_id]["stop_event"]
    progress_callback = _progress_callback_factory(run_id)

    def _run():
        try:
            result = train_model(
                **train_model_kwargs,
                progress_callback=progress_callback,
                stop_event=stop_event,
                generate_previews=True,
            )
            with _LOCK:
                _JOBS[run_id]["final_result"] = result
                _JOBS[run_id]["status"] = "stopped" if stop_event.is_set() else "completed"
        except Exception as e:
            with _LOCK:
                _JOBS[run_id]["status"] = "error"
                _JOBS[run_id]["error"] = f"{e}\n{traceback.format_exc()}"

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return run_id


def start_resume_job(checkpoint_path, additional_epochs, expected_architecture=None,
                      expected_dataset_name=None, expected_dataset_source=None,
                      device_preference="auto", checkpoint_every=5,
                      early_stopping_enabled=None, early_stopping_patience=None):
    """
    Start a resumed training run in a background thread. Raises
    CheckpointMismatchError immediately (before starting the thread) if
    the architecture/dataset don't match — this is a fast validation the
    caller should catch and turn into a 400 response, not a background job.
    Raises JobAlreadyRunningError if a training run or tuning sweep is
    already in progress.
    """
    with _LOCK:
        running = _get_running_job_description()
        if running:
            raise JobAlreadyRunningError(
                f"Can't resume training — {running} is already in progress. "
                f"Wait for it to finish, or stop it first."
            )

    # Validate synchronously first (raises CheckpointMismatchError early,
    # before we ever spin up a thread or claim a run_id).
    import train as train_module
    checkpoint = train_module.load_checkpoint(checkpoint_path)
    config = checkpoint["config"]
    if expected_architecture is not None and expected_architecture != config["architecture"]:
        raise CheckpointMismatchError(
            f"Architecture mismatch: this checkpoint was trained with "
            f"'{config['architecture']}', but '{expected_architecture}' was selected."
        )
    if expected_dataset_name is not None and expected_dataset_name != config["dataset_name"]:
        raise CheckpointMismatchError(
            f"Dataset mismatch: this checkpoint was trained on "
            f"'{config['dataset_name']}', but '{expected_dataset_name}' was selected."
        )

    # Note: this run_id is only used for tracking THIS resume session's
    # live status polling. The actual checkpoint files continue to be
    # written into the ORIGINAL run's folder (train.resume_training derives
    # that from the checkpoint's own path) — so resumed epochs correctly
    # accumulate together with the original run in the checkpoints list.
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    run_id = f"resume_{config['architecture']}_{config['dataset_name']}_{timestamp}_{uuid.uuid4().hex[:4]}"

    with _LOCK:
        _JOBS[run_id] = _new_job_entry(run_id)

    stop_event = _JOBS[run_id]["stop_event"]
    progress_callback = _progress_callback_factory(run_id)

    def _run():
        try:
            result = resume_training(
                checkpoint_path=checkpoint_path,
                additional_epochs=additional_epochs,
                expected_architecture=expected_architecture,
                expected_dataset_name=expected_dataset_name,
                expected_dataset_source=expected_dataset_source,
                device_preference=device_preference,
                early_stopping_enabled=early_stopping_enabled,
                early_stopping_patience=early_stopping_patience,
                checkpoint_every=checkpoint_every,
                progress_callback=progress_callback,
                stop_event=stop_event,
                generate_previews=True,
            )
            with _LOCK:
                # Resumed run continues the ORIGINAL run_id internally; track
                # that under our job's key too so status lookups work either way.
                _JOBS[run_id]["final_result"] = result
                _JOBS[run_id]["status"] = "stopped" if stop_event.is_set() else "completed"
        except Exception as e:
            with _LOCK:
                _JOBS[run_id]["status"] = "error"
                _JOBS[run_id]["error"] = f"{e}\n{traceback.format_exc()}"

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return run_id


def get_job_status(run_id):
    """Return the current status dict for a run_id, or None if unknown."""
    with _LOCK:
        job = _JOBS.get(run_id)
        if job is None:
            return None
        return {
            "run_id": job["run_id"],
            "status": job["status"],
            "metrics_so_far": list(job["metrics_so_far"]),
            "latest_preview": job["latest_preview"],
            "final_result": job["final_result"],
            "error": job["error"],
        }


def stop_job(run_id):
    """Signal a running job to stop. Returns True if the job existed."""
    with _LOCK:
        job = _JOBS.get(run_id)
        if job is None:
            return False
        job["stop_event"].set()
        return True


# ---------------------------------------------------------------------------
# Hyperparameter tuning jobs (Stage 9)
# ---------------------------------------------------------------------------

def _new_tuning_job_entry(tuning_id, sweep_params, combinations):
    return {
        "tuning_id": tuning_id,
        "status": "running",  # running | completed | stopped | error
        "sweep_params": [e["param"] for e in sweep_params],
        "trials": [
            {
                "trial_index": i,
                "sweep_values": combo,  # dict, e.g. {"learning_rate": 0.001, "batch_size": 4}
                "status": "pending",  # pending | running | completed
                "run_id": None,
                "metrics_so_far": [],
                "final_metrics": None,
                "checkpoint_path": None,
            }
            for i, combo in enumerate(combinations)
        ],
        "meta": None,
        "error": None,
        "stop_event": threading.Event(),
    }


def start_tuning_job(base_config, sweep_params):
    """
    Start a hyperparameter sweep in a background thread. sweep_params is a
    list of {"param": <name>, "values": [...]} — one entry sweeps a single
    parameter, multiple entries run a full grid search across every
    combination. Trials run sequentially (not in parallel) since this is a
    single-user local app and parallel CPU jobs would just compete for the
    same cores. Returns a tuning_id immediately.

    Raises JobAlreadyRunningError if a training run or another tuning
    sweep is already in progress.
    """
    with _LOCK:
        running = _get_running_job_description()
        if running:
            raise JobAlreadyRunningError(
                f"Can't start a new sweep — {running} is already in progress. "
                f"Wait for it to finish, or stop it first."
            )

    grid_info = tuning_module.compute_grid_combinations(sweep_params)
    combinations = grid_info["combinations"]

    param_names_joined = "_".join(e["param"] for e in sweep_params)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    tuning_id = f"tuning_{param_names_joined}_{timestamp}_{uuid.uuid4().hex[:4]}"

    with _LOCK:
        _TUNING_JOBS[tuning_id] = _new_tuning_job_entry(tuning_id, sweep_params, combinations)

    job = _TUNING_JOBS[tuning_id]
    stop_event = job["stop_event"]

    def on_trial_start(i, combo, run_id):
        with _LOCK:
            job["trials"][i]["status"] = "running"
            job["trials"][i]["run_id"] = run_id

    def on_epoch_progress(i, epoch_metrics):
        with _LOCK:
            job["trials"][i]["metrics_so_far"].append(epoch_metrics)

    def on_trial_complete(i, trial_result):
        with _LOCK:
            job["trials"][i]["status"] = "completed"
            job["trials"][i]["final_metrics"] = trial_result["final_metrics"]
            job["trials"][i]["checkpoint_path"] = trial_result["checkpoint_path"]

    def _run():
        try:
            summary = run_sweep(
                base_config, sweep_params,
                on_trial_start=on_trial_start,
                on_epoch_progress=on_epoch_progress,
                on_trial_complete=on_trial_complete,
                stop_event=stop_event,
            )
            with _LOCK:
                job["meta"] = {k: v for k, v in summary.items() if k != "trials"}
                job["status"] = "stopped" if stop_event.is_set() else "completed"
                final_status, final_trials, final_meta = job["status"], list(job["trials"]), job["meta"]
            sweeps_module.save_sweep_record(tuning_id, [e["param"] for e in sweep_params], final_trials, final_status, final_meta)
        except Exception as e:
            with _LOCK:
                job["status"] = "error"
                job["error"] = f"{e}\n{traceback.format_exc()}"
                final_trials = list(job["trials"])
            sweeps_module.save_sweep_record(tuning_id, [e["param"] for e in sweep_params], final_trials, "error", {"error": str(e)})

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return tuning_id


def get_tuning_status(tuning_id):
    """Return the current status dict for a tuning_id, or None if unknown."""
    with _LOCK:
        job = _TUNING_JOBS.get(tuning_id)
        if job is None:
            return None
        return {
            "tuning_id": job["tuning_id"],
            "status": job["status"],
            "sweep_params": job["sweep_params"],
            "trials": [dict(t) for t in job["trials"]],
            "meta": job["meta"],
            "error": job["error"],
        }


def stop_tuning_job(tuning_id):
    """
    Signal a running tuning sweep to stop. Since each trial shares the same
    stop_event as train_model(), this stops the CURRENTLY running trial
    immediately (mid-epoch-loop) rather than waiting for it to finish, and
    skips any remaining trials.
    """
    with _LOCK:
        job = _TUNING_JOBS.get(tuning_id)
        if job is None:
            return False
        job["stop_event"].set()
        return True
