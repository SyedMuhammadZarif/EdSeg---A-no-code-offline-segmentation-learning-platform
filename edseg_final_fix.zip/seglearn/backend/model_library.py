"""
Model library for SegLearn — Stage 5.

Lets a student "save" a specific checkpoint as a named final model in
/models/, distinct from the working checkpoints/ folder used during
training. Saved models are what the Stage 10 testing/inference screen
loads. Internally this reuses the exact same checkpoint file format
(model weights + optimizer state + config + metrics history) so no
conversion is needed — saving is just copying a checkpoint file into
/models/ under a student-chosen name.
"""

import os
import shutil
import torch

from paths import get_persistent_data_root

MODELS_ROOT = os.path.join(get_persistent_data_root(), "models")


class ModelLibraryError(Exception):
    pass


def save_model(checkpoint_path, display_name):
    """
    Copy a checkpoint file into /models/<safe_name>.pt so it appears in
    the model library, independent of the training run's checkpoint folder.
    """
    if not os.path.exists(checkpoint_path):
        raise ModelLibraryError(f"Checkpoint not found: {checkpoint_path}")

    safe_name = "".join(c for c in display_name if c.isalnum() or c in ("-", "_")).strip()
    if not safe_name:
        raise ModelLibraryError("Please provide a name with at least one letter or number.")

    os.makedirs(MODELS_ROOT, exist_ok=True)
    target_path = os.path.join(MODELS_ROOT, f"{safe_name}.pt")

    if os.path.exists(target_path):
        raise ModelLibraryError(
            f"A model named '{safe_name}' already exists. Choose a different name, "
            f"or delete the existing one first if you meant to replace it."
        )

    shutil.copyfile(checkpoint_path, target_path)

    return describe_model(target_path)


def describe_model(path):
    """Read a saved model file's metadata without loading it onto a device."""
    ckpt = torch.load(path, weights_only=False, map_location="cpu")
    name = os.path.splitext(os.path.basename(path))[0]
    last_metrics = ckpt["metrics_history"][-1] if ckpt["metrics_history"] else {}

    return {
        "name": name,
        "path": path,
        "architecture": ckpt["config"]["architecture"],
        "dataset_name": ckpt["config"]["dataset_name"],
        "dataset_source": ckpt["config"]["dataset_source"],
        "trained_epochs": ckpt["epoch"],
        "final_train_loss": last_metrics.get("train_loss"),
        "final_val_dice": last_metrics.get("val_dice"),
        "final_val_iou": last_metrics.get("val_iou"),
    }


def list_saved_models():
    """List all models saved to the library."""
    if not os.path.isdir(MODELS_ROOT):
        return []

    results = []
    for filename in sorted(os.listdir(MODELS_ROOT)):
        if not filename.endswith(".pt"):
            continue
        try:
            results.append(describe_model(os.path.join(MODELS_ROOT, filename)))
        except Exception:
            continue  # skip unreadable files
    return results


def load_model_for_inference(name, device):
    """
    Load a saved model's weights onto the given device, ready for a
    forward pass. Returns (model, config).
    """
    import models as model_defs

    path = os.path.join(MODELS_ROOT, f"{name}.pt")
    if not os.path.exists(path):
        raise ModelLibraryError(f"Saved model '{name}' not found.")

    ckpt = torch.load(path, weights_only=False, map_location="cpu")
    model = model_defs.build_model(ckpt["config"]["architecture"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    return model, ckpt["config"]
