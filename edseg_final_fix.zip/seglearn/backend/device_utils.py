"""
Device detection/selection for CPU vs GPU (CUDA or Apple Silicon MPS).
"""

import torch


def detect_available_devices():
    """Return a dict describing what compute devices are usable on this machine."""
    return {
        "cpu": True,  # always available
        "cuda": torch.cuda.is_available(),
        "mps": torch.backends.mps.is_available() if hasattr(torch.backends, "mps") else False,
    }


def resolve_device(preference="auto"):
    """
    preference: 'auto', 'cpu', 'cuda', or 'mps'.

    'auto' picks the best available: cuda > mps > cpu.
    Explicit choices fall back to cpu (with a note) if unavailable, rather
    than crashing — this matters for the UI's CPU/GPU toggle.
    """
    available = detect_available_devices()

    if preference == "cpu":
        return torch.device("cpu"), "cpu"

    if preference == "cuda":
        if available["cuda"]:
            return torch.device("cuda"), "cuda"
        return torch.device("cpu"), "cpu (requested cuda, not available)"

    if preference == "mps":
        if available["mps"]:
            return torch.device("mps"), "mps"
        return torch.device("cpu"), "cpu (requested mps, not available)"

    # auto
    if available["cuda"]:
        return torch.device("cuda"), "cuda"
    if available["mps"]:
        return torch.device("mps"), "mps"
    return torch.device("cpu"), "cpu"
