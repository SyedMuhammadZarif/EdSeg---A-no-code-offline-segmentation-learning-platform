"""
Shared path resolution for EdSeg.

Why this exists: when running from source (`python backend/app.py`),
computing paths relative to `__file__` works fine. But when packaged by
PyInstaller into a single executable, the app actually runs from a
TEMPORARY extraction folder (sys._MEIPASS) that is deleted as soon as the
app closes. Anything the student needs to persist between runs —
checkpoints, saved models, reports, custom uploaded datasets — must NOT
be written there, or it would silently vanish every time they close the
app. This module is the one place that decides where things really go,
so every other module (dataset_utils, train, model_library, results)
stays correct in both source and packaged execution.
"""

import os
import sys


def is_frozen():
    """True when running as a PyInstaller-built executable."""
    return getattr(sys, "frozen", False)


def get_persistent_data_root():
    """
    Root directory for data that must survive between runs: checkpoints,
    saved models, reports, and custom uploaded datasets.

    Source execution: the project root (parent of backend/).
    Packaged execution: the folder containing the actual .exe/.app, which
    persists across runs (unlike sys._MEIPASS).
    """
    if is_frozen():
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_bundled_resource_root():
    """
    Root directory for READ-ONLY bundled resources: the frontend files and
    the bundled sample dataset. Safe to read from PyInstaller's temporary
    extraction folder since these are never written to at runtime.

    Source execution: the project root (parent of backend/).
    Packaged execution: sys._MEIPASS (PyInstaller's extraction folder).
    """
    if is_frozen():
        return sys._MEIPASS
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
