"""
Core training loop for SegLearn — Stage 3, extended in Stage 4 with
resume-from-checkpoint support.

Trains a chosen model on a chosen dataset with given hyperparameters,
tracks per-epoch metrics, and saves a checkpoint every N epochs (default
5) plus always at the final epoch. Checkpoints store everything needed
to resume later: model weights, optimizer state, and the full config
(architecture, dataset, hyperparameters).

This module has no Flask/API dependency — it's callable directly as a
function, which is what the test scripts do, and what the Stage 5 API
layer will wrap.
"""

import os
import io
import base64
import time
import uuid
import numpy as np
from PIL import Image
import torch
import torch.optim as optim

import models as model_defs
from segmentation_dataset import build_dataloaders
from losses_metrics import BCEDiceLoss, dice_score, iou_score
from device_utils import resolve_device

from paths import get_persistent_data_root

CHECKPOINTS_ROOT = os.path.join(get_persistent_data_root(), "checkpoints")


class CheckpointMismatchError(Exception):
    """Raised when a resume request's architecture/dataset doesn't match the checkpoint."""
    pass


def _tensor_to_base64_image(tensor_2d):
    """Convert a single-channel (H, W) tensor in [0, 1] to a base64 PNG data URL."""
    arr = (tensor_2d.detach().cpu().numpy() * 255).clip(0, 255).astype(np.uint8)
    im = Image.fromarray(arr, mode="L")
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def _run_validation(model, val_loader, loss_fn, device, want_preview=False):
    """
    Run one full validation pass, return average loss, dice, iou.

    If want_preview is True, also returns a 'preview' key with the first
    validation sample's (image, ground-truth mask, predicted mask) as
    base64 PNGs — used for the live "watch it improve" panel in the UI.
    This is intentionally NOT included when want_preview is False, so
    existing callers (Stage 3/4/5 scripts) are completely unaffected.
    """
    model.eval()
    total_loss, total_dice, total_iou, n_batches = 0.0, 0.0, 0.0, 0
    preview = None

    with torch.no_grad():
        for images, masks in val_loader:
            images, masks = images.to(device), masks.to(device)
            logits = model(images)
            loss = loss_fn(logits, masks)
            probs = torch.sigmoid(logits)

            if want_preview and preview is None:
                pred_binary = (probs[0, 0] > 0.5).float()
                preview = {
                    "image": _tensor_to_base64_image(images[0, 0]),
                    "ground_truth": _tensor_to_base64_image(masks[0, 0]),
                    "prediction": _tensor_to_base64_image(pred_binary),
                }

            total_loss += loss.item()
            total_dice += dice_score(probs, masks).item()
            total_iou += iou_score(probs, masks).item()
            n_batches += 1

    if n_batches == 0:
        return {"val_loss": None, "val_dice": None, "val_iou": None, "preview": None}

    return {
        "val_loss": total_loss / n_batches,
        "val_dice": total_dice / n_batches,
        "val_iou": total_iou / n_batches,
        "preview": preview,
    }


def save_checkpoint(run_id, epoch, model, optimizer, config, metrics_history):
    """Save a checkpoint to checkpoints/<run_id>/epoch_<n>.pt"""
    run_dir = os.path.join(CHECKPOINTS_ROOT, run_id)
    os.makedirs(run_dir, exist_ok=True)

    checkpoint = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "config": config,
        "metrics_history": metrics_history,
    }
    path = os.path.join(run_dir, f"epoch_{epoch}.pt")
    torch.save(checkpoint, path)
    return path


def load_checkpoint(checkpoint_path):
    """Load a checkpoint file from disk. Raises FileNotFoundError if missing."""
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    return torch.load(checkpoint_path, weights_only=False)


def _run_epoch_loop(model, optimizer, loss_fn, train_loader, val_loader, device,
                     start_epoch, end_epoch, checkpoint_every, run_id, config,
                     metrics_history, progress_callback=None, stop_event=None,
                     generate_previews=False):
    """
    Shared training loop used by both a fresh run (train_model) and a
    resumed run (resume_training). Runs epochs [start_epoch, end_epoch]
    inclusive, appending to metrics_history and saving checkpoints.

    If stop_event (a threading.Event) is provided and gets set, the loop
    stops cleanly before starting the next epoch, and — if the most
    recently completed epoch wasn't already checkpointed — forces a
    checkpoint save so no progress is lost when a student stops a run
    early.

    If generate_previews is True, a live preview (input image / ground
    truth / predicted mask) is included when calling progress_callback —
    but never stored in metrics_history or the saved checkpoint, keeping
    those lightweight.
    """
    checkpoint_paths = []
    last_completed_epoch = None
    last_checkpoint_epoch = None

    for epoch in range(start_epoch, end_epoch + 1):
        if stop_event is not None and stop_event.is_set():
            break

        model.train()
        epoch_start = time.time()
        total_train_loss, n_batches = 0.0, 0

        for images, masks in train_loader:
            images, masks = images.to(device), masks.to(device)

            optimizer.zero_grad()
            logits = model(images)
            loss = loss_fn(logits, masks)
            loss.backward()
            optimizer.step()

            total_train_loss += loss.item()
            n_batches += 1

        avg_train_loss = total_train_loss / max(n_batches, 1)
        val_metrics = _run_validation(model, val_loader, loss_fn, device, want_preview=generate_previews) if val_loader else {
            "val_loss": None, "val_dice": None, "val_iou": None, "preview": None
        }
        preview = val_metrics.pop("preview", None)

        epoch_metrics = {
            "epoch": epoch,
            "train_loss": avg_train_loss,
            "epoch_seconds": time.time() - epoch_start,
            **val_metrics,
        }
        metrics_history.append(epoch_metrics)
        last_completed_epoch = epoch

        if progress_callback:
            if generate_previews and preview is not None:
                progress_callback({**epoch_metrics, "preview": preview})
            else:
                progress_callback(epoch_metrics)

        is_checkpoint_epoch = (epoch % checkpoint_every == 0) or (epoch == end_epoch)
        if is_checkpoint_epoch:
            path = save_checkpoint(run_id, epoch, model, optimizer, config, metrics_history)
            checkpoint_paths.append(path)
            last_checkpoint_epoch = epoch

    # If we stopped early and the last completed epoch wasn't already
    # checkpointed, save one now so the student doesn't lose progress.
    if last_completed_epoch is not None and last_completed_epoch != last_checkpoint_epoch:
        path = save_checkpoint(run_id, last_completed_epoch, model, optimizer, config, metrics_history)
        checkpoint_paths.append(path)

    return metrics_history, checkpoint_paths


def train_model(
    dataset_name,
    dataset_source,
    model_name,
    learning_rate=1e-3,
    epochs=10,
    batch_size=8,
    val_split=0.2,
    subset_size=None,
    image_size=128,
    device_preference="auto",
    checkpoint_every=5,
    run_id=None,
    progress_callback=None,
    stop_event=None,
    generate_previews=False,
):
    """
    Run a full training job from scratch. Returns a dict with run_id,
    final metrics history, checkpoint paths, and the resolved device used.

    progress_callback, if provided, is called after every epoch with a
    dict of that epoch's metrics — this is the hook Stage 5/6 will use to
    stream live progress to the UI.
    """
    run_id = run_id or f"{model_name}_{dataset_name}_{time.strftime('%Y-%m-%d_%H-%M-%S')}_{uuid.uuid4().hex[:4]}"

    device, device_label = resolve_device(device_preference)

    train_loader, val_loader, total_pairs_used = build_dataloaders(
        dataset_name, dataset_source,
        image_size=image_size, batch_size=batch_size,
        val_split=val_split, subset_size=subset_size,
    )

    model = model_defs.build_model(model_name).to(device)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = BCEDiceLoss()

    config = {
        "architecture": model_name,
        "dataset_name": dataset_name,
        "dataset_source": dataset_source,
        "learning_rate": learning_rate,
        "batch_size": batch_size,
        "val_split": val_split,
        "subset_size": subset_size,
        "image_size": image_size,
        "total_pairs_used": total_pairs_used,
    }

    metrics_history, checkpoint_paths = _run_epoch_loop(
        model, optimizer, loss_fn, train_loader, val_loader, device,
        start_epoch=1, end_epoch=epochs, checkpoint_every=checkpoint_every,
        run_id=run_id, config=config, metrics_history=[],
        progress_callback=progress_callback, stop_event=stop_event,
        generate_previews=generate_previews,
    )

    return {
        "run_id": run_id,
        "device_used": device_label,
        "config": config,
        "metrics_history": metrics_history,
        "checkpoint_paths": checkpoint_paths,
    }


def resume_training(
    checkpoint_path,
    additional_epochs,
    expected_architecture=None,
    expected_dataset_name=None,
    expected_dataset_source=None,
    device_preference="auto",
    checkpoint_every=5,
    progress_callback=None,
    stop_event=None,
    generate_previews=False,
):
    """
    Resume training from a saved checkpoint for additional_epochs more
    epochs. Restores model weights, optimizer state, and continues
    appending to the same metrics history and the same run's checkpoint
    folder.

    If expected_architecture / expected_dataset_name / expected_dataset_source
    are provided (e.g. from what the student selected in the UI) and they
    don't match what's actually stored in the checkpoint, raises
    CheckpointMismatchError with a clear message rather than silently
    proceeding with mismatched settings.
    """
    checkpoint = load_checkpoint(checkpoint_path)
    config = checkpoint["config"]

    if expected_architecture is not None and expected_architecture != config["architecture"]:
        raise CheckpointMismatchError(
            f"Architecture mismatch: this checkpoint was trained with "
            f"'{config['architecture']}', but '{expected_architecture}' was selected. "
            f"Select '{config['architecture']}' to resume this checkpoint."
        )
    if expected_dataset_name is not None and expected_dataset_name != config["dataset_name"]:
        raise CheckpointMismatchError(
            f"Dataset mismatch: this checkpoint was trained on "
            f"'{config['dataset_name']}', but '{expected_dataset_name}' was selected. "
            f"Select '{config['dataset_name']}' to resume this checkpoint."
        )
    if expected_dataset_source is not None and expected_dataset_source != config["dataset_source"]:
        raise CheckpointMismatchError(
            f"Dataset source mismatch: this checkpoint used a '{config['dataset_source']}' "
            f"dataset, but source '{expected_dataset_source}' was selected."
        )

    device, device_label = resolve_device(device_preference)

    train_loader, val_loader, _ = build_dataloaders(
        config["dataset_name"], config["dataset_source"],
        image_size=config["image_size"], batch_size=config["batch_size"],
        val_split=config["val_split"], subset_size=config["subset_size"],
    )

    model = model_defs.build_model(config["architecture"]).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])

    optimizer = optim.Adam(model.parameters(), lr=config["learning_rate"])
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

    loss_fn = BCEDiceLoss()

    run_id = os.path.basename(os.path.dirname(checkpoint_path))
    start_epoch = checkpoint["epoch"] + 1
    end_epoch = checkpoint["epoch"] + additional_epochs
    metrics_history = list(checkpoint["metrics_history"])  # copy, don't mutate the loaded checkpoint's list

    metrics_history, checkpoint_paths = _run_epoch_loop(
        model, optimizer, loss_fn, train_loader, val_loader, device,
        start_epoch=start_epoch, end_epoch=end_epoch, checkpoint_every=checkpoint_every,
        run_id=run_id, config=config, metrics_history=metrics_history,
        progress_callback=progress_callback, stop_event=stop_event,
        generate_previews=generate_previews,
    )

    return {
        "run_id": run_id,
        "device_used": device_label,
        "config": config,
        "metrics_history": metrics_history,
        "checkpoint_paths": checkpoint_paths,
        "resumed_from_epoch": checkpoint["epoch"],
    }


def delete_checkpoint(checkpoint_path):
    """
    Delete a single checkpoint file. If it was the last file in its run's
    folder, the now-empty folder is removed too. Validates the path is
    actually inside CHECKPOINTS_ROOT to prevent deleting arbitrary files.
    """
    checkpoint_path = os.path.abspath(checkpoint_path)
    checkpoints_root_abs = os.path.abspath(CHECKPOINTS_ROOT)

    if not checkpoint_path.startswith(checkpoints_root_abs + os.sep):
        raise ValueError("Refusing to delete a path outside the checkpoints folder.")
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    os.remove(checkpoint_path)

    run_dir = os.path.dirname(checkpoint_path)
    if os.path.isdir(run_dir) and not os.listdir(run_dir):
        os.rmdir(run_dir)


def list_checkpoints():
    """
    Scan the checkpoints folder and return metadata for every saved
    checkpoint across all runs — used by the Stage 5 API and the Stage 7
    "Resume Training" screen.
    """
    results = []
    if not os.path.isdir(CHECKPOINTS_ROOT):
        return results

    for run_id in sorted(os.listdir(CHECKPOINTS_ROOT)):
        run_dir = os.path.join(CHECKPOINTS_ROOT, run_id)
        if not os.path.isdir(run_dir):
            continue

        for filename in sorted(os.listdir(run_dir)):
            if not filename.endswith(".pt"):
                continue
            path = os.path.join(run_dir, filename)
            try:
                ckpt = torch.load(path, weights_only=False, map_location="cpu")
                results.append({
                    "run_id": run_id,
                    "filename": filename,
                    "path": path,
                    "epoch": ckpt["epoch"],
                    "architecture": ckpt["config"]["architecture"],
                    "dataset_name": ckpt["config"]["dataset_name"],
                    "dataset_source": ckpt["config"]["dataset_source"],
                    "learning_rate": ckpt["config"]["learning_rate"],
                    "latest_train_loss": ckpt["metrics_history"][-1]["train_loss"] if ckpt["metrics_history"] else None,
                })
            except Exception:
                continue  # skip unreadable/corrupt checkpoint files

    return results
