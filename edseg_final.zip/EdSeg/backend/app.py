"""
SegLearn backend — Stage 5

Adds the full API layer wrapping datasets (Stage 1), models (Stage 2),
training + checkpointing (Stage 3), and resume logic (Stage 4) into HTTP
endpoints. Training runs in a background thread (job_manager.py) so the
server stays responsive for status polling and stop requests.

Endpoints:
  GET  /api/ping
  GET  /api/datasets
  POST /api/datasets/upload
  GET  /api/datasets/<name>/preview
  GET  /api/models/architectures            -> list selectable model architectures
  GET  /api/devices                         -> which compute devices are available
  POST /api/train/start                     -> start a fresh training run
  GET  /api/train/status/<run_id>           -> poll progress / result
  POST /api/train/stop/<run_id>             -> stop an in-progress run
  GET  /api/checkpoints                     -> list all saved checkpoints
  POST /api/train/resume                    -> resume from a checkpoint
  POST /api/model/save                      -> save a checkpoint as a named model
  GET  /api/models                          -> list saved models
  POST /api/inference                       -> run a saved model on a new image

Still no UI wiring — that's Stage 6 onward. This stage is verified via
direct API calls (curl / a test script), same approach as prior stages.
"""

from flask import Flask, jsonify, send_from_directory, request
import os

import dataset_utils
import models as model_defs
import job_manager
import tuning as tuning_module
import model_library
import inference as inference_module
import results as results_module
from train import list_checkpoints, delete_checkpoint, CheckpointMismatchError
from device_utils import detect_available_devices

from paths import get_bundled_resource_root

FRONTEND_DIR = os.path.join(get_bundled_resource_root(), "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")


@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/api/ping")
def ping():
    return jsonify({"status": "ok", "message": "Backend is reachable."})


# ---------------------------------------------------------------------------
# Datasets (Stage 1)
# ---------------------------------------------------------------------------

@app.route("/api/datasets")
def list_datasets():
    bundled = dataset_utils.list_bundled_datasets()
    custom = dataset_utils.list_custom_datasets()
    return jsonify({"datasets": bundled + custom})


@app.route("/api/datasets/upload", methods=["POST"])
def upload_dataset():
    if "file" not in request.files:
        return jsonify({"error": "No file was included in the upload."}), 400

    file = request.files["file"]
    dataset_name = request.form.get("name", "").strip()

    if file.filename == "":
        return jsonify({"error": "No file was selected."}), 400
    if not dataset_name:
        return jsonify({"error": "Please provide a name for this dataset."}), 400

    try:
        metadata = dataset_utils.save_uploaded_zip(file, dataset_name)
        return jsonify({"dataset": metadata})
    except dataset_utils.DatasetValidationError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Unexpected error while processing upload: {e}"}), 500


@app.route("/api/datasets/<name>/preview")
def preview_dataset(name):
    source = request.args.get("source", "bundled")
    count = int(request.args.get("count", 4))

    try:
        preview = dataset_utils.get_preview(name, source, max_count=count)
        return jsonify(preview)
    except dataset_utils.DatasetValidationError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Could not load dataset '{name}': {e}"}), 500


# ---------------------------------------------------------------------------
# Models & devices (Stage 2 / Stage 3)
# ---------------------------------------------------------------------------

@app.route("/api/models/architectures")
def list_architectures():
    """List selectable model architectures for the training setup screen."""
    result = [
        {"name": cls.name, "display_name": cls.display_name}
        for cls in model_defs.MODEL_REGISTRY.values()
    ]
    return jsonify({"architectures": result})


@app.route("/api/devices")
def list_devices():
    """Report which compute devices (cpu/cuda/mps) are available on this machine."""
    return jsonify(detect_available_devices())


# ---------------------------------------------------------------------------
# Training (Stage 3) — start / status / stop
# ---------------------------------------------------------------------------

@app.route("/api/train/start", methods=["POST"])
def start_training():
    """
    JSON body:
      dataset_name, dataset_source, model_name, learning_rate, epochs,
      batch_size, val_split, subset_size (optional), device_preference (optional)
    """
    body = request.get_json(force=True)

    required = ["dataset_name", "dataset_source", "model_name"]
    missing = [f for f in required if f not in body]
    if missing:
        return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

    try:
        run_id = job_manager.start_training_job(
            dataset_name=body["dataset_name"],
            dataset_source=body["dataset_source"],
            model_name=body["model_name"],
            learning_rate=float(body.get("learning_rate", 1e-3)),
            epochs=int(body.get("epochs", 10)),
            batch_size=int(body.get("batch_size", 8)),
            val_split=float(body.get("val_split", 0.2)),
            subset_size=body.get("subset_size"),
            device_preference=body.get("device_preference", "auto"),
            checkpoint_every=int(body.get("checkpoint_every", 5)),
        )
        return jsonify({"run_id": run_id})
    except Exception as e:
        return jsonify({"error": f"Could not start training: {e}"}), 400


@app.route("/api/train/status/<run_id>")
def training_status(run_id):
    status = job_manager.get_job_status(run_id)
    if status is None:
        return jsonify({"error": f"No run found with id '{run_id}'."}), 404
    return jsonify(status)


@app.route("/api/train/stop/<run_id>", methods=["POST"])
def stop_training(run_id):
    stopped = job_manager.stop_job(run_id)
    if not stopped:
        return jsonify({"error": f"No run found with id '{run_id}'."}), 404
    return jsonify({"message": f"Stop requested for run '{run_id}'."})


# ---------------------------------------------------------------------------
# Hyperparameter tuning (Stage 9)
# ---------------------------------------------------------------------------

@app.route("/api/tuning/params")
def get_sweepable_params():
    """List which hyperparameters can be swept, plus the hard caps in effect."""
    return jsonify({
        "sweepable_params": tuning_module.SWEEPABLE_PARAMS,
        "max_params_to_sweep": tuning_module.MAX_PARAMS_TO_SWEEP,
        "max_values_per_param": tuning_module.MAX_VALUES_PER_PARAM,
        "max_total_trials": tuning_module.MAX_TOTAL_TRIALS,
        "max_epochs_per_trial": tuning_module.MAX_EPOCHS_PER_TRIAL,
    })


@app.route("/api/tuning/start", methods=["POST"])
def start_tuning():
    """
    JSON body:
      dataset_name, dataset_source, model_name, learning_rate, epochs,
      batch_size, val_split, subset_size, device_preference (the base config —
      same shape as /api/train/start), plus:
      sweep_params (required) — a list of {"param": <name>, "values": [...]}.
      One entry sweeps a single parameter; multiple entries run a full grid
      search across every combination of their values.
    """
    body = request.get_json(force=True)

    required = ["dataset_name", "dataset_source", "model_name", "sweep_params"]
    missing = [f for f in required if f not in body]
    if missing:
        return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

    sweep_params = body["sweep_params"]
    if not isinstance(sweep_params, list) or len(sweep_params) == 0:
        return jsonify({"error": "sweep_params must be a non-empty list."}), 400
    for entry in sweep_params:
        if "param" not in entry or "values" not in entry or not isinstance(entry["values"], list) or len(entry["values"]) == 0:
            return jsonify({"error": "Each sweep_params entry needs a 'param' name and a non-empty 'values' list."}), 400

    base_config = {
        "dataset_name": body["dataset_name"],
        "dataset_source": body["dataset_source"],
        "model_name": body["model_name"],
        "learning_rate": float(body.get("learning_rate", 1e-3)),
        "epochs": int(body.get("epochs", 10)),
        "batch_size": int(body.get("batch_size", 8)),
        "val_split": float(body.get("val_split", 0.2)),
        "subset_size": body.get("subset_size"),
        "device_preference": body.get("device_preference", "auto"),
    }

    try:
        tuning_id = job_manager.start_tuning_job(base_config, sweep_params)
        return jsonify({"tuning_id": tuning_id})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Could not start tuning sweep: {e}"}), 400


@app.route("/api/tuning/status/<tuning_id>")
def tuning_status(tuning_id):
    status = job_manager.get_tuning_status(tuning_id)
    if status is None:
        return jsonify({"error": f"No tuning run found with id '{tuning_id}'."}), 404
    return jsonify(status)


@app.route("/api/tuning/stop/<tuning_id>", methods=["POST"])
def stop_tuning(tuning_id):
    stopped = job_manager.stop_tuning_job(tuning_id)
    if not stopped:
        return jsonify({"error": f"No tuning run found with id '{tuning_id}'."}), 404
    return jsonify({"message": f"Stop requested for tuning run '{tuning_id}'."})


# ---------------------------------------------------------------------------
# Checkpoints & resume (Stage 4)
# ---------------------------------------------------------------------------

@app.route("/api/checkpoints")
def get_checkpoints():
    return jsonify({"checkpoints": list_checkpoints()})


@app.route("/api/checkpoints/delete", methods=["POST"])
def delete_checkpoint_endpoint():
    """JSON body: checkpoint_path"""
    body = request.get_json(force=True)
    checkpoint_path = body.get("checkpoint_path")

    if not checkpoint_path:
        return jsonify({"error": "Missing required field: checkpoint_path"}), 400

    try:
        delete_checkpoint(checkpoint_path)
        return jsonify({"message": "Checkpoint deleted."})
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Could not delete checkpoint: {e}"}), 500


@app.route("/api/train/resume", methods=["POST"])
def resume_training_endpoint():
    """
    JSON body:
      checkpoint_path, additional_epochs,
      expected_architecture, expected_dataset_name, expected_dataset_source (all optional but recommended),
      device_preference (optional)
    """
    body = request.get_json(force=True)

    if "checkpoint_path" not in body:
        return jsonify({"error": "Missing required field: checkpoint_path"}), 400

    try:
        run_id = job_manager.start_resume_job(
            checkpoint_path=body["checkpoint_path"],
            additional_epochs=int(body.get("additional_epochs", 5)),
            expected_architecture=body.get("expected_architecture"),
            expected_dataset_name=body.get("expected_dataset_name"),
            expected_dataset_source=body.get("expected_dataset_source"),
            device_preference=body.get("device_preference", "auto"),
            checkpoint_every=int(body.get("checkpoint_every", 5)),
        )
        return jsonify({"run_id": run_id})
    except CheckpointMismatchError as e:
        return jsonify({"error": str(e)}), 400
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": f"Could not resume training: {e}"}), 400


# ---------------------------------------------------------------------------
# Model library (final save/load, distinct from mid-training checkpoints)
# ---------------------------------------------------------------------------

@app.route("/api/model/save", methods=["POST"])
def save_model_endpoint():
    """JSON body: checkpoint_path, name"""
    body = request.get_json(force=True)

    if "checkpoint_path" not in body or "name" not in body:
        return jsonify({"error": "Missing required field(s): checkpoint_path, name"}), 400

    try:
        metadata = model_library.save_model(body["checkpoint_path"], body["name"])
        return jsonify({"model": metadata})
    except model_library.ModelLibraryError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Could not save model: {e}"}), 500


@app.route("/api/models")
def list_saved_models_endpoint():
    return jsonify({"models": model_library.list_saved_models()})


# ---------------------------------------------------------------------------
# Inference (preview of Stage 10)
# ---------------------------------------------------------------------------

@app.route("/api/inference", methods=["POST"])
def run_inference_endpoint():
    """
    multipart/form-data:
      model_name (required)
      image (required, file)
      mask (optional, file) — if provided, single-image Dice/IoU are computed
      device_preference (optional)
    """
    model_name = request.form.get("model_name")
    if not model_name:
        return jsonify({"error": "Missing required field: model_name"}), 400
    if "image" not in request.files:
        return jsonify({"error": "No image file was included."}), 400

    image_file = request.files["image"]
    mask_file = request.files.get("mask")
    device_preference = request.form.get("device_preference", "auto")

    try:
        result = inference_module.run_inference(model_name, image_file, mask_file, device_preference)
        return jsonify(result)
    except model_library.ModelLibraryError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": f"Inference failed: {e}"}), 500


# ---------------------------------------------------------------------------
# Results (Stage 8) — confusion matrix, sample predictions, saved reports
# ---------------------------------------------------------------------------

@app.route("/api/results")
def get_results():
    """Query param: checkpoint_path (required)"""
    checkpoint_path = request.args.get("checkpoint_path")
    if not checkpoint_path:
        return jsonify({"error": "Missing required query param: checkpoint_path"}), 400

    try:
        summary = results_module.build_results_summary(checkpoint_path)
        return jsonify(summary)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": f"Could not compute results: {e}"}), 500


@app.route("/api/results/save_report", methods=["POST"])
def save_report_endpoint():
    """JSON body: checkpoint_path"""
    body = request.get_json(force=True)
    checkpoint_path = body.get("checkpoint_path")
    if not checkpoint_path:
        return jsonify({"error": "Missing required field: checkpoint_path"}), 400

    try:
        report_info = results_module.save_report(checkpoint_path)
        return jsonify(report_info)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": f"Could not save report: {e}"}), 500


@app.route("/api/reports/<filename>")
def download_report(filename):
    """Serve a previously saved report file for download."""
    if not os.path.exists(os.path.join(results_module.REPORTS_ROOT, filename)):
        return jsonify({"error": f"Report '{filename}' not found."}), 404
    return send_from_directory(results_module.REPORTS_ROOT, filename, as_attachment=True)


if __name__ == "__main__":
    print("Starting SegLearn backend...")
    print("Open http://127.0.0.1:5000 in your browser.")
    app.run(host="127.0.0.1", port=5000, debug=True, threaded=True)
