"""
EdSeg desktop launcher.

This is what turns EdSeg from "run python backend/app.py and open a
browser" into an actual double-click desktop app: it starts the same
Flask backend in a background thread, then opens a native OS window
(via pywebview) pointing at it — no visible browser chrome, no terminal,
no manual step for the student.

This file is what PyInstaller packages into the final .exe / .app.

Important differences from running backend/app.py directly for development:
  - debug=False and use_reloader=False — Flask's debug reloader spawns a
    second process and watches files for changes, neither of which makes
    sense (or works reliably) inside a frozen/bundled executable.
  - The server always binds to 127.0.0.1 (loopback only) — this app is
    never meant to be reachable from other machines on the network.
  - If PyInstaller has bundled the app (sys.frozen is set), paths are
    resolved relative to the bundle's temp extraction folder instead of
    the source tree.
  - A loading screen is shown IMMEDIATELY (before the backend is even
    guaranteed to be ready), then the window automatically swaps to the
    real app once the backend responds. Without this, students would see
    a blank/white window for however long PyTorch takes to load — which
    can be a genuinely long time on a CUDA build — and reasonably assume
    the app had frozen or crashed.
"""

import os
import sys
import threading
import time

import webview

# How long to wait for the backend before showing an error screen instead
# of the app. CUDA-enabled PyTorch builds can take a while to initialize
# on first launch (extracting the bundle, loading CUDA libraries), so this
# is intentionally generous rather than tuned for the CPU-only case.
STARTUP_TIMEOUT_SECONDS = 120

LOADING_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  html, body {
    margin: 0; height: 100%;
    background: #0b0e14;
    color: #e7eaf0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
    display: flex; align-items: center; justify-content: center;
  }
  .box { text-align: center; }
  .brand { font-size: 22px; font-weight: 700; margin-bottom: 18px; }
  .brand .accent {
    background: linear-gradient(135deg, #5b8def, #8b5cf6);
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .spinner {
    width: 34px; height: 34px; margin: 0 auto 18px auto;
    border: 3px solid #232b3a; border-top-color: #5b8def;
    border-radius: 50%; animation: spin 0.9s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .status { font-size: 13px; color: #8b93a7; }
</style>
</head>
<body>
  <div class="box">
    <div class="brand">Ed<span class="accent">Seg</span></div>
    <div class="spinner"></div>
    <div class="status">Starting up&hellip; this can take a little while the first time.</div>
  </div>
</body>
</html>
"""

ERROR_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  html, body {
    margin: 0; height: 100%;
    background: #0b0e14;
    color: #e7eaf0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
    display: flex; align-items: center; justify-content: center;
  }
  .box { text-align: center; max-width: 440px; padding: 20px; }
  .title { font-size: 18px; font-weight: 700; margin-bottom: 10px; color: #ef4444; }
  .msg { font-size: 13px; color: #8b93a7; line-height: 1.6; }
</style>
</head>
<body>
  <div class="box">
    <div class="title">EdSeg didn't start in time</div>
    <div class="msg">
      The backend took longer than expected to respond. Try closing this
      window and reopening the app. If this keeps happening, check that
      no other program is using port 5000, or ask whoever set this app up
      for help.
    </div>
  </div>
</body>
</html>
"""


def resource_path(relative_path):
    """
    Resolve a path that works both when running from source AND when
    running as a PyInstaller-frozen executable (which unpacks bundled
    files into a temporary folder referenced by sys._MEIPASS).
    """
    if getattr(sys, "frozen", False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def start_flask_server():
    """Import and run the Flask app in this thread (blocking)."""
    backend_dir = resource_path("backend")
    sys.path.insert(0, backend_dir)

    # Imported here (not at module level) so `backend_dir` is on sys.path first
    import app as flask_app_module

    flask_app_module.app.run(
        host="127.0.0.1",
        port=5000,
        debug=False,
        use_reloader=False,
        threaded=True,
    )


def wait_for_server(url, timeout):
    """Poll the server until it responds or the timeout elapses."""
    import urllib.request
    import urllib.error

    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except (urllib.error.URLError, ConnectionError, OSError):
            time.sleep(0.3)
    return False


def wait_then_switch(window):
    """
    Runs in a background thread once the webview GUI loop has started.
    Polls the backend, then swaps the (already-visible) loading window
    over to the real app, or to an error screen if it never comes up.
    """
    ready = wait_for_server("http://127.0.0.1:5000/api/ping", timeout=STARTUP_TIMEOUT_SECONDS)
    if ready:
        window.load_url("http://127.0.0.1:5000")
    else:
        window.load_html(ERROR_HTML)


def main():
    server_thread = threading.Thread(target=start_flask_server, daemon=True)
    server_thread.start()

    # Show the loading screen immediately — don't wait for the backend
    # before the student sees *something*.
    window = webview.create_window(
        "EdSeg",
        html=LOADING_HTML,
        width=1440,
        height=900,
        min_size=(1000, 700),
    )

    # webview.start()'s `func` runs in a background thread after the GUI
    # loop is already running, so the loading screen is visible right away
    # while this polls for the backend in parallel.
    # NOTE: `args` must be an iterable of arguments (a tuple), not the
    # bare window object — passing it un-wrapped causes pywebview to try
    # to unpack it incorrectly.
    webview.start(wait_then_switch, (window,))


if __name__ == "__main__":
    main()
