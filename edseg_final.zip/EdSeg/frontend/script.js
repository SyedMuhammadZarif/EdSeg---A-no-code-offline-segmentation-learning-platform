// EdSeg — Visual overhaul
// Dark app-shell theme: topbar, left sidebar navigation, main content
// (unchanged screen logic), right sidebar with live status/dataset/
// architecture/device info. All icons are hand-authored inline SVG so
// the app has zero external/CDN dependencies and stays fully offline.

const ICONS = {
  brain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 5 3 3 0 0 0 2 5v1a3 3 0 0 0 6 0V6a2 2 0 0 0-3-2z"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 5 3 3 0 0 1-2 5v1a3 3 0 0 1-6 0V6a2 2 0 0 1 3-2z"/></svg>',
  database: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
  "bar-chart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="20" x2="6" y2="12"/><line x1="12" y1="20" x2="12" y2="6"/><line x1="18" y1="20" x2="18" y2="14"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
  flask: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6"/><path d="M10 3v6l-6 10a1.5 1.5 0 0 0 1.3 2.2h13.4A1.5 1.5 0 0 0 20 19L14 9V3"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  scale: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="3" x2="12" y2="21"/><path d="M5 7h14"/><path d="M5 7l-3 7a3.5 3.5 0 0 0 6 0z"/><path d="M19 7l-3 7a3.5 3.5 0 0 0 6 0z"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  "check-circle": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
  cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="15" x2="23" y2="15"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="15" x2="4" y2="15"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
};

function renderIcons(root) {
  const scope = root || document;
  scope.querySelectorAll("[data-icon]").forEach((el) => {
    const key = el.getAttribute("data-icon");
    if (ICONS[key] && !el.dataset.iconRendered) {
      el.innerHTML = ICONS[key];
      el.dataset.iconRendered = "1";
    }
  });
}

// ---------------------------------------------------------------------------
// Light / dark theme toggle
// ---------------------------------------------------------------------------

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  document.getElementById("theme-icon-sun").classList.toggle("hidden", theme === "light");
  document.getElementById("theme-icon-moon").classList.toggle("hidden", theme === "dark");
  try { localStorage.setItem("edseg-theme", theme); } catch (e) { /* ignore if unavailable */ }
}

function initTheme() {
  let saved = "dark";
  try { saved = localStorage.getItem("edseg-theme") || "dark"; } catch (e) { /* default to dark */ }
  applyTheme(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") || "dark";
  applyTheme(current === "dark" ? "light" : "dark");
}

// ---------------------------------------------------------------------------
// Sidebar navigation
// ---------------------------------------------------------------------------

function setActiveNavItem(navKey) {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.toggle("active", item.dataset.nav === navKey);
  });
}

function setStepsIndicatorVisible(visible) {
  document.querySelector(".steps-indicator").classList.toggle("hidden", !visible);
}

function handleSidebarNav(navKey) {
  switch (navKey) {
    case "dataset":
      goToStep(1);
      break;
    case "setup":
      if (state.selectedDataset) {
        goToStep(2);
      } else {
        alert("Select a dataset first.");
        goToStep(1);
      }
      break;
    case "train":
      if (state.currentRunId || state.lastCheckpointPath) {
        goToStep(3);
        setActiveNavItem("train");
      } else {
        alert("No training in progress yet. Start one from Model Setup.");
        goToStep(state.selectedDataset ? 2 : 1);
      }
      break;
    case "results":
      if (state.lastCheckpointPath) {
        goToResultsScreen();
      } else {
        alert("Train a model first to see its results.");
        goToStep(1);
      }
      break;
    case "resume":
      goToResumeScreen();
      break;
    case "tuning":
      if (state.selectedDataset) {
        goToTuningSetupScreen();
      } else {
        alert("Select a dataset first.");
        goToStep(1);
      }
      break;
    case "library":
      goToModelLibraryScreen();
      break;
    case "testing":
      goToModelLibraryScreen();
      setActiveNavItem("testing");
      break;
    case "compare":
      goToCompareScreen();
      break;
    case "concepts":
      openConceptsModal();
      break;
  }
}

// ---------------------------------------------------------------------------
// Right sidebar: live info panels
// ---------------------------------------------------------------------------

function renderSidebarQuickStatus(ok, message) {
  const dot = document.getElementById("quick-status-dot");
  const text = document.getElementById("quick-status-text");
  const sub = document.getElementById("quick-status-sub");
  dot.className = "status-dot " + (ok ? "status-dot-ok" : "status-dot-error");
  text.textContent = ok ? "Backend Online" : "Backend Unreachable";
  sub.textContent = ok ? "API is ready" : message || "Check the server";

  const topDot = document.getElementById("topbar-status-dot");
  const topText = document.getElementById("topbar-status-text");
  topDot.className = "status-dot " + (ok ? "status-dot-ok" : "status-dot-error");
  topText.textContent = ok ? "Backend Online" : "Backend Offline";
}

function renderSidebarDatasetInfo(datasetMeta, previewPairs) {
  const container = document.getElementById("sidebar-dataset-info");
  const thumbs = (previewPairs || []).slice(0, 3).map((p) => `<img src="${p.image}" alt="" />`).join("");

  container.innerHTML = `
    <div class="info-row"><span class="info-row-label">Name</span><span class="info-row-value">${datasetMeta.display_name || datasetMeta.name}</span></div>
    <div class="info-row"><span class="info-row-label">Source</span><span class="info-row-value">${datasetMeta.source}</span></div>
    <div class="info-row"><span class="info-row-label">Total pairs</span><span class="info-row-value">${datasetMeta.count}</span></div>
    ${thumbs ? `<div class="sidebar-dataset-thumbs">${thumbs}</div>` : ""}
  `;
}

function renderSidebarArchitectures() {
  const container = document.getElementById("sidebar-architectures-list");
  if (!state.architectures.length) return;

  container.innerHTML = state.architectures.map((arch, i) => `
    <div class="info-list-item">
      <span class="info-list-item-name">${arch.display_name}</span>
      ${i === 0 ? '<span class="badge">default</span>' : ""}
    </div>
  `).join("");
}

function renderSidebarDevices() {
  const container = document.getElementById("sidebar-devices-list");
  const devices = state.devices;
  if (!devices || Object.keys(devices).length === 0) return;

  const rows = [
    { key: "cpu", label: "CPU" },
    { key: "cuda", label: "CUDA (GPU)" },
    { key: "mps", label: "MPS (Apple Silicon)" },
  ];

  container.innerHTML = rows.map((r) => {
    const available = !!devices[r.key];
    return `
      <div class="info-list-item">
        <span class="info-list-item-name">${r.label}</span>
        <span class="badge ${available ? "badge-success" : "badge-muted"}">${available ? "Available" : "Not available"}</span>
      </div>
    `;
  }).join("");
}

const LR_VALUES = [0.0001, 0.0005, 0.001, 0.005, 0.01];
const BATCH_VALUES = [2, 4, 8, 16, 32];

const state = {
  selectedDataset: null,   // { name, source, count }
  architectures: [],
  devices: {},
  selectedDevice: "auto",
  currentRunId: null,
  pollTimer: null,
  totalEpochsRequested: null,
  lossHistory: [],   // [{epoch, train_loss, val_loss}]
  metricHistory: [], // [{epoch, val_dice, val_iou}]
};

// ---------------------------------------------------------------------------
// Backend connectivity
// ---------------------------------------------------------------------------

async function checkBackendConnection() {
  try {
    const response = await fetch("/api/ping");
    if (!response.ok) throw new Error(`Server responded with status ${response.status}`);
    await response.json();
    renderSidebarQuickStatus(true);
  } catch (err) {
    renderSidebarQuickStatus(false, err.message);
  }
}

// ---------------------------------------------------------------------------
// Step navigation
// ---------------------------------------------------------------------------

function hideAllSections() {
  ["step-1", "step-2", "step-3", "step-resume", "step-results", "step-tuning-setup", "step-tuning-results",
   "step-model-library", "step-testing", "step-compare"].forEach((id) => {
    document.getElementById(id).classList.add("hidden");
  });
}

function goToStep(stepNumber) {
  hideAllSections();
  document.getElementById(`step-${stepNumber}`).classList.remove("hidden");
  [1, 2, 3].forEach((n) => {
    const dot = document.querySelector(`.step-dot[data-step="${n}"]`);
    dot.classList.toggle("active", n === stepNumber);
    dot.classList.toggle("done", n < stepNumber);
  });
  setStepsIndicatorVisible(true);
  setActiveNavItem(stepNumber === 1 ? "dataset" : stepNumber === 2 ? "setup" : "train");
}

function goToResumeScreen() {
  hideAllSections();
  document.getElementById("step-resume").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("resume");
  [1, 2, 3].forEach((n) => {
    document.querySelector(`.step-dot[data-step="${n}"]`).classList.remove("active", "done");
  });
  loadCheckpointsForResume();
}

// ---------------------------------------------------------------------------
// Step 1: Dataset selection (reused/extended from Stage 1)
// ---------------------------------------------------------------------------

async function loadDatasetList() {
  const select = document.getElementById("dataset-select");
  const previewBtn = document.getElementById("preview-btn");

  try {
    const response = await fetch("/api/datasets");
    const data = await response.json();

    select.innerHTML = '<option value="">-- Select a dataset --</option>';
    data.datasets.forEach((ds) => {
      const option = document.createElement("option");
      option.value = JSON.stringify({ name: ds.name, source: ds.source, count: ds.count });
      option.textContent = `${ds.display_name} (${ds.source}, ${ds.count} pairs)`;
      select.appendChild(option);
    });

    select.onchange = () => {
      previewBtn.disabled = select.value === "";
      document.getElementById("to-step-2-btn").disabled = true;
    };
  } catch (err) {
    console.error("Failed to load dataset list:", err);
  }
}

async function previewSelectedDataset() {
  const select = document.getElementById("dataset-select");
  const summary = document.getElementById("preview-summary");
  const grid = document.getElementById("preview-grid");

  if (!select.value) return;
  const { name, source, count } = JSON.parse(select.value);

  summary.textContent = "Loading preview...";
  grid.innerHTML = "";

  try {
    const response = await fetch(`/api/datasets/${encodeURIComponent(name)}/preview?source=${source}&count=4`);
    const data = await response.json();

    if (data.error) {
      summary.textContent = `Error: ${data.error}`;
      return;
    }

    summary.textContent = `Showing ${data.pairs.length} of ${data.total_count} total pairs.`;
    renderSidebarDatasetInfo({ name, display_name: name.replace(/_/g, " "), source, count }, data.pairs);

    data.pairs.forEach((pair) => {
      const card = document.createElement("div");
      card.className = "preview-pair";
      card.innerHTML = `
        <div style="display:flex; gap:6px; justify-content:center;">
          <img src="${pair.image}" alt="image" />
          <img src="${pair.mask}" alt="mask" />
        </div>
        <div class="labels"><span>Image</span><span>Mask</span></div>
        <div class="filename">${pair.filename}</div>
      `;
      grid.appendChild(card);
    });

    state.selectedDataset = { name, source, count };
    document.getElementById("to-step-2-btn").disabled = false;
  } catch (err) {
    summary.textContent = `Error loading preview: ${err.message}`;
  }
}

async function uploadDataset() {
  const nameInput = document.getElementById("upload-name");
  const fileInput = document.getElementById("upload-file");
  const messageEl = document.getElementById("upload-message");

  const name = nameInput.value.trim();
  const file = fileInput.files[0];

  messageEl.className = "message";
  messageEl.textContent = "";

  if (!name) {
    messageEl.classList.add("error");
    messageEl.textContent = "Please enter a name for the dataset.";
    return;
  }
  if (!file) {
    messageEl.classList.add("error");
    messageEl.textContent = "Please choose a .zip file to upload.";
    return;
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("name", name);

  messageEl.textContent = "Uploading and validating...";

  try {
    const response = await fetch("/api/datasets/upload", { method: "POST", body: formData });
    const data = await response.json();

    if (!response.ok) {
      messageEl.classList.add("error");
      messageEl.textContent = `❌ ${data.error}`;
      return;
    }

    messageEl.classList.add("success");
    messageEl.textContent = `✅ Uploaded "${data.dataset.display_name}" — ${data.dataset.count} valid pairs found.`;
    await loadDatasetList();
  } catch (err) {
    messageEl.classList.add("error");
    messageEl.textContent = `❌ Upload failed: ${err.message}`;
  }
}

// ---------------------------------------------------------------------------
// Step 2: Model & hyperparameters
// ---------------------------------------------------------------------------

async function loadArchitectures() {
  const select = document.getElementById("architecture-select");
  const note = document.getElementById("architecture-note");

  const response = await fetch("/api/models/architectures");
  const data = await response.json();
  state.architectures = data.architectures;
  renderSidebarArchitectures();

  select.innerHTML = "";
  data.architectures.forEach((arch) => {
    const option = document.createElement("option");
    option.value = arch.name;
    option.textContent = arch.display_name;
    select.appendChild(option);
  });

  const updateNote = () => {
    if (select.value === "real_unet") {
      note.textContent = "⚠️ This is a large, production-scale model. Training will take noticeably longer (potentially many minutes) compared to the other options.";
    } else {
      note.textContent = "";
    }
  };
  select.onchange = updateNote;
  updateNote();
}

function renderDeviceOptions(containerId, selectedKey, onSelect) {
  const container = document.getElementById(containerId);
  const devices = state.devices;

  const options = [
    { key: "auto", label: "Auto (recommended)", available: true },
    { key: "cpu", label: "CPU", available: true },
    { key: "cuda", label: "GPU (NVIDIA CUDA)", available: devices.cuda },
    { key: "mps", label: "GPU (Apple Silicon)", available: devices.mps },
  ];

  container.innerHTML = "";
  options.forEach((opt) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "device-option" + (opt.key === selectedKey() ? " selected" : "");
    btn.textContent = opt.label + (opt.available ? "" : " (not available)");
    btn.disabled = !opt.available;
    btn.onclick = () => {
      onSelect(opt.key);
      container.querySelectorAll(".device-option").forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
    };
    container.appendChild(btn);
  });
}

async function loadDevices() {
  const response = await fetch("/api/devices");
  state.devices = await response.json();
  renderSidebarDevices();

  renderDeviceOptions(
    "device-options",
    () => state.selectedDevice,
    (key) => { state.selectedDevice = key; }
  );
}

function setupSliders() {
  const lrSlider = document.getElementById("lr-slider");
  const lrValue = document.getElementById("lr-value");
  const updateLr = () => { lrValue.textContent = LR_VALUES[lrSlider.value]; };
  lrSlider.oninput = updateLr;
  updateLr();

  const epochsSlider = document.getElementById("epochs-slider");
  const epochsValue = document.getElementById("epochs-value");
  const updateEpochs = () => { epochsValue.textContent = epochsSlider.value; };
  epochsSlider.oninput = updateEpochs;
  updateEpochs();

  const batchSlider = document.getElementById("batch-slider");
  const batchValue = document.getElementById("batch-value");
  const updateBatch = () => { batchValue.textContent = BATCH_VALUES[batchSlider.value]; };
  batchSlider.oninput = updateBatch;
  updateBatch();

  const valSplitSlider = document.getElementById("val-split-slider");
  const valSplitValue = document.getElementById("val-split-value");
  const updateValSplit = () => { valSplitValue.textContent = `${valSplitSlider.value}%`; };
  valSplitSlider.oninput = updateValSplit;
  updateValSplit();

  const subsetSlider = document.getElementById("subset-slider");
  const subsetValue = document.getElementById("subset-value");
  const updateSubset = () => { subsetValue.textContent = subsetSlider.value; };
  subsetSlider.oninput = updateSubset;
  updateSubset();
}

function configureSubsetSliderForDataset() {
  const subsetSlider = document.getElementById("subset-slider");
  const subsetValue = document.getElementById("subset-value");
  const count = state.selectedDataset ? state.selectedDataset.count : 24;

  subsetSlider.min = Math.min(4, count);
  subsetSlider.max = count;
  subsetSlider.value = count;
  subsetValue.textContent = count;
}

function getHyperparams() {
  const lrSlider = document.getElementById("lr-slider");
  const epochsSlider = document.getElementById("epochs-slider");
  const batchSlider = document.getElementById("batch-slider");
  const valSplitSlider = document.getElementById("val-split-slider");
  const subsetSlider = document.getElementById("subset-slider");
  const architectureSelect = document.getElementById("architecture-select");

  return {
    architecture: architectureSelect.value,
    learning_rate: LR_VALUES[lrSlider.value],
    epochs: parseInt(epochsSlider.value, 10),
    batch_size: BATCH_VALUES[batchSlider.value],
    val_split: parseInt(valSplitSlider.value, 10) / 100,
    subset_size: parseInt(subsetSlider.value, 10),
    device_preference: state.selectedDevice,
  };
}

// ---------------------------------------------------------------------------
// Resume Training screen (Stage 7)
// ---------------------------------------------------------------------------

const resumeState = {
  checkpoints: [],
  selectedCheckpoint: null,
  selectedDevice: "auto",
  allDatasets: [],
};

async function loadCheckpointsForResume() {
  const listEl = document.getElementById("checkpoint-list");
  const emptyMessage = document.getElementById("checkpoint-empty-message");
  document.getElementById("resume-config-panel").classList.add("hidden");

  const response = await fetch("/api/checkpoints");
  const data = await response.json();
  resumeState.checkpoints = data.checkpoints;

  listEl.innerHTML = "";

  if (resumeState.checkpoints.length === 0) {
    emptyMessage.classList.remove("hidden");
    return;
  }
  emptyMessage.classList.add("hidden");

  resumeState.checkpoints.forEach((ckpt) => {
    const card = document.createElement("div");
    card.className = "checkpoint-card";
    const lossText = ckpt.latest_train_loss !== null && ckpt.latest_train_loss !== undefined
      ? ckpt.latest_train_loss.toFixed(4) : "n/a";
    card.innerHTML = `
      <div class="checkpoint-card-header">
        <div class="checkpoint-title">${ckpt.run_id} — epoch ${ckpt.epoch}</div>
        <button type="button" class="delete-checkpoint-btn" title="Delete this checkpoint">&times;</button>
      </div>
      <div class="checkpoint-meta">
        Architecture: ${ckpt.architecture} &nbsp;|&nbsp;
        Dataset: ${ckpt.dataset_name} (${ckpt.dataset_source}) &nbsp;|&nbsp;
        Learning rate: ${ckpt.learning_rate} &nbsp;|&nbsp;
        Train loss: ${lossText}
      </div>
    `;
    card.onclick = () => selectCheckpointForResume(ckpt, card);

    const deleteBtn = card.querySelector(".delete-checkpoint-btn");
    deleteBtn.onclick = (event) => {
      event.stopPropagation(); // don't also trigger card selection
      deleteCheckpoint(ckpt, card);
    };

    listEl.appendChild(card);
  });
}

async function deleteCheckpoint(checkpoint, cardEl) {
  const confirmed = window.confirm(
    `Delete checkpoint "${checkpoint.run_id} — epoch ${checkpoint.epoch}"? This cannot be undone.`
  );
  if (!confirmed) return;

  const response = await fetch("/api/checkpoints/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ checkpoint_path: checkpoint.path }),
  });

  if (!response.ok) {
    const data = await response.json();
    alert(`Could not delete checkpoint: ${data.error}`);
    return;
  }

  // If the deleted checkpoint was the one currently selected, hide the config panel
  if (resumeState.selectedCheckpoint && resumeState.selectedCheckpoint.path === checkpoint.path) {
    resumeState.selectedCheckpoint = null;
    document.getElementById("resume-config-panel").classList.add("hidden");
  }

  await loadCheckpointsForResume();
}

async function selectCheckpointForResume(checkpoint, cardEl) {
  document.querySelectorAll(".checkpoint-card").forEach((c) => c.classList.remove("selected"));
  cardEl.classList.add("selected");

  resumeState.selectedCheckpoint = checkpoint;

  document.getElementById("resume-checkpoint-label").textContent =
    `${checkpoint.run_id} (epoch ${checkpoint.epoch})`;

  // Populate architecture dropdown, pre-selecting the checkpoint's architecture
  const archSelect = document.getElementById("resume-architecture-select");
  archSelect.innerHTML = "";
  state.architectures.forEach((arch) => {
    const option = document.createElement("option");
    option.value = arch.name;
    option.textContent = arch.display_name;
    archSelect.appendChild(option);
  });
  archSelect.value = checkpoint.architecture;

  // Populate dataset dropdown, pre-selecting the checkpoint's dataset
  const datasetSelect = document.getElementById("resume-dataset-select");
  if (resumeState.allDatasets.length === 0) {
    const resp = await fetch("/api/datasets");
    const data = await resp.json();
    resumeState.allDatasets = data.datasets;
  }
  datasetSelect.innerHTML = "";
  resumeState.allDatasets.forEach((ds) => {
    const option = document.createElement("option");
    option.value = JSON.stringify({ name: ds.name, source: ds.source });
    option.textContent = `${ds.display_name} (${ds.source})`;
    if (ds.name === checkpoint.dataset_name && ds.source === checkpoint.dataset_source) {
      option.selected = true;
    }
    datasetSelect.appendChild(option);
  });

  renderDeviceOptions(
    "resume-device-options",
    () => resumeState.selectedDevice,
    (key) => { resumeState.selectedDevice = key; }
  );

  document.getElementById("resume-epochs-value").textContent =
    document.getElementById("resume-epochs-slider").value;

  document.getElementById("resume-error-message").classList.add("hidden");
  document.getElementById("resume-config-panel").classList.remove("hidden");
}

function setupResumeEpochsSlider() {
  const slider = document.getElementById("resume-epochs-slider");
  const valueEl = document.getElementById("resume-epochs-value");
  slider.oninput = () => { valueEl.textContent = slider.value; };
}

async function startResumeTraining() {
  const checkpoint = resumeState.selectedCheckpoint;
  if (!checkpoint) return;

  const architecture = document.getElementById("resume-architecture-select").value;
  const { name: datasetName, source: datasetSource } =
    JSON.parse(document.getElementById("resume-dataset-select").value);
  const additionalEpochs = parseInt(document.getElementById("resume-epochs-slider").value, 10);

  const errorMessage = document.getElementById("resume-error-message");
  errorMessage.classList.add("hidden");
  errorMessage.textContent = "";

  const response = await fetch("/api/train/resume", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      checkpoint_path: checkpoint.path,
      additional_epochs: additionalEpochs,
      expected_architecture: architecture,
      expected_dataset_name: datasetName,
      expected_dataset_source: datasetSource,
      device_preference: resumeState.selectedDevice,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    errorMessage.textContent = `❌ ${data.error}`;
    errorMessage.classList.remove("hidden");
    return;
  }

  prepareTrainingViewUI(additionalEpochs, `Resuming from epoch ${checkpoint.epoch}...`);
  state.currentRunId = data.run_id;
  pollTrainingStatus();
}

// ---------------------------------------------------------------------------
// Hyperparameter Tuning screens (Stage 9)
// ---------------------------------------------------------------------------

const tuningState = {
  sweepableParams: {},
  maxParamsToSweep: 3,
  maxValuesPerParam: 4,
  maxTotalTrials: 9,
  maxEpochsPerTrial: 15,
  selectedParamsOrder: [],       // array of param keys, in the order the student selected them
  valuesByParam: {},             // param key -> Set of selected values
  selectedDevice: "auto",
  currentTuningId: null,
  pollTimer: null,
};

async function goToTuningSetupScreen() {
  hideAllSections();
  document.getElementById("step-tuning-setup").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("tuning");
  document.getElementById("tuning-error-message").classList.add("hidden");

  document.getElementById("tuning-dataset-label").textContent =
    `${state.selectedDataset.name} (${state.selectedDataset.source}, ${state.selectedDataset.count} pairs)`;

  if (Object.keys(tuningState.sweepableParams).length === 0) {
    const response = await fetch("/api/tuning/params");
    const data = await response.json();
    tuningState.sweepableParams = data.sweepable_params;
    tuningState.maxParamsToSweep = data.max_params_to_sweep;
    tuningState.maxValuesPerParam = data.max_values_per_param;
    tuningState.maxTotalTrials = data.max_total_trials;
    tuningState.maxEpochsPerTrial = data.max_epochs_per_trial;
  }

  // Reset selections each time the screen is opened fresh
  tuningState.selectedParamsOrder = [];
  tuningState.valuesByParam = {};

  renderParamToggles();
  renderParamValueSections();
  updateTrialCountNote();

  const epochsSlider = document.getElementById("tuning-epochs-slider");
  epochsSlider.max = tuningState.maxEpochsPerTrial;
  epochsSlider.value = Math.min(6, tuningState.maxEpochsPerTrial);
  const epochsValue = document.getElementById("tuning-epochs-value");
  epochsSlider.oninput = () => { epochsValue.textContent = epochsSlider.value; };
  epochsValue.textContent = epochsSlider.value;

  renderDeviceOptions(
    "tuning-device-options",
    () => tuningState.selectedDevice,
    (key) => { tuningState.selectedDevice = key; }
  );
}

function renderParamToggles() {
  const container = document.getElementById("tuning-param-toggles");
  container.innerHTML = "";

  Object.entries(tuningState.sweepableParams).forEach(([key, info]) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "device-option";
    const isSelected = tuningState.selectedParamsOrder.includes(key);
    if (isSelected) btn.classList.add("selected");

    btn.textContent = info.display_name;
    btn.onclick = () => {
      if (isSelected) {
        tuningState.selectedParamsOrder = tuningState.selectedParamsOrder.filter((k) => k !== key);
        delete tuningState.valuesByParam[key];
      } else {
        if (tuningState.selectedParamsOrder.length >= tuningState.maxParamsToSweep) {
          return; // at the cap — ignore further selections until one is deselected
        }
        tuningState.selectedParamsOrder.push(key);
        tuningState.valuesByParam[key] = new Set();
      }
      renderParamToggles();
      renderParamValueSections();
      updateTrialCountNote();
    };
    container.appendChild(btn);
  });
}

function getValueOptionsForParam(param) {
  if (param === "learning_rate") {
    return LR_VALUES.map((v) => ({ label: String(v), value: v }));
  }
  if (param === "batch_size") {
    return BATCH_VALUES.map((v) => ({ label: String(v), value: v }));
  }
  if (param === "subset_size") {
    const total = state.selectedDataset ? state.selectedDataset.count : 24;
    const fractions = [0.25, 0.5, 0.75, 1.0];
    return fractions.map((f) => ({ label: String(Math.max(4, Math.round(total * f))), value: Math.max(4, Math.round(total * f)) }));
  }
  if (param === "architecture") {
    return state.architectures.map((a) => ({ label: a.display_name, value: a.name }));
  }
  return [];
}

function renderParamValueSections() {
  const container = document.getElementById("tuning-param-value-sections");
  container.innerHTML = "";

  tuningState.selectedParamsOrder.forEach((param) => {
    const block = document.createElement("div");
    block.className = "param-value-block";

    const title = document.createElement("div");
    title.className = "param-value-title";
    title.textContent = `${tuningState.sweepableParams[param].display_name} — values to try (up to ${tuningState.maxValuesPerParam})`;
    block.appendChild(title);

    const optionsDiv = document.createElement("div");
    optionsDiv.className = "device-options";

    const options = getValueOptionsForParam(param);
    const selectedSet = tuningState.valuesByParam[param];
    const wasFreshlyEmpty = selectedSet.size === 0; // snapshot BEFORE the loop mutates it

    options.forEach((opt, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "device-option";

      // Pre-select the first couple of options by default so the sweep isn't empty
      if (wasFreshlyEmpty && i < 2) selectedSet.add(opt.value);
      if (selectedSet.has(opt.value)) btn.classList.add("selected");

      btn.textContent = opt.label;
      btn.onclick = () => {
        if (selectedSet.has(opt.value)) {
          selectedSet.delete(opt.value);
          btn.classList.remove("selected");
        } else {
          if (selectedSet.size >= tuningState.maxValuesPerParam) return; // at the per-param cap
          selectedSet.add(opt.value);
          btn.classList.add("selected");
        }
        updateTrialCountNote();
      };
      optionsDiv.appendChild(btn);
    });

    block.appendChild(optionsDiv);
    container.appendChild(block);
  });
}

function updateTrialCountNote() {
  const countEl = document.getElementById("tuning-trial-count-note");
  const capsEl = document.getElementById("tuning-caps-note");

  if (tuningState.selectedParamsOrder.length === 0) {
    countEl.textContent = "Select at least one parameter to sweep.";
  } else {
    const counts = tuningState.selectedParamsOrder.map((p) => tuningState.valuesByParam[p].size);
    const hasEmptyParam = counts.some((c) => c === 0);
    const totalTrials = counts.reduce((a, b) => a * b, 1);

    if (hasEmptyParam) {
      countEl.textContent = "Select at least one value for each parameter you're sweeping.";
    } else if (tuningState.selectedParamsOrder.length === 1) {
      countEl.textContent = `This will run ${totalTrials} trial${totalTrials === 1 ? "" : "s"}.`;
    } else {
      countEl.textContent = `Grid search: ${counts.join(" × ")} = ${totalTrials} trials total.`;
    }
  }

  capsEl.textContent =
    `Caps: up to ${tuningState.maxParamsToSweep} parameters, ${tuningState.maxValuesPerParam} values each, ` +
    `${tuningState.maxTotalTrials} trials total, ${tuningState.maxEpochsPerTrial} epochs per trial maximum — ` +
    `kept short so a full sweep finishes quickly.`;
}

async function startTuning() {
  const errorMessage = document.getElementById("tuning-error-message");
  errorMessage.classList.add("hidden");

  if (tuningState.selectedParamsOrder.length === 0) {
    errorMessage.textContent = "❌ Select at least one parameter to sweep.";
    errorMessage.classList.remove("hidden");
    return;
  }

  const sweepParams = tuningState.selectedParamsOrder.map((param) => ({
    param,
    values: Array.from(tuningState.valuesByParam[param]),
  }));

  if (sweepParams.some((p) => p.values.length === 0)) {
    errorMessage.textContent = "❌ Select at least one value for each parameter you're sweeping.";
    errorMessage.classList.remove("hidden");
    return;
  }

  // Use the currently selected architecture from Step 2 as the base model,
  // unless architecture itself is being swept (in which case the base
  // value doesn't matter — every trial overrides it).
  const baseArchitecture = document.getElementById("architecture-select").value;

  const body = {
    dataset_name: state.selectedDataset.name,
    dataset_source: state.selectedDataset.source,
    model_name: baseArchitecture,
    epochs: parseInt(document.getElementById("tuning-epochs-slider").value, 10),
    batch_size: BATCH_VALUES[document.getElementById("batch-slider").value],
    val_split: parseInt(document.getElementById("val-split-slider").value, 10) / 100,
    subset_size: parseInt(document.getElementById("subset-slider").value, 10),
    device_preference: tuningState.selectedDevice,
    sweep_params: sweepParams,
  };

  const response = await fetch("/api/tuning/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await response.json();

  if (!response.ok) {
    errorMessage.textContent = `❌ ${data.error}`;
    errorMessage.classList.remove("hidden");
    return;
  }

  tuningState.currentTuningId = data.tuning_id;
  goToTuningResultsScreen();
}

function goToTuningResultsScreen() {
  hideAllSections();
  document.getElementById("step-tuning-results").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("tuning");
  document.getElementById("tuning-results-title").textContent = "Running sweep...";
  document.getElementById("stop-tuning-btn").classList.remove("hidden");
  document.getElementById("stop-tuning-btn").disabled = false;
  document.getElementById("tuning-trials-list").innerHTML = "";
  clearCanvas("tuning-bar-chart");

  pollTuningStatus();
}

function pollTuningStatus() {
  if (tuningState.pollTimer) clearInterval(tuningState.pollTimer);

  tuningState.pollTimer = setInterval(async () => {
    if (!tuningState.currentTuningId) return;

    const response = await fetch(`/api/tuning/status/${tuningState.currentTuningId}`);
    const data = await response.json();

    if (data.error) {
      clearInterval(tuningState.pollTimer);
      document.getElementById("tuning-progress-text").textContent = `Error: ${data.error}`;
      return;
    }

    renderTuningTrials(data);

    if (data.status === "completed" || data.status === "stopped" || data.status === "error") {
      clearInterval(tuningState.pollTimer);
      document.getElementById("stop-tuning-btn").classList.add("hidden");
      const titleEl = document.getElementById("tuning-results-title");
      if (data.status === "completed") titleEl.textContent = "Sweep complete ✅";
      else if (data.status === "stopped") titleEl.textContent = "Sweep stopped early ⏸️";
      else titleEl.textContent = "Sweep error ❌";
    }
  }, 700);
}

function formatSweepValues(sweepValues) {
  // sweepValues is a dict, e.g. {"learning_rate": 0.001, "batch_size": 4}
  return Object.entries(sweepValues).map(([k, v]) => `${k}=${v}`).join(", ");
}

function renderTuningTrials(data) {
  const completedCount = data.trials.filter((t) => t.status === "completed").length;
  const sweptParamsLabel = data.sweep_params.join(", ");
  document.getElementById("tuning-progress-text").textContent =
    `${completedCount} of ${data.trials.length} trials completed — sweeping ${sweptParamsLabel}`;

  const listEl = document.getElementById("tuning-trials-list");
  listEl.innerHTML = "";

  // Find the best completed trial by val_dice, if any, to highlight it
  const completedTrials = data.trials.filter((t) => t.status === "completed" && t.final_metrics);
  let bestTrialIndex = null;
  if (completedTrials.length > 0) {
    const best = completedTrials.reduce((a, b) =>
      (b.final_metrics.val_dice || 0) > (a.final_metrics.val_dice || 0) ? b : a
    );
    bestTrialIndex = best.trial_index;
  }

  data.trials.forEach((trial) => {
    const card = document.createElement("div");
    card.className = "checkpoint-card";
    if (trial.trial_index === bestTrialIndex) card.classList.add("selected");

    const statusLabel = { pending: "Waiting...", running: "Training...", completed: "Done" }[trial.status] || trial.status;
    let metricsHtml = "";
    if (trial.status === "completed" && trial.final_metrics) {
      const m = trial.final_metrics;
      metricsHtml = `
        Train loss: ${m.train_loss !== undefined ? m.train_loss.toFixed(4) : "n/a"} &nbsp;|&nbsp;
        Val Dice: ${m.val_dice !== undefined && m.val_dice !== null ? m.val_dice.toFixed(4) : "n/a"} &nbsp;|&nbsp;
        Val IoU: ${m.val_iou !== undefined && m.val_iou !== null ? m.val_iou.toFixed(4) : "n/a"}
        ${trial.trial_index === bestTrialIndex ? " &nbsp;🏆 Best so far" : ""}
      `;
    }

    card.innerHTML = `
      <div class="checkpoint-title">${formatSweepValues(trial.sweep_values)} — ${statusLabel}</div>
      <div class="checkpoint-meta">${metricsHtml}</div>
    `;

    if (trial.status === "completed" && trial.checkpoint_path) {
      const actionsDiv = document.createElement("div");
      actionsDiv.style.marginTop = "8px";
      actionsDiv.style.display = "flex";
      actionsDiv.style.gap = "8px";

      const viewBtn = document.createElement("button");
      viewBtn.textContent = "View Full Results";
      viewBtn.className = "secondary-btn";
      viewBtn.onclick = (e) => {
        e.stopPropagation();
        state.lastCheckpointPath = trial.checkpoint_path;
        goToResultsScreen();
      };
      actionsDiv.appendChild(viewBtn);

      const saveBtn = document.createElement("button");
      saveBtn.textContent = "Save as Model";
      saveBtn.className = "secondary-btn";
      saveBtn.onclick = async (e) => {
        e.stopPropagation();
        const suggestedName = Object.entries(trial.sweep_values).map(([k, v]) => `${k}${v}`).join("_");
        const name = window.prompt("Name this model:", suggestedName);
        if (!name) return;
        const resp = await fetch("/api/model/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ checkpoint_path: trial.checkpoint_path, name }),
        });
        const result = await resp.json();
        if (!resp.ok) {
          alert(`Could not save model: ${result.error}`);
        } else {
          alert(`Saved as "${result.model.name}"`);
        }
      };
      actionsDiv.appendChild(saveBtn);

      card.appendChild(actionsDiv);
    }

    listEl.appendChild(card);
  });

  // Bar chart of val_dice per trial
  const labels = data.trials.map((t) => Object.values(t.sweep_values).join("/"));
  const values = data.trials.map((t) =>
    (t.status === "completed" && t.final_metrics && t.final_metrics.val_dice !== null)
      ? t.final_metrics.val_dice : 0
  );
  drawBarChartOnCanvas(
    document.getElementById("tuning-bar-chart"),
    labels, values,
    ["#2563eb", "#16a34a", "#9333ea", "#dc2626", "#f59e0b", "#0891b2"]
  );
}

async function stopTuning() {
  if (!tuningState.currentTuningId) return;
  document.getElementById("stop-tuning-btn").disabled = true;
  await fetch(`/api/tuning/stop/${tuningState.currentTuningId}`, { method: "POST" });
}

// ---------------------------------------------------------------------------
// Step 3: Training
// ---------------------------------------------------------------------------

function prepareTrainingViewUI(totalEpochs, titleText) {
  state.totalEpochsRequested = totalEpochs;
  state.lossHistory = [];
  state.metricHistory = [];

  document.getElementById("training-title").textContent = titleText || "Training...";
  document.getElementById("stop-training-btn").classList.remove("hidden");
  document.getElementById("stop-training-btn").disabled = false;
  document.getElementById("train-another-btn").classList.add("hidden");
  document.getElementById("view-results-btn").classList.add("hidden");
  document.getElementById("progress-bar-fill").style.width = "0%";
  document.getElementById("progress-text").textContent = "Starting...";
  document.getElementById("preview-live").innerHTML = "";
  clearCanvas("loss-chart");
  clearCanvas("metric-chart");

  goToStep(3);
}

async function startTraining() {
  const params = getHyperparams();
  prepareTrainingViewUI(params.epochs);

  const response = await fetch("/api/train/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      dataset_name: state.selectedDataset.name,
      dataset_source: state.selectedDataset.source,
      model_name: params.architecture,
      learning_rate: params.learning_rate,
      epochs: params.epochs,
      batch_size: params.batch_size,
      val_split: params.val_split,
      subset_size: params.subset_size,
      device_preference: params.device_preference,
      checkpoint_every: 5,
    }),
  });

  const data = await response.json();
  if (!response.ok) {
    document.getElementById("progress-text").textContent = `Error: ${data.error}`;
    return;
  }

  state.currentRunId = data.run_id;
  pollTrainingStatus();
}

function pollTrainingStatus() {
  if (state.pollTimer) clearInterval(state.pollTimer);

  state.pollTimer = setInterval(async () => {
    if (!state.currentRunId) return;

    const response = await fetch(`/api/train/status/${state.currentRunId}`);
    const data = await response.json();

    if (data.error) {
      clearInterval(state.pollTimer);
      document.getElementById("progress-text").textContent = `Error: ${data.error}`;
      return;
    }

    updateTrainingView(data);

    if (data.status === "completed" || data.status === "stopped" || data.status === "error") {
      clearInterval(state.pollTimer);
      finishTraining(data);
    }
  }, 700);
}

function updateTrainingView(statusData) {
  const metrics = statusData.metrics_so_far;
  const completedEpochs = metrics.length;
  const totalEpochs = state.totalEpochsRequested;
  const percent = totalEpochs ? Math.min(100, (completedEpochs / totalEpochs) * 100) : 0;

  document.getElementById("progress-bar-fill").style.width = `${percent}%`;
  document.getElementById("progress-text").textContent =
    `Epoch ${completedEpochs} of ${totalEpochs} — status: ${statusData.status}`;

  state.lossHistory = metrics.map((m) => ({ epoch: m.epoch, train_loss: m.train_loss, val_loss: m.val_loss }));
  state.metricHistory = metrics.map((m) => ({ epoch: m.epoch, val_dice: m.val_dice, val_iou: m.val_iou }));

  drawLossChart();
  drawMetricChart();

  if (statusData.latest_preview) {
    renderLivePreview(statusData.latest_preview);
  }
}

function finishTraining(statusData) {
  document.getElementById("stop-training-btn").classList.add("hidden");
  document.getElementById("train-another-btn").classList.remove("hidden");

  const titleEl = document.getElementById("training-title");
  if (statusData.status === "completed") {
    titleEl.textContent = "Training complete ✅";
  } else if (statusData.status === "stopped") {
    titleEl.textContent = "Training stopped early ⏸️";
  } else {
    titleEl.textContent = "Training error ❌";
    document.getElementById("progress-text").textContent = statusData.error || "An unknown error occurred.";
  }

  // Capture the most recent checkpoint from this run so "View Full Results" can use it
  const checkpointPaths = statusData.final_result && statusData.final_result.checkpoint_paths;
  if (checkpointPaths && checkpointPaths.length > 0) {
    state.lastCheckpointPath = checkpointPaths[checkpointPaths.length - 1];
    document.getElementById("view-results-btn").classList.remove("hidden");
  } else {
    document.getElementById("view-results-btn").classList.add("hidden");
  }
}

async function stopTraining() {
  if (!state.currentRunId) return;
  document.getElementById("stop-training-btn").disabled = true;
  await fetch(`/api/train/stop/${state.currentRunId}`, { method: "POST" });
}

function renderLivePreview(preview) {
  const container = document.getElementById("preview-live");
  container.innerHTML = `
    <div class="preview-item">
      <img src="${preview.image}" alt="input" />
      <div class="preview-item-label">Input</div>
    </div>
    <div class="preview-item">
      <img src="${preview.ground_truth}" alt="ground truth" />
      <div class="preview-item-label">Ground truth</div>
    </div>
    <div class="preview-item">
      <img src="${preview.prediction}" alt="prediction" />
      <div class="preview-item-label">Prediction</div>
    </div>
  `;
}

// ---------------------------------------------------------------------------
// Simple canvas line charts (no external dependencies — keeps the app
// fully offline-capable)
// ---------------------------------------------------------------------------

function drawBarChartOnCanvas(canvas, labels, values, colors) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  const padding = { left: 40, right: 10, top: 15, bottom: 30 };
  ctx.clearRect(0, 0, w, h);

  const plotW = w - padding.left - padding.right;
  const plotH = h - padding.top - padding.bottom;
  const maxVal = Math.max(1, ...values);

  const barCount = values.length;
  const gap = 16;
  const barWidth = (plotW - gap * (barCount - 1)) / barCount;

  // Axis
  ctx.strokeStyle = "#ccc";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + plotH);
  ctx.lineTo(padding.left + plotW, padding.top + plotH);
  ctx.stroke();

  ctx.fillStyle = "#999";
  ctx.font = "10px sans-serif";
  ctx.fillText(maxVal.toFixed(2), 2, padding.top + 8);
  ctx.fillText("0.00", 8, padding.top + plotH);

  values.forEach((val, i) => {
    const barHeight = (val / maxVal) * plotH;
    const x = padding.left + i * (barWidth + gap);
    const y = padding.top + plotH - barHeight;

    ctx.fillStyle = colors[i % colors.length];
    ctx.fillRect(x, y, barWidth, barHeight);

    ctx.fillStyle = "#333";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(val.toFixed(3), x + barWidth / 2, y - 4);
    ctx.fillText(labels[i], x + barWidth / 2, padding.top + plotH + 16);
    ctx.textAlign = "left";
  });
}

function clearCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function drawLineChartOnCanvas(canvas, series) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  const padding = { left: 40, right: 10, top: 15, bottom: 25 };
  ctx.clearRect(0, 0, w, h);

  const allValues = series.flatMap((s) => s.values.filter((v) => v !== null && v !== undefined));
  if (allValues.length === 0) return;

  const xCount = Math.max(...series.map((s) => s.values.length));
  if (xCount < 1) return;

  let minY = Math.min(...allValues);
  let maxY = Math.max(...allValues);
  if (minY === maxY) { minY -= 0.1; maxY += 0.1; }
  const yPad = (maxY - minY) * 0.1;
  minY -= yPad; maxY += yPad;

  const plotW = w - padding.left - padding.right;
  const plotH = h - padding.top - padding.bottom;

  const xForIndex = (i) => padding.left + (xCount <= 1 ? 0 : (i / (xCount - 1)) * plotW);
  const yForValue = (v) => padding.top + plotH - ((v - minY) / (maxY - minY)) * plotH;

  // Axes
  ctx.strokeStyle = "#ccc";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + plotH);
  ctx.lineTo(padding.left + plotW, padding.top + plotH);
  ctx.stroke();

  // Y axis labels (min/max)
  ctx.fillStyle = "#999";
  ctx.font = "10px sans-serif";
  ctx.fillText(maxY.toFixed(2), 2, padding.top + 8);
  ctx.fillText(minY.toFixed(2), 2, padding.top + plotH);

  // Series lines
  series.forEach((s) => {
    ctx.strokeStyle = s.color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    let started = false;
    s.values.forEach((v, i) => {
      if (v === null || v === undefined) return;
      const x = xForIndex(i);
      const y = yForValue(v);
      if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
    });
    ctx.stroke();
  });

  // Legend
  let legendX = padding.left;
  series.forEach((s) => {
    ctx.fillStyle = s.color;
    ctx.fillRect(legendX, h - 12, 10, 10);
    ctx.fillStyle = "#333";
    ctx.fillText(s.label, legendX + 14, h - 3);
    legendX += ctx.measureText(s.label).width + 40;
  });
}

function drawLossChart() {
  const canvas = document.getElementById("loss-chart");
  drawLineChartOnCanvas(canvas, [
    { label: "Train loss", color: "#2563eb", values: state.lossHistory.map((m) => m.train_loss) },
    { label: "Val loss", color: "#dc2626", values: state.lossHistory.map((m) => m.val_loss) },
  ]);
}

function drawMetricChart() {
  const canvas = document.getElementById("metric-chart");
  drawLineChartOnCanvas(canvas, [
    { label: "Val Dice", color: "#16a34a", values: state.metricHistory.map((m) => m.val_dice) },
    { label: "Val IoU", color: "#9333ea", values: state.metricHistory.map((m) => m.val_iou) },
  ]);
}

// ---------------------------------------------------------------------------
// Results screen (Stage 8)
// ---------------------------------------------------------------------------

async function goToResultsScreen() {
  if (!state.lastCheckpointPath) return;
  hideAllSections();
  document.getElementById("step-results").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("results");
  document.getElementById("report-message").textContent = "";
  document.getElementById("save-model-message").textContent = "";
  document.getElementById("save-model-name").value = "";

  document.getElementById("results-run-label").textContent = "Loading...";
  document.getElementById("results-summary-cards").innerHTML = "";
  document.getElementById("confusion-matrix-container").innerHTML = "";
  document.getElementById("sample-predictions-grid").innerHTML = "";
  clearCanvas("metric-bar-chart");

  const response = await fetch(`/api/results?checkpoint_path=${encodeURIComponent(state.lastCheckpointPath)}`);
  const data = await response.json();

  if (data.error) {
    document.getElementById("results-run-label").textContent = `Error: ${data.error}`;
    return;
  }

  renderResults(data);
}

function renderResults(data) {
  const runId = data.checkpoint_path.split("/").slice(-2, -1)[0] || data.checkpoint_path;
  document.getElementById("results-run-label").textContent = `${runId} (epoch ${data.epoch})`;

  const lastEpochMetrics = data.metrics_history[data.metrics_history.length - 1] || {};
  const cm = data.confusion_matrix;

  const cardsHtml = [
    { label: "Final train loss", value: lastEpochMetrics.train_loss },
    { label: "Final val loss", value: lastEpochMetrics.val_loss },
    { label: "Overall Dice", value: cm.dice },
    { label: "Overall IoU", value: cm.iou },
    { label: "Precision", value: cm.precision },
    { label: "Recall", value: cm.recall },
  ].map((c) => `
    <div class="summary-card">
      <div class="summary-value">${c.value !== null && c.value !== undefined ? c.value.toFixed(4) : "n/a"}</div>
      <div class="summary-label">${c.label}</div>
    </div>
  `).join("");
  document.getElementById("results-summary-cards").innerHTML = cardsHtml;

  document.getElementById("confusion-matrix-container").innerHTML = `
    <table class="confusion-table">
      <tr>
        <th></th>
        <th>Predicted: Foreground</th>
        <th>Predicted: Background</th>
      </tr>
      <tr>
        <th>Actual: Foreground</th>
        <td class="tp"><div class="cell-count">${cm.tp.toLocaleString()}</div>True Positive</td>
        <td class="fn"><div class="cell-count">${cm.fn.toLocaleString()}</div>False Negative</td>
      </tr>
      <tr>
        <th>Actual: Background</th>
        <td class="fp"><div class="cell-count">${cm.fp.toLocaleString()}</div>False Positive</td>
        <td class="tn"><div class="cell-count">${cm.tn.toLocaleString()}</div>True Negative</td>
      </tr>
    </table>
    <p class="hint" style="text-align:center; margin-top: 10px;">
      ${cm.total_pixels.toLocaleString()} total pixels evaluated across the validation set — accuracy: ${(cm.accuracy * 100).toFixed(1)}%
    </p>
  `;

  const barCanvas = document.getElementById("metric-bar-chart");
  drawBarChartOnCanvas(
    barCanvas,
    ["Precision", "Recall", "Dice", "IoU", "Accuracy"],
    [cm.precision, cm.recall, cm.dice, cm.iou, cm.accuracy],
    ["#2563eb", "#16a34a", "#9333ea", "#dc2626", "#f59e0b"]
  );

  const grid = document.getElementById("sample-predictions-grid");
  grid.innerHTML = "";
  data.sample_predictions.forEach((sample, i) => {
    const card = document.createElement("div");
    card.className = "sample-prediction-card";
    card.innerHTML = `
      <div class="sample-prediction-images">
        <div class="sample-prediction-item">
          <img src="${sample.image}" alt="image" />
          <div class="sample-prediction-label">Image</div>
        </div>
        <div class="sample-prediction-item">
          <img src="${sample.ground_truth}" alt="ground truth" />
          <div class="sample-prediction-label">Ground truth</div>
        </div>
        <div class="sample-prediction-item">
          <img src="${sample.prediction}" alt="prediction" />
          <div class="sample-prediction-label">Prediction</div>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });

  state.currentResultsCheckpointPath = data.checkpoint_path;
}

async function saveModelFromResults() {
  const nameInput = document.getElementById("save-model-name");
  const messageEl = document.getElementById("save-model-message");
  const name = nameInput.value.trim();

  messageEl.className = "message";

  if (!name) {
    messageEl.classList.add("error");
    messageEl.textContent = "❌ Please enter a name for this model.";
    return;
  }

  messageEl.textContent = "Saving...";

  const response = await fetch("/api/model/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ checkpoint_path: state.currentResultsCheckpointPath, name }),
  });
  const data = await response.json();

  if (!response.ok) {
    messageEl.classList.add("error");
    messageEl.textContent = `❌ ${data.error}`;
    return;
  }

  messageEl.classList.add("success");
  messageEl.textContent = `✅ Saved as "${data.model.name}" — find it under "Test a saved model" from the start screen.`;
}

async function saveReport() {
  const messageEl = document.getElementById("report-message");
  messageEl.className = "message";
  messageEl.textContent = "Saving...";

  const response = await fetch("/api/results/save_report", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ checkpoint_path: state.currentResultsCheckpointPath }),
  });
  const data = await response.json();

  if (!response.ok) {
    messageEl.classList.add("error");
    messageEl.textContent = `❌ ${data.error}`;
    return;
  }

  messageEl.classList.add("success");
  messageEl.innerHTML = `✅ Saved as <strong>${data.filename}</strong> — <a href="/api/reports/${encodeURIComponent(data.filename)}" target="_blank">Download</a>`;
}

// ---------------------------------------------------------------------------
// Model Library & Testing/Inference screens (Stage 10)
// ---------------------------------------------------------------------------

const testingState = {
  selectedModelName: null,
  selectedDevice: "auto",
};

async function goToModelLibraryScreen() {
  hideAllSections();
  document.getElementById("step-model-library").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("library");

  const listEl = document.getElementById("model-library-list");
  const emptyMessage = document.getElementById("model-library-empty-message");
  listEl.innerHTML = "";

  const response = await fetch("/api/models");
  const data = await response.json();

  if (data.models.length === 0) {
    emptyMessage.classList.remove("hidden");
    return;
  }
  emptyMessage.classList.add("hidden");

  data.models.forEach((model) => {
    const card = document.createElement("div");
    card.className = "checkpoint-card";

    const diceText = model.final_val_dice !== null && model.final_val_dice !== undefined
      ? model.final_val_dice.toFixed(4) : "n/a";
    const iouText = model.final_val_iou !== null && model.final_val_iou !== undefined
      ? model.final_val_iou.toFixed(4) : "n/a";

    card.innerHTML = `
      <div class="checkpoint-title">${model.name}</div>
      <div class="checkpoint-meta">
        Architecture: ${model.architecture} &nbsp;|&nbsp;
        Dataset: ${model.dataset_name} (${model.dataset_source}) &nbsp;|&nbsp;
        Trained epochs: ${model.trained_epochs} &nbsp;|&nbsp;
        Val Dice: ${diceText} &nbsp;|&nbsp;
        Val IoU: ${iouText}
      </div>
    `;
    card.onclick = () => goToTestingScreen(model);
    listEl.appendChild(card);
  });
}

function goToTestingScreen(model) {
  testingState.selectedModelName = model.name;

  hideAllSections();
  document.getElementById("step-testing").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("testing");
  document.getElementById("testing-model-label").textContent =
    `${model.name} (${model.architecture}, trained on ${model.dataset_name})`;

  document.getElementById("testing-image-file").value = "";
  document.getElementById("testing-mask-file").value = "";
  document.getElementById("testing-error-message").classList.add("hidden");
  document.getElementById("testing-results-panel").classList.add("hidden");
  document.getElementById("testing-results-images").innerHTML = "";
  document.getElementById("testing-results-metrics").innerHTML = "";

  renderDeviceOptions(
    "testing-device-options",
    () => testingState.selectedDevice,
    (key) => { testingState.selectedDevice = key; }
  );
}

async function runInference() {
  const imageInput = document.getElementById("testing-image-file");
  const maskInput = document.getElementById("testing-mask-file");
  const errorMessage = document.getElementById("testing-error-message");

  errorMessage.classList.add("hidden");

  if (!imageInput.files[0]) {
    errorMessage.textContent = "❌ Please choose an image to test.";
    errorMessage.classList.remove("hidden");
    return;
  }

  const formData = new FormData();
  formData.append("model_name", testingState.selectedModelName);
  formData.append("image", imageInput.files[0]);
  if (maskInput.files[0]) {
    formData.append("mask", maskInput.files[0]);
  }
  formData.append("device_preference", testingState.selectedDevice);

  const runBtn = document.getElementById("run-inference-btn");
  runBtn.disabled = true;
  runBtn.textContent = "Running...";

  try {
    const response = await fetch("/api/inference", { method: "POST", body: formData });
    const data = await response.json();

    if (!response.ok) {
      errorMessage.textContent = `❌ ${data.error}`;
      errorMessage.classList.remove("hidden");
      return;
    }

    renderInferenceResult(data, imageInput.files[0], maskInput.files[0]);
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = "Run Inference";
  }
}

function renderInferenceResult(data, imageFile, maskFile) {
  const imagesContainer = document.getElementById("testing-results-images");
  const metricsContainer = document.getElementById("testing-results-metrics");

  const imageUrl = URL.createObjectURL(imageFile);
  let imagesHtml = `
    <div class="preview-item">
      <img src="${imageUrl}" alt="input" />
      <div class="preview-item-label">Input image</div>
    </div>
  `;

  if (maskFile) {
    const maskUrl = URL.createObjectURL(maskFile);
    imagesHtml += `
      <div class="preview-item">
        <img src="${maskUrl}" alt="ground truth" />
        <div class="preview-item-label">Ground truth</div>
      </div>
    `;
  }

  imagesHtml += `
    <div class="preview-item">
      <img src="${data.predicted_mask}" alt="prediction" />
      <div class="preview-item-label">Predicted mask</div>
    </div>
  `;
  imagesContainer.innerHTML = imagesHtml;

  let metricsHtml = `
    <div class="summary-card">
      <div class="summary-value">${data.device_used}</div>
      <div class="summary-label">Device used</div>
    </div>
  `;
  if (data.dice !== undefined) {
    metricsHtml += `
      <div class="summary-card">
        <div class="summary-value">${data.dice.toFixed(4)}</div>
        <div class="summary-label">Dice (this image)</div>
      </div>
      <div class="summary-card">
        <div class="summary-value">${data.iou.toFixed(4)}</div>
        <div class="summary-label">IoU (this image)</div>
      </div>
    `;
  }
  metricsContainer.innerHTML = metricsHtml;

  document.getElementById("testing-results-panel").classList.remove("hidden");
}

// ---------------------------------------------------------------------------
// Concepts explainer panel (Stage 11)
// ---------------------------------------------------------------------------

const CONCEPTS = [
  {
    question: "What is deep learning?",
    answer: "A way of teaching a computer to perform a task by showing it many examples, rather than programming explicit rules. The computer adjusts millions of internal numbers (parameters) until its predictions match the examples well, then applies what it learned to new, unseen data.",
  },
  {
    question: "What is image segmentation?",
    answer: "Labeling every individual pixel in an image as belonging to a category (e.g. \"this pixel is part of the object\" vs \"this pixel is background\"), producing a mask that outlines exactly where something is — more detailed than just saying an object is somewhere in the image.",
  },
  {
    question: "What is a loss function?",
    answer: "A single number that measures how wrong the model's current predictions are, calculated by comparing predictions to the correct answers. Training works by repeatedly adjusting the model to make this number smaller.",
  },
  {
    question: "What is learning rate?",
    answer: "How big a step the model takes each time it adjusts itself to reduce the loss. Too high and it can overshoot and never settle down (unstable training); too low and it takes a very long time to improve.",
  },
  {
    question: "What is an epoch?",
    answer: "One complete pass through the entire training dataset. Training usually runs for many epochs, since a single pass isn't enough for the model to learn well.",
  },
  {
    question: "What is batch size?",
    answer: "How many images the model looks at together before it updates itself once. Larger batches give a more stable, averaged-out update; smaller batches update more often but with noisier information.",
  },
  {
    question: "What is overfitting?",
    answer: "When a model starts memorizing the specific training images instead of learning general patterns. You can spot it when training loss keeps improving but validation loss (on images the model wasn't trained on) starts getting worse.",
  },
  {
    question: "What is a validation split?",
    answer: "A portion of the dataset deliberately held back from training, used only to check how well the model performs on data it hasn't memorized — a fair test of real learning.",
  },
  {
    question: "What is the Dice score?",
    answer: "A measure of how much the predicted mask overlaps the correct mask, from 0 (no overlap) to 1 (perfect match). It counts the overlap twice relative to the combined size of both masks, which makes it forgiving of small mismatches on small objects.",
  },
  {
    question: "What is IoU (Intersection over Union)?",
    answer: "Similar to Dice — it measures overlap between predicted and correct masks from 0 to 1 — but computed as the overlapping area divided by the total area covered by either mask. IoU is always a little stricter (lower or equal) than Dice for the same prediction.",
  },
  {
    question: "What is a confusion matrix?",
    answer: "A table breaking down every pixel's prediction into four outcomes: True Positive (correctly found foreground), True Negative (correctly found background), False Positive (wrongly predicted foreground), and False Negative (missed real foreground). Precision, recall, Dice, and IoU are all calculated from these four numbers.",
  },
  {
    question: "CPU vs GPU — what's the difference?",
    answer: "Both can run the same calculations, but a GPU (Graphics Processing Unit) is built to do many simple calculations in parallel, which happens to be exactly what training a neural network needs — so it's often dramatically faster than a CPU for this kind of work, especially on larger models.",
  },
  {
    question: "What is a checkpoint?",
    answer: "A saved snapshot of a model's exact state partway through training (its learned values, plus the settings used), so training can be paused and resumed later from exactly that point instead of starting over.",
  },
  {
    question: "What is hyperparameter tuning?",
    answer: "Systematically trying different settings (like learning rate or batch size) to see which produces the best result, rather than guessing one configuration and hoping it's good.",
  },
];

function initConceptsPanel() {
  const accordion = document.getElementById("concepts-accordion");
  accordion.innerHTML = "";

  CONCEPTS.forEach((concept, i) => {
    const item = document.createElement("div");
    item.className = "concept-item";

    const question = document.createElement("button");
    question.type = "button";
    question.className = "concept-question";
    question.innerHTML = `<span>${concept.question}</span><span class="concept-arrow">&#9656;</span>`;

    const answer = document.createElement("div");
    answer.className = "concept-answer";
    answer.textContent = concept.answer;

    question.onclick = () => {
      const isExpanded = answer.classList.contains("expanded");
      answer.classList.toggle("expanded", !isExpanded);
      question.querySelector(".concept-arrow").classList.toggle("expanded", !isExpanded);
    };

    item.appendChild(question);
    item.appendChild(answer);
    accordion.appendChild(item);
  });
}

function openConceptsModal() {
  document.getElementById("concepts-modal-overlay").classList.remove("hidden");
}

function closeConceptsModal() {
  document.getElementById("concepts-modal-overlay").classList.add("hidden");
}

// ---------------------------------------------------------------------------
// Compare Runs screen (Stage 11)
// ---------------------------------------------------------------------------

async function goToCompareScreen() {
  hideAllSections();
  document.getElementById("step-compare").classList.remove("hidden");
  setStepsIndicatorVisible(false);
  setActiveNavItem("compare");
  document.getElementById("compare-results-panel").classList.add("hidden");
  document.getElementById("compare-loss-panel").classList.add("hidden");
  document.getElementById("compare-bar-panel").classList.add("hidden");
  document.getElementById("compare-error-message").classList.add("hidden");

  const response = await fetch("/api/checkpoints");
  const data = await response.json();

  const selectA = document.getElementById("compare-select-a");
  const selectB = document.getElementById("compare-select-b");
  [selectA, selectB].forEach((select) => { select.innerHTML = ""; });

  data.checkpoints.forEach((ckpt) => {
    const label = `${ckpt.run_id} — epoch ${ckpt.epoch} (${ckpt.architecture})`;
    [selectA, selectB].forEach((select) => {
      const option = document.createElement("option");
      option.value = ckpt.path;
      option.textContent = label;
      select.appendChild(option);
    });
  });

  // Default to two different checkpoints if at least two exist
  if (data.checkpoints.length > 1) {
    selectB.selectedIndex = 1;
  }
}

async function runComparison() {
  const pathA = document.getElementById("compare-select-a").value;
  const pathB = document.getElementById("compare-select-b").value;
  const errorMessage = document.getElementById("compare-error-message");
  errorMessage.classList.add("hidden");

  if (!pathA || !pathB) {
    errorMessage.textContent = "❌ Both Run A and Run B need a checkpoint selected.";
    errorMessage.classList.remove("hidden");
    return;
  }
  if (pathA === pathB) {
    errorMessage.textContent = "❌ Select two different checkpoints to compare.";
    errorMessage.classList.remove("hidden");
    return;
  }

  const [respA, respB] = await Promise.all([
    fetch(`/api/results?checkpoint_path=${encodeURIComponent(pathA)}`),
    fetch(`/api/results?checkpoint_path=${encodeURIComponent(pathB)}`),
  ]);
  const [dataA, dataB] = await Promise.all([respA.json(), respB.json()]);

  if (dataA.error || dataB.error) {
    errorMessage.textContent = `❌ ${dataA.error || dataB.error}`;
    errorMessage.classList.remove("hidden");
    return;
  }

  renderComparison(dataA, dataB);
}

function renderComparisonSummary(containerId, labelId, data) {
  const runId = data.checkpoint_path.split("/").slice(-2, -1)[0] || data.checkpoint_path;
  document.getElementById(labelId).textContent = `${runId} (epoch ${data.epoch})`;

  const lastEpoch = data.metrics_history[data.metrics_history.length - 1] || {};
  const cm = data.confusion_matrix;

  const cards = [
    { label: "Train loss", value: lastEpoch.train_loss },
    { label: "Val loss", value: lastEpoch.val_loss },
    { label: "Dice", value: cm.dice },
    { label: "IoU", value: cm.iou },
  ].map((c) => `
    <div class="summary-card">
      <div class="summary-value">${c.value !== null && c.value !== undefined ? c.value.toFixed(4) : "n/a"}</div>
      <div class="summary-label">${c.label}</div>
    </div>
  `).join("");

  document.getElementById(containerId).innerHTML = cards;
}

function drawGroupedBarChartOnCanvas(canvas, labels, valuesA, valuesB, labelA, labelB, colorA, colorB, fixedMax) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  const padding = { left: 40, right: 10, top: 30, bottom: 40 };
  ctx.clearRect(0, 0, w, h);

  const plotW = w - padding.left - padding.right;
  const plotH = h - padding.top - padding.bottom;
  const maxVal = fixedMax || Math.max(1, ...valuesA, ...valuesB);

  const groupCount = labels.length;
  const groupGap = 20;
  const groupWidth = (plotW - groupGap * (groupCount - 1)) / groupCount;
  const barWidth = groupWidth / 2 - 2;

  ctx.strokeStyle = "#ccc";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + plotH);
  ctx.lineTo(padding.left + plotW, padding.top + plotH);
  ctx.stroke();

  ctx.fillStyle = "#999";
  ctx.font = "10px sans-serif";
  ctx.fillText(maxVal.toFixed(2), 2, padding.top + 8);
  ctx.fillText("0.00", 8, padding.top + plotH);

  labels.forEach((label, i) => {
    const groupX = padding.left + i * (groupWidth + groupGap);

    const barAHeight = (valuesA[i] / maxVal) * plotH;
    ctx.fillStyle = colorA;
    ctx.fillRect(groupX, padding.top + plotH - barAHeight, barWidth, barAHeight);

    const barBHeight = (valuesB[i] / maxVal) * plotH;
    ctx.fillStyle = colorB;
    ctx.fillRect(groupX + barWidth + 4, padding.top + plotH - barBHeight, barWidth, barBHeight);

    ctx.fillStyle = "#333";
    ctx.font = "11px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(label, groupX + groupWidth / 2, padding.top + plotH + 16);
    ctx.textAlign = "left";
  });

  // Legend
  ctx.fillStyle = colorA;
  ctx.fillRect(padding.left, 4, 10, 10);
  ctx.fillStyle = "#333";
  ctx.fillText(labelA, padding.left + 14, 13);
  const labelAWidth = ctx.measureText(labelA).width;
  ctx.fillStyle = colorB;
  ctx.fillRect(padding.left + labelAWidth + 40, 4, 10, 10);
  ctx.fillStyle = "#333";
  ctx.fillText(labelB, padding.left + labelAWidth + 54, 13);
}

function renderComparison(dataA, dataB) {
  document.getElementById("compare-results-panel").classList.remove("hidden");
  document.getElementById("compare-loss-panel").classList.remove("hidden");
  document.getElementById("compare-bar-panel").classList.remove("hidden");

  renderComparisonSummary("compare-summary-a", "compare-label-a", dataA);
  renderComparisonSummary("compare-summary-b", "compare-label-b", dataB);

  // Loss curves — both runs on the same chart/axes
  drawLineChartOnCanvas(document.getElementById("compare-loss-chart"), [
    { label: "Run A train loss", color: "#2563eb", values: dataA.metrics_history.map((m) => m.train_loss) },
    { label: "Run B train loss", color: "#dc2626", values: dataB.metrics_history.map((m) => m.train_loss) },
  ]);

  // Metric comparison bar chart — fixed 0-1 scale so both runs are directly comparable
  const labels = ["Precision", "Recall", "Dice", "IoU", "Accuracy"];
  const valuesA = [dataA.confusion_matrix.precision, dataA.confusion_matrix.recall, dataA.confusion_matrix.dice,
                   dataA.confusion_matrix.iou, dataA.confusion_matrix.accuracy];
  const valuesB = [dataB.confusion_matrix.precision, dataB.confusion_matrix.recall, dataB.confusion_matrix.dice,
                   dataB.confusion_matrix.iou, dataB.confusion_matrix.accuracy];

  drawGroupedBarChartOnCanvas(
    document.getElementById("compare-bar-chart"),
    labels, valuesA, valuesB, "Run A", "Run B", "#2563eb", "#dc2626", 1.0
  );
}

// ---------------------------------------------------------------------------
// Reset flow
// ---------------------------------------------------------------------------

function resetToStep1() {
  state.currentRunId = null;
  goToStep(1);
}

// ---------------------------------------------------------------------------
// Wire everything up
// ---------------------------------------------------------------------------

window.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  renderIcons();

  document.getElementById("theme-toggle-btn").addEventListener("click", toggleTheme);

  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => handleSidebarNav(item.dataset.nav));
  });

  checkBackendConnection();
  await loadDatasetList();
  await loadArchitectures();
  await loadDevices();
  setupSliders();

  document.getElementById("preview-btn").addEventListener("click", previewSelectedDataset);
  document.getElementById("upload-btn").addEventListener("click", uploadDataset);

  document.getElementById("to-step-2-btn").addEventListener("click", () => {
    document.getElementById("selected-dataset-label").textContent =
      `${state.selectedDataset.name} (${state.selectedDataset.source}, ${state.selectedDataset.count} pairs)`;
    configureSubsetSliderForDataset();
    goToStep(2);
  });

  document.getElementById("back-to-step-1-btn").addEventListener("click", () => goToStep(1));
  document.getElementById("start-training-btn").addEventListener("click", startTraining);
  document.getElementById("stop-training-btn").addEventListener("click", stopTraining);
  document.getElementById("train-another-btn").addEventListener("click", resetToStep1);

  document.getElementById("to-resume-btn").addEventListener("click", goToResumeScreen);
  document.getElementById("back-from-resume-list-btn").addEventListener("click", () => goToStep(1));
  document.getElementById("back-from-resume-btn").addEventListener("click", () => {
    document.getElementById("resume-config-panel").classList.add("hidden");
  });
  document.getElementById("start-resume-btn").addEventListener("click", startResumeTraining);
  setupResumeEpochsSlider();

  document.getElementById("view-results-btn").addEventListener("click", goToResultsScreen);
  document.getElementById("back-from-results-btn").addEventListener("click", resetToStep1);
  document.getElementById("save-report-btn").addEventListener("click", saveReport);

  document.getElementById("to-tuning-btn").addEventListener("click", goToTuningSetupScreen);
  document.getElementById("back-from-tuning-setup-btn").addEventListener("click", () => goToStep(2));
  document.getElementById("start-tuning-btn").addEventListener("click", startTuning);
  document.getElementById("stop-tuning-btn").addEventListener("click", stopTuning);
  document.getElementById("back-from-tuning-results-btn").addEventListener("click", resetToStep1);

  document.getElementById("save-model-btn").addEventListener("click", saveModelFromResults);

  document.getElementById("to-model-library-btn").addEventListener("click", goToModelLibraryScreen);
  document.getElementById("back-from-model-library-btn").addEventListener("click", () => goToStep(1));
  document.getElementById("run-inference-btn").addEventListener("click", runInference);
  document.getElementById("back-from-testing-btn").addEventListener("click", goToModelLibraryScreen);

  document.getElementById("close-concepts-btn").addEventListener("click", closeConceptsModal);
  document.getElementById("concepts-modal-overlay").addEventListener("click", (e) => {
    if (e.target.id === "concepts-modal-overlay") closeConceptsModal(); // click outside the box closes it
  });
  initConceptsPanel();

  document.getElementById("to-compare-btn").addEventListener("click", goToCompareScreen);
  document.getElementById("run-compare-btn").addEventListener("click", runComparison);
  document.getElementById("back-from-compare-btn").addEventListener("click", resetToStep1);
});
