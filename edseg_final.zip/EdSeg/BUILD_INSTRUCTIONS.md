# Building EdSeg as a Desktop App (Windows & Mac)

This produces the actual double-click desktop app. PyInstaller **cannot
cross-compile**: you must run the build *on* the operating system you're
building for. Build on a real Windows machine to get the Windows version,
and on a real Mac to get the Mac version.

## App icon

`icon.ico` (Windows) and `icon.icns` (Mac) are already included in the
project and wired into `launcher.spec` — the build automatically picks
the right one based on the platform you're building on. Nothing extra to
do here; the built app will show the EdSeg brain icon in the taskbar,
title bar, and (on Mac) the Dock.

## Onedir, not onefile — what you'll actually get

This build produces a **folder**, not a single file:
```
dist/EdSeg/
├── EdSeg.exe          (Windows — small, a few MB)
├── _internal/          (all supporting files: Python runtime, PyTorch, etc.)
└── ...
```
Students double-click `EdSeg.exe` inside that folder — but the whole
`EdSeg` folder needs to stay together (zip it to share, or just copy the
whole folder as-is).

**Why not a single .exe:** PyInstaller's alternative "onefile" mode
crams everything into one file, but that file has to silently
re-extract its entire contents into a temp folder **every single time**
the app launches — with PyTorch involved, that adds real, noticeable
delay to *every* startup, not just the first. Onedir mode launches
almost immediately since every file already sits on disk in its final
place — nothing to unpack. Measured in testing: a lightweight
onedir build reached "ready" in about **0.4 seconds**, versus several
seconds of extraction overhead for the equivalent onefile build, every
single launch.

## Before you start (both platforms)

You need Python 3.10+ installed. Then, in the project folder:

```
python -m venv build_venv
```

Activate it:
- **Windows:** `build_venv\Scripts\activate`
- **Mac:** `source build_venv/bin/activate`

Install dependencies:

```
pip install Flask Pillow numpy pywebview pyinstaller
pip install torch
```

**A note on CUDA vs. CPU-only PyTorch:** plain `pip install torch` does
NOT reliably give you the CUDA build — it can silently resolve to a much
smaller CPU-only wheel depending on your pip/Python setup. If you
specifically want GPU acceleration to work in the built app (e.g. you
have an NVIDIA GPU and want the app's GPU toggle to actually do
something), install explicitly instead:
```
pip uninstall torch -y
pip install torch --index-url https://download.pytorch.org/whl/cu128
```
(Match the CUDA version to your driver — check with `nvidia-smi`; try
`cu126` or `cu130` if `cu128` doesn't have a wheel for your torch
version.) Expect the CUDA build to add several GB to the final folder
size and noticeably more download/build time — that's the real,
unavoidable cost of including it. If your students mostly won't have
NVIDIA GPUs anyway, the CPU-only build is the more practical choice for
anything you distribute widely; keep the CUDA build to a copy you use
yourself.

## Building on Windows

From the project root (with `build_venv` activated):

```
pyinstaller launcher.spec --noconfirm
```

This will take several minutes — PyInstaller has to analyze and bundle
all of PyTorch, which is large. That's normal, not a sign of a problem.

When it finishes, your app is at:
```
dist\EdSeg\EdSeg.exe
```
Share the whole `dist\EdSeg` folder (zip it up) — not just the .exe alone.

**First-time Windows security warning:** since this isn't a signed,
commercially-distributed app, Windows will likely show a "Windows
protected your PC" SmartScreen warning the first time it's run. Click
**"More info"** → **"Run anyway."** This is normal for small/free
tools and only appears once per machine.

## Building on Mac

From the project root (with `build_venv` activated):

```
pyinstaller launcher.spec --noconfirm
```

Same expectation: this takes several minutes due to PyTorch's size.

When it finishes, your app is at:
```
dist/EdSeg/EdSeg.app
```
Zip the whole `dist/EdSeg` folder to share it (or just the `.app` itself
if PyInstaller placed all its dependencies inside the `.app` bundle on
Mac, which is the typical Mac packaging convention — check whether
`EdSeg.app` alone launches correctly before assuming you need the whole
folder on this platform).

**First-time Mac security warning:** since this isn't notarized by Apple,
Gatekeeper will block it the first time with an "unidentified developer"
warning. The student needs to **right-click the app → Open** (instead of
double-clicking) the very first time, then click "Open" in the dialog
that appears. After that, it opens normally. This is standard for
small/free Mac apps distributed outside the App Store.

## Testing checklist (do this after building, on each platform)

Run through the whole app on a machine that does **not** have Python or
any dev tools installed, to confirm it's genuinely self-contained:

- [ ] Double-clicking the built app opens a window (no terminal, no
      browser tab, no visible console) within a few seconds
- [ ] The Dataset screen loads and shows the bundled sample dataset
- [ ] Selecting it and clicking "Preview dataset" shows real thumbnails
- [ ] A full training run completes (Model Setup → Start Training →
      watch the live charts update → Training complete)
- [ ] Checkpoints get created — verify a `checkpoints/` folder appears
      **next to the app file** (not inside it) after training
- [ ] Resuming from a checkpoint works
- [ ] The Results screen shows real numbers, confusion matrix, and charts
- [ ] Saving a model works, and it appears in the Model Library
- [ ] Testing a saved model on a new image produces a prediction
- [ ] Comparing two runs works
- [ ] Closing the app and reopening it: previously saved models and
      checkpoints are still there (confirms data is being saved next to
      the app, not into a temporary folder that gets wiped)

If all of these pass, the packaged build is working correctly and is
ready to hand to students.

## Why checkpoints/models/reports appear next to the app, not inside it

This is intentional, not a bug. All the app's own bundled files (Python
runtime, PyTorch, the frontend, the sample dataset) live inside the
`_internal` folder next to the exe. That folder is meant to be treated as
part of the app itself — it gets fully replaced if a student updates to a
newer build. If saved checkpoints/models/reports were written in there
too, updating the app (or accidentally deleting/replacing `_internal`)
would silently wipe every trained model along with it. To prevent that,
EdSeg's backend was specifically updated (see `backend/paths.py`) to
always write persistent data to a location next to the actual
`EdSeg.exe`/`EdSeg.app` — outside `_internal` — so it survives updates
and reinstalls, not just normal open/close cycles.

## Rebuilding after making code changes

Delete the `build/` and `dist/` folders first, then re-run the
`pyinstaller launcher.spec --noconfirm` command. PyInstaller caches
aggressively and can sometimes bundle stale code if you don't clear
these first.
