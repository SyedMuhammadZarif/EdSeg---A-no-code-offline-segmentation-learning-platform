// EdSeg — "Behind the scenes" training visualisation.
//
// Phases:  idle -> starting (black-and-white plexus network, "Training is starting…")
//          -> revealing (pipeline stages fade in one by one) -> running (a pulse of
//          activity loops through the stages, like one training step after another)
//          -> done ("Final output ready") | stopped | failed.
//
// Look: large glowing line-art illustrations in the style of a 3D-medical-imaging
// pipeline diagram — glass cubes, stacked slice planes, a U-Net with streams of
// particles, loss between two volumes, the same network with the stream reversed
// for backpropagation — each with a caption and a live status line.
//
// What is real and what is illustration: the epoch, loss, Dice, model name, batch
// size, image/volume size and learning rate shown here come from the actual run.
// The looping highlight is an illustration of what happens inside every training
// step (the engine does not report per-step progress), and the panel says so.
//
// Accessibility: the artwork is aria-hidden; the captions are a real ordered list;
// there is a Pause button (animation longer than 5 s must be pausable);
// prefers-reduced-motion turns the movement off entirely.

const trainViz = (() => {
  const STEP_MS = 850;            // time each stage stays highlighted
  const START_MS = 2400;          // minimum time on the plexus "starting" screen
  const REVEAL_MS = 520;          // gap between stages appearing
  const FAST_REVEAL_MS = 110;     // used when training already finished / re-attaching
  const VALIDATE_MS = 1400;       // how long the validation stage lights up after an epoch
  const VALIDATE_GAP_MS = 4800;   // ...and at most this often, so fast epochs don't freeze the loop on it

  // ---------------------------------------------------------------- artwork
  // Every illustration is drawn in a 200 x 100 box. Shapes use CSS classes
  // (face, hid, bar, flow, ...) so trainviz.css controls colour and motion.

  const BLOB = `
    <ellipse class="blobfill" cx="100" cy="52" rx="34" ry="27"/>
    <ellipse class="blobfill core" cx="100" cy="51" rx="15" ry="12"/>
    <path class="contour" d="M75 53q3-19 25-17t27 13q4 15-10 21t-27 2q-15-4-15-19Z"/>
    <path class="contour" d="M84 51q6-11 18-7t15 9q0 11-12 13t-19-4q-5-4-2-11Z"/>
    <path class="contour c2" d="M92 50q4-4 10-1t9 3M90 58q8 5 14 1t9-1M95 44q6 3 11 1M86 54q3 4 8 4"/>
    <circle class="spark s1" cx="90" cy="45" r="1.2"/><circle class="spark s2" cx="110" cy="59" r="1.2"/><circle class="spark s3" cx="101" cy="50" r="1.4"/>
    <circle class="spark s2" cx="116" cy="47" r="1"/><circle class="spark s1" cx="86" cy="58" r="1"/><circle class="spark s3" cx="104" cy="41" r="1"/>`;

  const CUBE = (inner) => `
    <path class="hid" d="M100 72L54 72M100 72L146 72M100 72V32"/>
    <polygon class="face" points="54,32 100,54 100,94 54,72"/>
    <polygon class="face" points="100,54 146,32 146,72 100,94"/>
    <polygon class="face top" points="100,10 146,32 100,54 54,32"/>
    <path class="slc" d="M54 43L100 65M54 54L100 76M54 65L100 87M100 65L146 43M100 76L146 54M100 87L146 65"/>
    ${inner}`;

  const MINI = (x, y, i, sc = 1) => `<g class="mc" style="--i:${i}" transform="translate(${x} ${y}) scale(${sc})">
    <polygon class="face" points="-12,-1 0,5 0,17 -12,11"/><polygon class="face" points="0,5 12,-1 12,11 0,17"/><polygon class="face top" points="0,-7 12,-1 0,5 -12,-1"/></g>`;

  const PLANE = (y, cls) => `<g class="plane ${cls}"><polygon class="face" points="34,${y} 100,${y - 13} 166,${y} 100,${y + 13}"/></g>`;

  const UNET = (rev) => {
    const hs = [64, 50, 36, 24], xl = [10, 28, 46, 64], xr = [178, 160, 142, 124];
    const bar = (x, h, i) => `<rect class="bar" style="--i:${i}" x="${x}" y="${50 - h / 2}" width="12" height="${h}" rx="2"/><line class="barline" x1="${x + 6}" y1="${50 - h / 2 + 3}" x2="${x + 6}" y2="${50 + h / 2 - 3}"/>`;
    const bars = hs.map((h, i) => bar(xl[i], h, i)).join("") + bar(94, 12, 4) + hs.map((h, i) => bar(xr[i], h, 7 - i)).join("");
    const skips = hs.slice(0, 3).map((h, i) => { const top = 50 - h / 2; return `<path class="skip" d="M${xl[i] + 6} ${top}Q100 ${Math.max(-4, top - 34)} ${xr[i] + 6} ${top}"/>`; }).join("");
    return `<g class="unet ${rev ? "rev" : ""}">${skips}${bars}
      <path class="flow f1" d="M0 50H200"/><path class="flow f2" d="M0 40C40 28 62 52 100 50S160 66 200 58"/><path class="flow f3" d="M0 60C40 72 62 48 100 50S160 34 200 42"/></g>`;
  };

  const ART = {
    data3d: `<svg viewBox="0 0 200 100">${CUBE(BLOB)}</svg>`,
    data2d: `<svg viewBox="0 0 200 100"><polygon class="face top" points="26,52 100,20 174,52 100,84"/>
      <path class="hid" d="M26 58L100 90L174 58"/><polygon class="face" points="26,52 100,84 100,90 26,58"/><polygon class="face" points="100,84 174,52 174,58 100,90"/>
      <ellipse class="blobfill" cx="100" cy="52" rx="28" ry="12"/><path class="contour" d="M80 52q8-8 18-3t18-1q6 5-1 9t-17 2q-10 2-18-7Z"/>
      <circle class="spark s1" cx="94" cy="50" r="1.1"/><circle class="spark s2" cx="110" cy="55" r="1.1"/></svg>`,
    preprocess: `<svg viewBox="0 0 200 100">
      ${[[44, 26], [100, 18], [156, 26], [30, 56], [86, 50], [142, 58], [58, 84], [114, 82], [170, 78]].map(([x, y], i) => MINI(x, y, i, 1.15)).join("")}
      <path class="flow f1" d="M0 52H200"/></svg>`,
    model: `<svg viewBox="0 0 200 100">${UNET(false)}</svg>`,
    prediction: `<svg viewBox="0 0 200 100">${CUBE(BLOB + '<ellipse class="ring r1" cx="100" cy="52" rx="34" ry="27"/><ellipse class="ring r2" cx="100" cy="52" rx="34" ry="27"/>')}</svg>`,
    loss: `<svg viewBox="0 0 200 100">
      <g transform="translate(34 46)">${MINI(0, 0, 0, 1.9)}</g><g transform="translate(166 46)">${MINI(0, 0, 3, 1.9)}</g>
      <path class="flow f1" d="M54 50H82"/><path class="flow f1 back" d="M146 50H118"/>
      <circle class="ring lr1" cx="100" cy="50" r="16"/><circle class="ring lr2" cx="100" cy="50" r="16"/>
      <circle class="lossdisc" cx="100" cy="50" r="16"/><text x="100" y="53" text-anchor="middle" class="losstxt">LOSS</text></svg>`,
    gradients: `<svg viewBox="0 0 200 100">${UNET(true)}</svg>`,
    update: `<svg viewBox="0 0 200 100">
      ${PLANE(74, "u1")}${PLANE(56, "u2")}${PLANE(38, "u3")}${PLANE(20, "u4")}
      <path class="flow up" d="M44 92V6"/><path class="flow up" d="M100 96V0"/><path class="flow up" d="M156 92V6"/></svg>`,
    validate: `<svg viewBox="0 0 200 100"><g transform="translate(58 42)">${MINI(0, 0, 0, 2.2)}</g>
      <path class="flow f1" d="M84 50H112"/>
      <circle class="vring" cx="140" cy="50" r="19"/><path class="tick" d="M130 51l7 7 14-15"/></svg>`,
  };

  const s = {
    phase: "idle", info: {}, stages: [], active: -1, timers: [], cycleTimer: null,
    paused: false, screenVisible: false, lastEpoch: 0, total: 0, revealed: 0, pendingReveal: false,
    startedAt: 0, pollSeen: false, validateUntil: 0, lastValidateAt: 0, forceMotion: false, live: { loss: null, dice: null },
  };

  const reducedMotion = () => !s.forceMotion && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ------------------------------------------------------------------ plexus
  const plexus = { canvas: null, ctx: null, nodes: [], raf: 0, running: false, w: 0, h: 0 };

  function plexusResize() {
    const c = plexus.canvas;
    if (!c) return;
    const rect = c.getBoundingClientRect();
    if (rect.width < 10) return;
    const dpr = window.devicePixelRatio || 1;
    plexus.w = rect.width; plexus.h = rect.height;
    c.width = Math.round(rect.width * dpr); c.height = Math.round(rect.height * dpr);
    plexus.ctx = c.getContext("2d");
    plexus.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.max(30, Math.min(95, Math.round((rect.width * rect.height) / 5600)));
    plexus.nodes = Array.from({ length: count }, () => ({
      x: Math.random() * rect.width, y: Math.random() * rect.height,
      vx: (Math.random() - 0.5) * 0.45, vy: (Math.random() - 0.5) * 0.45, r: 1 + Math.random() * 1.4,
    }));
  }

  function plexusDraw() {
    const { ctx, w, h, nodes } = plexus;
    if (!ctx) return;
    ctx.clearRect(0, 0, w, h);
    const link = 110;
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < link) {
          ctx.strokeStyle = `rgba(255,255,255,${(1 - d / link) * 0.55})`;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
    }
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    nodes.forEach((n) => { ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2); ctx.fill(); });
  }

  function plexusStep() {
    plexus.raf = 0;
    if (!plexus.running || s.paused || !s.screenVisible) return;
    const speed = s.phase === "starting" ? 1 : 0.5;
    plexus.nodes.forEach((n) => {
      n.x += n.vx * speed; n.y += n.vy * speed;
      if (n.x < 0 || n.x > plexus.w) n.vx *= -1;
      if (n.y < 0 || n.y > plexus.h) n.vy *= -1;
    });
    plexusDraw();
    plexus.raf = requestAnimationFrame(plexusStep);
  }

  function plexusStart() {
    plexusResize();
    plexus.running = true;
    plexusDraw();
    if (!reducedMotion() && !plexus.raf) plexus.raf = requestAnimationFrame(plexusStep);
  }

  function plexusStop() {
    plexus.running = false;
    if (plexus.raf) cancelAnimationFrame(plexus.raf);
    plexus.raf = 0;
  }

  // ------------------------------------------------------------------ stages
  function stageDefs() {
    const i = s.info, three = i.dim === 3;
    const size = i.size ? (three ? `${i.size} × ${i.size} × ${i.size}` : `${i.size} × ${i.size}`) : null;
    const unit = three ? "volumes" : "images";
    return [
      { key: "data", art: three ? ART.data3d : ART.data2d, title: three ? "3D volume" : "2D image",
        sub: [size, i.batch ? `batch of ${i.batch} ${unit}` : null].filter(Boolean).join(" · ") || `a batch of ${unit}`, live: "Loading " + (three ? "volume" : "image") },
      { key: "pre", art: ART.preprocess, title: "Preprocess",
        sub: size ? `resize to ${size}, normalise` : "resize and normalise", live: "Preparing input" },
      { key: "model", art: ART.model, title: i.model || "Neural network",
        sub: "(encoder → bottleneck → decoder)", live: "Forward pass" },
      { key: "pred", art: ART.prediction, title: "Prediction",
        sub: `probability map · every ${three ? "voxel" : "pixel"}`, live: "Generating prediction" },
      { key: "loss", art: ART.loss, title: "Loss",
        sub: "Dice + cross-entropy" + (s.live.loss != null ? ` · now ${s.live.loss.toFixed(4)}` : ""), live: "Computing loss" },
      { key: "grad", art: ART.gradients, title: "Gradients",
        sub: "backpropagation", live: "Propagating gradients" },
      { key: "upd", art: ART.update, title: "Weight update",
        sub: "optimizer (Adam)" + (i.lr ? ` · learning rate ${i.lr}` : ""), live: "Updating weights" },
      { key: "val", art: ART.validate, title: "Validation check",
        sub: s.live.dice != null ? `unseen data · Dice ${s.live.dice.toFixed(3)}` : "tested on unseen data", live: "Checking unseen data" },
    ];
  }

  function buildStages() {
    const list = $("tv-stages");
    s.stages = stageDefs();
    list.innerHTML = s.stages.map((st, idx) => `
      <li class="tv-stage is-hidden" data-i="${idx}" data-key="${st.key}">
        <div class="tv-art" aria-hidden="true">${st.art}<span class="tv-check">✓</span></div>
        <div class="tv-text">
          <span class="tv-title">${esc(st.title)}</span>
          <span class="tv-sub">${esc(st.sub)}</span>
        </div>
        <div class="tv-state" aria-hidden="true">
          <span class="tv-state-text"><i class="tv-bullet"></i>${esc(st.live)}<i class="tv-dots"></i></span>
          <span class="tv-state-extra"></span>
        </div>
      </li>`).join("");
  }

  function refreshStageText() {
    const defs = stageDefs();
    document.querySelectorAll("#tv-stages .tv-stage").forEach((li, idx) => {
      li.querySelector(".tv-title").textContent = defs[idx].title;
      li.querySelector(".tv-sub").textContent = defs[idx].sub;
    });
    const extra = document.querySelector('#tv-stages .tv-stage[data-i="0"] .tv-state-extra');
    if (extra) extra.textContent = s.lastEpoch ? `Epoch ${s.lastEpoch} / ${s.total}` : "";
  }

  const el = (i) => document.querySelector(`#tv-stages .tv-stage[data-i="${i}"]`);

  function setActive(idx) {
    document.querySelectorAll("#tv-stages .tv-stage").forEach((li) => {
      const n = Number(li.dataset.i);
      li.classList.toggle("is-active", n === idx);
      li.classList.toggle("is-flow", n === idx - 1);   // the stream leading into the active stage glows
    });
    s.active = idx;
  }

  const later = (fn, ms) => { const t = setTimeout(fn, ms); s.timers.push(t); return t; };
  function clearTimers() { s.timers.forEach(clearTimeout); s.timers = []; if (s.cycleTimer) clearInterval(s.cycleTimer); s.cycleTimer = null; }

  // ------------------------------------------------------------------ phases
  function setStatus(text, kind) {
    const st = $("tv-status");
    st.textContent = text;
    st.className = "tv-status" + (kind ? ` is-${kind}` : "");
  }

  function begin(info = {}) {
    clearTimers();
    s.info = info; s.live = { loss: null, dice: null }; s.lastEpoch = 0; s.total = 0; s.revealed = 0;
    s.phase = "starting"; s.startedAt = Date.now(); s.pollSeen = false; s.pendingReveal = false; s.active = -1;
    const root = $("train-viz");
    root.className = "train-viz is-starting";
    root.classList.toggle("is-paused", s.paused);
    buildStages();
    $("tv-final").hidden = true;
    $("tv-chip-epoch").textContent = "Epoch –"; $("tv-chip-loss").textContent = "Loss –"; $("tv-chip-dice").textContent = "Dice –";
    setStatus("Training is starting…", "starting");
    $("tv-start-label").hidden = false;
    plexus.canvas.style.opacity = "1";
    plexusStart();
    if (info.fast) { s.pollSeen = true; later(reveal, 200); }
    else later(maybeReveal, START_MS);
  }

  function maybeReveal() {
    if (s.phase !== "starting") return;
    if (s.pollSeen) reveal(); else s.pendingReveal = true;
  }

  function reveal(fast) {
    if (s.phase !== "starting") return;
    s.phase = "revealing";
    $("train-viz").className = $("train-viz").className.replace("is-starting", "is-revealing");
    $("tv-start-label").hidden = true;
    plexus.canvas.style.opacity = "0.2";
    setStatus("Training in progress", "running");
    const gap = fast || reducedMotion() ? FAST_REVEAL_MS : REVEAL_MS;
    s.stages.forEach((_, idx) => later(() => {
      const li = el(idx); if (li) li.classList.remove("is-hidden");
      s.revealed = idx + 1;
      if (idx === s.stages.length - 1) later(startRunning, gap + 300);
    }, 150 + idx * gap));
  }

  function startRunning() {
    if (s.phase !== "revealing") return;
    s.phase = "running";
    $("train-viz").className = $("train-viz").className.replace("is-revealing", "is-running");
    if (reducedMotion()) { setActive(Math.max(0, Math.min(6, s.lastEpoch % 7))); return; }
    let idx = -1;
    const tick = () => {
      if (s.paused || !s.screenVisible || s.phase !== "running") return;
      if (Date.now() < s.validateUntil) return;                 // validation highlight owns the stage for a moment
      idx = (idx + 1) % 7;                                       // stages 0..6 loop; 7 (validation) is epoch-driven
      if (idx === 0) { const loop = $("tv-loop"); loop.classList.remove("pulse"); void loop.offsetWidth; loop.classList.add("pulse"); }
      setActive(idx);
    };
    tick();
    s.cycleTimer = setInterval(tick, STEP_MS);
  }

  /** Called with every status poll: real numbers for the chips and stage captions. */
  function update({ epoch, total, trainLoss, valDice, status }) {
    if (s.phase === "idle") return;
    s.pollSeen = true;
    if (s.pendingReveal) { s.pendingReveal = false; reveal(); }
    if (trainLoss != null) s.live.loss = trainLoss;
    if (valDice != null) s.live.dice = valDice;
    s.total = total;
    $("tv-chip-epoch").textContent = `Epoch ${epoch} / ${total}`;
    $("tv-chip-loss").textContent = `Loss ${trainLoss != null ? trainLoss.toFixed(4) : "–"}`;
    $("tv-chip-dice").textContent = `Dice ${valDice != null ? valDice.toFixed(3) : "–"}`;
    const newEpoch = epoch > 0 && epoch > s.lastEpoch;
    s.lastEpoch = epoch;
    if (s.phase === "running" || s.phase === "revealing") refreshStageText();
    if (newEpoch) {
      if (s.phase === "running") {
        if (reducedMotion()) {
          setActive(epoch % 7);                                  // no movement: step to the next stage once per epoch
        } else if (Date.now() - s.lastValidateAt >= VALIDATE_GAP_MS) {
          // An epoch just finished: light up the validation stage, then go back to the loop.
          s.lastValidateAt = Date.now();
          s.validateUntil = Date.now() + VALIDATE_MS; setActive(7);
        }
      }
      const chip = $("tv-chip-epoch"); chip.classList.remove("pulse"); void chip.offsetWidth; chip.classList.add("pulse");
    }
  }

  /** status: 'completed' | 'stopped' | 'error' */
  function finish(status) {
    if (s.phase === "idle" || s.phase === "done") return;
    const introUnfinished = s.phase === "starting" || s.phase === "revealing";
    if (s.cycleTimer) clearInterval(s.cycleTimer);
    s.cycleTimer = null;
    s.timers.forEach(clearTimeout); s.timers = [];
    const root = $("train-viz");

    const settle = () => {
      s.phase = "done";
      setActive(-1);
      root.className = "train-viz is-done is-" + status + (s.paused ? " is-paused" : "");
      document.querySelectorAll("#tv-stages .tv-stage").forEach((li) => li.classList.remove("is-flow"));
      $("tv-start-label").hidden = true;
      if (status === "completed") {
        // a quick wave of ticks down the pipeline, then the final banner
        const lis = [...document.querySelectorAll("#tv-stages .tv-stage")];
        lis.forEach((li, idx) => later(() => li.classList.add("is-done"), reducedMotion() ? 0 : 110 * idx));
        later(() => { $("tv-final").hidden = false; setStatus("Training complete", "done"); announce("Training finished. Final output ready."); }, reducedMotion() ? 0 : 110 * lis.length + 200);
        later(() => { plexus.canvas.style.opacity = "0"; later(plexusStop, 1500); }, 500);
      } else {
        setStatus(status === "stopped" ? "Training stopped" : "Training failed", status === "stopped" ? "stopped" : "error");
        plexus.canvas.style.opacity = "0"; later(plexusStop, 1500);
      }
    };

    if (introUnfinished) {
      // Training ended before the intro finished: reveal what is left quickly, then settle.
      $("tv-start-label").hidden = true;
      s.phase = "revealing";
      s.stages.forEach((_, idx) => later(() => { const li = el(idx); if (li) li.classList.remove("is-hidden"); }, 60 + idx * FAST_REVEAL_MS));
      later(settle, 60 + s.stages.length * FAST_REVEAL_MS + 250);
    } else {
      settle();
    }
  }

  function setPaused(paused) {
    s.paused = paused;
    const btn = $("tv-pause");
    btn.setAttribute("aria-pressed", paused ? "true" : "false");
    btn.textContent = paused ? "Resume animation" : "Pause animation";
    $("train-viz").classList.toggle("is-paused", paused);
    if (!paused && plexus.running && !plexus.raf && !reducedMotion()) plexus.raf = requestAnimationFrame(plexusStep);
  }

  function onScreenChange(isTrainScreen) {
    s.screenVisible = isTrainScreen;
    if (isTrainScreen) {
      requestAnimationFrame(() => {
        if (plexus.running) { plexusResize(); plexusDraw(); if (!plexus.raf && !s.paused && !reducedMotion()) plexus.raf = requestAnimationFrame(plexusStep); }
      });
    }
  }

  function init() {
    plexus.canvas = $("tv-plexus");
    $("tv-pause").addEventListener("click", () => setPaused(!s.paused));
    window.addEventListener("resize", () => { if (plexus.running) { plexusResize(); plexusDraw(); } });
    if (window.matchMedia) {
      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      if (mq.addEventListener) mq.addEventListener("change", () => { if (plexus.running) { plexusStop(); plexusStart(); } });
    }
    buildStages();
  }

  return { init, begin, update, finish, onScreenChange, setPaused, _state: s };
})();
