// EdSeg — main workflow screens: dataset, model setup, training, results.

// ---------------------------------------------------------------------------
// Shared: device chooser (used on setup / resume / sweep / testing)
// ---------------------------------------------------------------------------

function renderDeviceOptions(containerId, getKey, setKey) {
  const container = $(containerId);
  const devices = state.devices || {};
  const options = [
    { key: "auto", label: "Auto (recommended)", available: true },
    { key: "cpu", label: "CPU", available: true },
    { key: "cuda", label: "NVIDIA GPU (CUDA)", available: !!devices.cuda },
    { key: "mps", label: "Apple Silicon GPU", available: !!devices.mps },
  ];
  // A device that is no longer available (e.g. after a driver change) can't stay selected.
  if (!options.find((o) => o.key === getKey() && o.available)) setKey("auto");

  container.innerHTML = "";
  options.forEach((opt) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "device-option";
    btn.textContent = opt.label + (opt.available ? "" : " (not available)");
    btn.disabled = !opt.available;
    btn.setAttribute("aria-pressed", opt.key === getKey() ? "true" : "false");
    btn.addEventListener("click", () => {
      setKey(opt.key);
      container.querySelectorAll(".device-option").forEach((b) => b.setAttribute("aria-pressed", "false"));
      btn.setAttribute("aria-pressed", "true");
    });
    container.appendChild(btn);
  });
}

/** Explain, in plain words, why a GPU option is greyed out (and what the bigger build would cost). */
function renderDeviceNotice() {
  const box = $("device-notice");
  const b = state.build, d = state.devices || {};
  if (!b) { box.classList.add("hidden"); return; }
  const cudaSize = b.sizes_mb && (b.sizes_mb.cuda_folder || null);
  let html = "", cls = "callout";
  if (d.cuda) {
    cls += " callout-ok";
    html = `<strong>GPU ready</strong><p>${esc(b.gpu_name || "An NVIDIA GPU")} will be used when the device is set to Auto or GPU. Larger models and 3D volumes train much faster on it.</p>`;
  } else if (d.mps) {
    cls += " callout-ok";
    html = "<strong>Apple Silicon GPU ready</strong><p>Auto and GPU will use it.</p>";
  } else if (b.flavor === "cpu") {
    html = `<strong>This is the CPU-only build</strong><p>It runs on every computer but cannot use an NVIDIA GPU, so training uses your processor. Small 2D models train in seconds to minutes; 3D models and the full-size U-Net take longer. ` +
      `A separate CUDA build adds GPU support but is much larger${cudaSize ? ` (about ${esc(formatMB(cudaSize))} on disk)` : " (several gigabytes)"} &mdash; see <em>About this build</em> in the System info panel.</p>`;
  } else {
    cls += " callout-warn";
    html = "<strong>No usable NVIDIA GPU found</strong><p>This is the CUDA build, but this computer has no compatible NVIDIA GPU or its driver is missing or outdated, so training will use the CPU.</p>";
  }
  box.className = cls;
  box.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Dataset screen
// ---------------------------------------------------------------------------

let _previewToken = 0;

function datasetOptionLabel(ds) {
  const unit = ds.dim === 3 ? "volumes" : "images";
  return `${ds.display_name} — ${ds.dim === 3 ? "3D" : "2D"}, ${ds.count} ${unit} (${ds.source === "custom" ? "uploaded" : "bundled"})`;
}

async function loadDatasetList(selectKey) {
  const select = $("dataset-select");
  try {
    const data = await api("/api/datasets");
    state.datasets = data.datasets;
  } catch (err) {
    state.datasets = [];
    $("preview-summary").textContent = err.message;
  }
  select.innerHTML = '<option value="">-- Select a dataset --</option>';
  // Beginners should meet the simple 2D sample first, then 3D, then their own uploads.
  state.datasets.sort((a, b) => (a.dim - b.dim) || (a.source === b.source ? a.name.localeCompare(b.name) : (a.source === "bundled" ? -1 : 1)));
  state.datasets.forEach((ds) => {
    const option = document.createElement("option");
    option.value = `${ds.source}/${ds.name}`;
    option.textContent = datasetOptionLabel(ds);
    select.appendChild(option);
  });
  if (selectKey && state.datasets.some((d) => `${d.source}/${d.name}` === selectKey)) select.value = selectKey;
  else if (state.selectedDataset && state.datasets.some((d) => `${d.source}/${d.name}` === `${state.selectedDataset.source}/${state.selectedDataset.name}`)) {
    select.value = `${state.selectedDataset.source}/${state.selectedDataset.name}`;
  }
  $("delete-dataset-btn").classList.toggle("hidden", !selectedDatasetMeta() || selectedDatasetMeta().source !== "custom");
}

function selectedDatasetMeta() {
  const value = $("dataset-select").value;
  return state.datasets.find((d) => `${d.source}/${d.name}` === value) || null;
}

function setContinueEnabled(enabled, hint) {
  $("to-setup-btn").disabled = !enabled;
  $("continue-hint").textContent = hint;
}

async function previewSelectedDataset() {
  const meta = selectedDatasetMeta();
  const summary = $("preview-summary"), grid = $("preview-grid");
  $("delete-dataset-btn").classList.toggle("hidden", !meta || meta.source !== "custom");
  const token = ++_previewToken;
  grid.innerHTML = "";

  if (!meta) {
    state.selectedDataset = null;
    summary.textContent = "Select a dataset to see a preview.";
    setContinueEnabled(false, "Choose and preview a dataset to continue.");
    $("sidebar-dataset-info").innerHTML = '<p class="hint" style="margin:0;">No dataset selected yet.</p>';
    return;
  }

  setContinueEnabled(false, "Loading the preview…");
  summary.textContent = "Loading preview…";
  try {
    const data = await api(`/api/datasets/${encodeURIComponent(meta.name)}/preview?source=${encodeURIComponent(meta.source)}&count=4`);
    if (token !== _previewToken) return; // a newer selection superseded this one
    summary.textContent = `Showing ${data.pairs.length} of ${data.total_count} ${meta.dim === 3 ? "volumes (the slice with the most foreground)" : "image/mask pairs"}.`;
    renderSidebarDatasetInfo(meta, data.pairs);
    data.pairs.forEach((pair) => {
      const card = document.createElement("div");
      card.className = "preview-pair";
      card.innerHTML = `
        <div class="pair-images">
          <img src="${safeImageUrl(pair.image)}" alt="Image: ${esc(pair.filename)}" />
          <img src="${safeImageUrl(pair.mask)}" alt="Mask for ${esc(pair.filename)}" />
        </div>
        <div class="labels" aria-hidden="true"><span>Image</span><span>Mask</span></div>
        <div class="filename">${esc(pair.filename)}${pair.shape ? ` &middot; ${esc(pair.shape.join("×"))} voxels` : ""}</div>`;
      grid.appendChild(card);
    });
    state.selectedDataset = { ...meta };
    setContinueEnabled(true, `Selected: ${meta.display_name} (${meta.dim === 3 ? "3D" : "2D"}). Continue to choose a model.`);
  } catch (err) {
    if (token !== _previewToken) return;
    state.selectedDataset = null;
    summary.textContent = `Could not load this dataset: ${err.message}`;
    setContinueEnabled(false, "This dataset can't be used. Choose another.");
  }
}

async function uploadDataset() {
  const nameInput = $("upload-name"), fileInput = $("upload-file"), messageEl = $("upload-message"), btn = $("upload-btn");
  const name = nameInput.value.trim();
  const file = fileInput.files[0];
  messageEl.className = "message";
  messageEl.textContent = "";

  const fail = (text) => { messageEl.classList.add("error"); messageEl.textContent = text; };
  if (!name) return fail("Please enter a name for the dataset.");
  if (!/^[A-Za-z0-9_-]+$/.test(name)) return fail("Use only letters, numbers, dashes and underscores in the name.");
  if (!file) return fail("Please choose a .zip file to upload.");
  if (!file.name.toLowerCase().endsWith(".zip")) return fail("The dataset must be a .zip file.");
  if (file.size > 1024 * 1024 * 1024) return fail(`That file is ${(file.size / 1048576).toFixed(0)} MB; the limit is 1 GB.`);

  const form = new FormData();
  form.append("file", file);
  form.append("name", name);
  btn.disabled = true;
  messageEl.textContent = `Uploading and checking ${(file.size / 1048576).toFixed(1)} MB… large 3D datasets can take a minute.`;
  try {
    const data = await api("/api/datasets/upload", { method: "POST", form });
    messageEl.classList.add("success");
    messageEl.textContent = `Uploaded “${data.dataset.display_name}” — ${data.dataset.count} valid ${data.dataset.dim === 3 ? "3D volumes" : "image/mask pairs"} found.`;
    nameInput.value = ""; fileInput.value = "";
    await loadDatasetList(`custom/${data.dataset.name}`);
    await previewSelectedDataset();
  } catch (err) {
    fail(err.message);
  } finally {
    btn.disabled = false;
  }
}

async function deleteSelectedDataset() {
  const meta = selectedDatasetMeta();
  if (!meta || meta.source !== "custom") return;
  const ok = await uiConfirm("Delete this dataset?", `“${meta.display_name}” will be removed from this computer. Models already trained on it are kept. This cannot be undone.`, { confirmText: "Delete dataset", danger: true });
  if (!ok) return;
  try {
    await api(`/api/datasets/${encodeURIComponent(meta.name)}`, { method: "DELETE" });
    if (state.selectedDataset && state.selectedDataset.name === meta.name) state.selectedDataset = null;
    await loadDatasetList();
    $("dataset-select").value = "";
    await previewSelectedDataset();
    toast(`Deleted “${meta.display_name}”.`, "success");
    $("dataset-select").focus();
  } catch (err) {
    toast(err.message, "error");
  }
}

// ---------------------------------------------------------------------------
// Model setup screen
// ---------------------------------------------------------------------------

const currentDim = () => (state.selectedDataset ? state.selectedDataset.dim : 2);
const batchValues = () => (currentDim() === 3 ? BATCH_VALUES_3D : BATCH_VALUES_2D);

function archsForCurrentDataset() {
  return state.architectures.filter((a) => a.dim === currentDim());
}

function speedBadge(speed) {
  const labels = { fastest: "fastest", fast: "fast", medium: "moderate", slow: "slow" };
  return labels[speed] || speed;
}

function populateArchitectureSelect(preferred) {
  const select = $("architecture-select");
  const archs = archsForCurrentDataset();
  const keep = preferred || select.value;
  select.innerHTML = "";
  archs.forEach((arch) => {
    const option = document.createElement("option");
    option.value = arch.name;
    option.textContent = `${arch.display_name} · ${formatParams(arch.parameters)} parameters`;
    select.appendChild(option);
  });
  if (archs.some((a) => a.name === keep)) select.value = keep;
  updateArchitectureNote();

  const dimLabel = currentDim() === 3 ? "3D" : "2D";
  const rows = archs.map((a) => `<tr><th scope="row">${esc(a.display_name)}</th><td>${esc(formatParams(a.parameters))}</td><td>${esc(speedBadge(a.speed))}</td><td style="text-align:left;">${esc(a.description)}</td></tr>`).join("");
  $("architecture-table").innerHTML = `<caption>${dimLabel} models available for this dataset</caption><thead><tr><th scope="col">Model</th><th scope="col">Parameters</th><th scope="col">Speed</th><th scope="col">What makes it different</th></tr></thead><tbody>${rows}</tbody>`;
}

function updateArchitectureNote() {
  const note = $("architecture-note");
  const arch = state.architectures.find((a) => a.name === $("architecture-select").value);
  if (!arch) { note.classList.add("hidden"); return; }
  let extra = "";
  let cls = "callout";
  if (arch.speed === "slow" && arch.dim === 2) {
    cls += " callout-warn";
    extra = `<p><strong>Heads-up:</strong> this is a large model (${esc(formatParams(arch.parameters))} parameters). Training will take noticeably longer — potentially many minutes — than the lightweight options.</p>`;
  } else if (arch.dim === 3) {
    cls += arch.speed === "slow" ? " callout-warn" : "";
    extra = `<p><strong>3D models</strong> look at the whole volume at once, which costs memory and time. Keep the volume size and batch size small on a CPU${arch.speed === "slow" ? "; this one is among the slower models" : ""}.</p>`;
  }
  note.className = cls;
  note.innerHTML = `<strong>${esc(arch.display_name)}</strong> <span class="badge badge-muted">${esc(speedBadge(arch.speed))}</span><p>${esc(arch.description)}</p>${extra}`;
}

function setupSliders() {
  const bind = (sliderId, valueId, format, valueText) => {
    const slider = $(sliderId), out = $(valueId);
    const update = () => {
      const text = format(slider.value);
      out.textContent = text;
      slider.setAttribute("aria-valuetext", valueText ? valueText(slider.value, text) : text);
    };
    slider.addEventListener("input", update);
    update();
    return update;
  };
  state.updateLr = bind("lr-slider", "lr-value", (v) => String(LR_VALUES[v]), (v, t) => `Learning rate ${t}`);
  bind("epochs-slider", "epochs-value", (v) => v, (v) => `${v} epochs`);
  state.updateBatch = bind("batch-slider", "batch-value", (v) => String(batchValues()[v]), (v, t) => `Batch size ${t}`);
  state.updateSize = bind("size-slider", "size-value", (v) => (currentDim() === 3 ? `${v}×${v}×${v} voxels` : `${v}×${v} pixels`));
  bind("val-split-slider", "val-split-value", (v) => `${v}%`);
  bind("subset-slider", "subset-value", (v) => v, (v) => `${v} ${currentDim() === 3 ? "volumes" : "images"}`);
  bind("early-stopping-patience-slider", "early-stopping-patience-value", (v) => v);
  bind("resume-epochs-slider", "resume-epochs-value", (v) => v);

  $("early-stopping-toggle").addEventListener("change", () => {
    $("early-stopping-patience-row").classList.toggle("hidden", !$("early-stopping-toggle").checked);
  });
}

/** Re-shape the sliders for the selected dataset (2D image vs 3D volume). */
function configureSlidersForDataset() {
  const is3d = currentDim() === 3;
  const count = state.selectedDataset ? state.selectedDataset.count : 24;

  const subset = $("subset-slider");
  subset.min = Math.min(4, count);
  subset.max = Math.max(count, subset.min);
  subset.value = Math.min(count, is3d ? 40 : 200);
  $("subset-slider").dispatchEvent(new Event("input"));
  $("subset-hint").textContent = `How many ${is3d ? "volumes" : "images"} to actually use (this dataset has ${count}). ` +
    "Using fewer trains faster and shows how less data affects results; the default is capped so a first run stays quick.";

  const size = $("size-slider");
  if (is3d) { size.min = 24; size.max = 64; size.step = 8; size.value = 32; }
  else { size.min = 64; size.max = 256; size.step = 16; size.value = 128; }
  $("size-label").textContent = is3d ? "Volume size (cube side)" : "Image size";
  $("size-hint").textContent = is3d
    ? "Every scan is resized to a cube this many voxels on each side. Memory and time grow with the cube of this number — 32 is quick on a CPU, 64 is eight times heavier."
    : "Images are resized to a square this many pixels wide. Larger shows more detail but trains slower (time grows with the square of this number).";
  state.updateSize();

  const batch = $("batch-slider");
  batch.value = is3d ? 1 : 2;
  state.updateBatch();
  $("batch-hint").textContent = is3d
    ? "How many volumes are processed together before updating the model. 3D volumes use a lot of memory, so keep this small (1–6)."
    : "How many images are processed together before updating the model. Larger batches are more stable but use more memory.";
  // Defaults chosen by measurement: 0.005 with 15 epochs reached Dice >= 0.96 on every one of 10 random seeds
  // for the starter dataset, whereas 0.001 with 10 epochs failed to learn on roughly 1 run in 5.
  $("epochs-slider").value = 15;
  $("lr-slider").value = 3;
  state.updateLr();
  $("epochs-slider").dispatchEvent(new Event("input"));
}

function getHyperparams() {
  return {
    architecture: $("architecture-select").value,
    learning_rate: LR_VALUES[$("lr-slider").value],
    epochs: parseInt($("epochs-slider").value, 10),
    batch_size: batchValues()[$("batch-slider").value],
    image_size: parseInt($("size-slider").value, 10),
    val_split: parseInt($("val-split-slider").value, 10) / 100,
    subset_size: parseInt($("subset-slider").value, 10),
    device_preference: state.selectedDevice,
    early_stopping_enabled: $("early-stopping-toggle").checked,
    early_stopping_patience: parseInt($("early-stopping-patience-slider").value, 10),
  };
}

let _setupDatasetKey = null;

function goToSetup() {
  if (!state.selectedDataset) { showScreen("dataset"); return; }
  const ds = state.selectedDataset;
  $("selected-dataset-label").textContent = `${ds.display_name} (${ds.count} ${ds.dim === 3 ? "volumes" : "images"})`;
  const kind = $("selected-dataset-kind");
  kind.textContent = ds.dim === 3 ? "3D volumes" : "2D images";
  // Only reshape sliders when the dataset changed, so a student's settings survive Back/Continue.
  const key = `${ds.source}/${ds.name}`;
  if (key !== _setupDatasetKey) {
    _setupDatasetKey = key;
    populateArchitectureSelect();
    configureSlidersForDataset();
  }
  $("setup-error").textContent = "";
  renderDeviceOptions("device-options", () => state.selectedDevice, (k) => { state.selectedDevice = k; });
  renderDeviceNotice();
  showScreen("setup");
}

// ---------------------------------------------------------------------------
// Training screen
// ---------------------------------------------------------------------------

let _pollTimer = null;

function prepareTrainingView(totalEpochs, title, vizInfo) {
  state.totalEpochs = totalEpochs;
  state.lossHistory = [];
  state.metricHistory = [];
  $("training-title").textContent = title || "Training…";
  $("stop-training-btn").classList.remove("hidden");
  $("stop-training-btn").disabled = false;
  ["train-another-btn", "view-results-btn", "train-back-setup-btn"].forEach((id) => $(id).classList.add("hidden"));
  $("train-error-callout").classList.add("hidden");
  setProgress(0, "Starting…");
  $("progress-text").textContent = "Starting…";
  $("preview-live").innerHTML = "";
  clearCanvas("loss-chart", "Loss chart: no data yet");
  clearCanvas("metric-chart", "Dice and IoU chart: no data yet");
  $("loss-table").innerHTML = ""; $("metric-table").innerHTML = "";
  trainViz.begin(vizInfo || {});
  showScreen("train");
}

function setProgress(percent, text) {
  $("progress-bar-fill").style.width = `${percent}%`;
  const track = $("progress-track");
  track.setAttribute("aria-valuenow", String(Math.round(percent)));
  track.setAttribute("aria-valuetext", text);
}

async function startTraining() {
  const params = getHyperparams();
  const errEl = $("setup-error"), btn = $("start-training-btn");
  errEl.textContent = "";
  btn.disabled = true;
  try {
    const data = await api("/api/train/start", { method: "POST", json: {
      dataset_name: state.selectedDataset.name,
      dataset_source: state.selectedDataset.source,
      model_name: params.architecture,
      learning_rate: params.learning_rate,
      epochs: params.epochs,
      batch_size: params.batch_size,
      image_size: params.image_size,
      val_split: params.val_split,
      subset_size: params.subset_size,
      device_preference: params.device_preference,
      checkpoint_every: 5,
      early_stopping_enabled: params.early_stopping_enabled,
      early_stopping_patience: params.early_stopping_patience,
    } });
    state.currentRunId = data.run_id;
    const arch = state.architectures.find((a) => a.name === params.architecture);
    prepareTrainingView(Math.min(params.epochs, 100), "Training…", {
      dim: state.selectedDataset.dim, model: arch ? arch.display_name.replace(/\s*\(.*\)$/, "") : params.architecture,
      batch: params.batch_size, size: params.image_size, lr: params.learning_rate,
    });
    beginTrainingPolling();
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    btn.disabled = false;
  }
}

function beginTrainingPolling() {
  state.trainingActive = true;
  setRunningBadges();
  if (_pollTimer) clearTimeout(_pollTimer);
  let failures = 0;
  const tick = async () => {
    if (!state.currentRunId) return;
    try {
      const data = await api(`/api/train/status/${encodeURIComponent(state.currentRunId)}`);
      failures = 0;
      $("train-error-callout").classList.toggle("hidden", $("train-error-callout").dataset.kind !== "result");
      updateTrainingView(data);
      if (["completed", "stopped", "error"].includes(data.status)) {
        state.trainingActive = false;
        setRunningBadges();
        finishTraining(data);
        return;
      }
    } catch (err) {
      failures += 1;
      if (failures >= 4) {
        const box = $("train-error-callout");
        box.dataset.kind = "connection";
        box.className = "callout callout-warn";
        box.textContent = "Lost contact with EdSeg's engine. Training may still be running — retrying…";
      }
    }
    _pollTimer = setTimeout(tick, 800);
  };
  tick();
}

let _lastProgressText = "";

function updateTrainingView(status) {
  const metrics = status.metrics_so_far || [];
  const total = status.total_epochs || state.totalEpochs || metrics.length || 1;
  state.totalEpochs = total;
  const done = metrics.length;
  const percent = Math.min(100, (done / total) * 100);
  const text = `Epoch ${done} of ${total}` + (done ? ` — latest train loss ${fmt(metrics[done - 1].train_loss)}` + (metrics[done - 1].val_dice != null ? `, validation Dice ${fmt(metrics[done - 1].val_dice)}` : "") : "");
  setProgress(percent, `${done} of ${total} epochs complete`);
  if (text !== _lastProgressText) { $("progress-text").textContent = text; _lastProgressText = text; }
  if (status.label) $("training-title").textContent = status.status === "running" ? `Training ${status.label}…` : $("training-title").textContent;

  state.lossHistory = metrics.map((m) => ({ epoch: m.epoch, train_loss: m.train_loss, val_loss: m.val_loss }));
  state.metricHistory = metrics.map((m) => ({ epoch: m.epoch, val_dice: m.val_dice, val_iou: m.val_iou }));
  drawLossChart();
  drawMetricChart();
  if (status.latest_preview) renderLivePreview(status.latest_preview);
  const lastM = metrics[done - 1];
  trainViz.update({ epoch: done, total, trainLoss: lastM ? lastM.train_loss : null, valDice: lastM ? lastM.val_dice : null, status: status.status });
}

function finishTraining(status) {
  $("stop-training-btn").classList.add("hidden");
  $("train-another-btn").classList.remove("hidden");
  $("train-back-setup-btn").classList.remove("hidden");

  trainViz.finish(status.status);
  const titleEl = $("training-title");
  const done = (status.metrics_so_far || []).length, total = status.total_epochs || state.totalEpochs;
  const box = $("train-error-callout");
  box.dataset.kind = "";
  if (status.status === "completed") {
    titleEl.textContent = "Training complete";
    if (done < total) {
      $("progress-text").textContent = `Finished after ${done} of ${total} epochs — early stopping ended the run because validation loss stopped improving, and the best epoch was kept.`;
    } else {
      $("progress-text").textContent = `Finished all ${total} epochs.`;
    }
    setProgress(100, "Training complete");
  } else if (status.status === "stopped") {
    titleEl.textContent = "Training stopped early";
    $("progress-text").textContent = done === 0
      ? "Stopped before the first epoch finished, so nothing was saved."
      : `Stopped after ${done} of ${total} epochs. Your progress was saved as a checkpoint.`;
  } else {
    titleEl.textContent = "Training failed";
    const lines = String(status.error || "An unknown error occurred.").split("\n");
    box.dataset.kind = "result";
    box.className = "callout callout-danger";
    box.innerHTML = `<strong>Training could not finish</strong><p>${esc(lines[0])}</p>` +
      (lines.length > 1 ? `<details class="data-table-details"><summary>Technical details</summary><pre class="layout">${esc(lines.slice(1).join("\n"))}</pre></details>` : "");
    $("progress-text").textContent = "Training failed.";
  }
  announce(`${titleEl.textContent}. ${$("progress-text").textContent}`, status.status === "error");
  titleEl.focus({ preventScroll: true });

  const paths = status.final_result && status.final_result.checkpoint_paths;
  if (paths && paths.length) {
    state.lastCheckpointPath = paths[paths.length - 1];
    $("view-results-btn").classList.remove("hidden");
  }
}

async function stopTraining() {
  if (!state.currentRunId) return;
  $("stop-training-btn").disabled = true;
  $("progress-text").textContent = "Stopping after the current epoch…";
  try {
    await api(`/api/train/stop/${encodeURIComponent(state.currentRunId)}`, { method: "POST" });
  } catch (err) {
    toast(err.message, "error");
    $("stop-training-btn").disabled = false;
  }
}

function renderLivePreview(preview) {
  const sliceNote = preview.slice_index !== undefined ? ` (slice ${preview.slice_index + 1} of ${preview.depth})` : "";
  $("preview-live").innerHTML = ["image|Input", "ground_truth|Ground truth", "prediction|Prediction"].map((spec) => {
    const [key, label] = spec.split("|");
    return `<figure class="preview-item"><img src="${safeImageUrl(preview[key])}" alt="${label}${esc(sliceNote)}" /><figcaption class="preview-item-label">${label}</figcaption></figure>`;
  }).join("");
  $("live-preview-hint").textContent = preview.slice_index !== undefined
    ? `A validation volume the model hasn't been directly trained on — showing the slice with the most foreground (slice ${preview.slice_index + 1} of ${preview.depth}).`
    : "A validation image the model hasn't been directly trained on — watch the prediction improve as training progresses.";
}

function drawLossChart() {
  const h = state.lossHistory;
  drawLineChart($("loss-chart"), [
    { label: "Train loss", color: chartPalette()[0], dash: [], marker: "circle", values: h.map((m) => m.train_loss) },
    { label: "Validation loss", color: chartPalette()[1], dash: [7, 4], marker: "square", values: h.map((m) => m.val_loss) },
  ]);
  const last = h[h.length - 1];
  $("loss-chart").setAttribute("aria-label", last
    ? `Loss chart over ${h.length} epochs. Latest train loss ${fmt(last.train_loss)}, validation loss ${fmt(last.val_loss)}. A table of all values follows.`
    : "Loss chart: no data yet");
  if (h.length) renderDataTable("loss-table", "Loss per epoch", ["Epoch", "Train loss", "Validation loss"], h.map((m) => [m.epoch, fmt(m.train_loss), fmt(m.val_loss)]));
}
registerChartRedraw("loss-chart", drawLossChart);

function drawMetricChart() {
  const h = state.metricHistory;
  drawLineChart($("metric-chart"), [
    { label: "Validation Dice", color: chartPalette()[2], dash: [], marker: "circle", values: h.map((m) => m.val_dice) },
    { label: "Validation IoU", color: chartPalette()[3], dash: [7, 4], marker: "triangle", values: h.map((m) => m.val_iou) },
  ], { yMin: 0, yMax: 1 });
  const last = h[h.length - 1];
  $("metric-chart").setAttribute("aria-label", last
    ? `Dice and IoU chart over ${h.length} epochs. Latest Dice ${fmt(last.val_dice)}, IoU ${fmt(last.val_iou)}. A table of all values follows.`
    : "Dice and IoU chart: no data yet");
  if (h.length) renderDataTable("metric-table", "Validation Dice and IoU per epoch", ["Epoch", "Dice", "IoU"], h.map((m) => [m.epoch, fmt(m.val_dice), fmt(m.val_iou)]));
}
registerChartRedraw("metric-chart", drawMetricChart);

// ---------------------------------------------------------------------------
// Results screen
// ---------------------------------------------------------------------------

function summaryCardsHtml(items) {
  return items.map((c) => `<div class="summary-card"><dt class="summary-label">${esc(c.label)}</dt><dd class="summary-value" style="margin:0;">${esc(c.text !== undefined ? c.text : fmt(c.value))}</dd></div>`).join("");
}

function buildConfusionMatrixHtml(cm, scope, unit = "pixels") {
  const n = (v) => Number(v).toLocaleString();
  return `
    <table class="confusion-table">
      <caption>Confusion matrix: rows are the true class, columns are what the model predicted.</caption>
      <thead><tr><td></td><th scope="col">Predicted: foreground</th><th scope="col">Predicted: background</th></tr></thead>
      <tbody>
        <tr><th scope="row">Actual: foreground</th>
          <td class="tp"><span class="cell-count">${n(cm.tp)}</span>True positive</td>
          <td class="fn"><span class="cell-count">${n(cm.fn)}</span>False negative</td></tr>
        <tr><th scope="row">Actual: background</th>
          <td class="fp"><span class="cell-count">${n(cm.fp)}</span>False positive</td>
          <td class="tn"><span class="cell-count">${n(cm.tn)}</span>True negative</td></tr>
      </tbody>
    </table>
    <p class="hint" style="text-align:center; margin-top:0.625rem;">${n(cm.total_pixels)} total ${unit} evaluated ${esc(scope)} — accuracy ${(cm.accuracy * 100).toFixed(1)}%</p>`;
}

let _resultsToken = 0;

async function goToResultsScreen(checkpointPath, backAction, backLabel) {
  if (!checkpointPath) return;
  $("back-from-results-btn").textContent = `\u2190 ${backLabel || "Back"}`;
  state.lastCheckpointPath = checkpointPath;
  state.resultsBackAction = backAction || (() => showScreen("dataset"));
  const token = ++_resultsToken;

  showScreen("results");
  $("report-message").textContent = ""; $("save-model-message").textContent = "";
  $("save-model-name").value = ""; $("results-error").textContent = "";
  $("results-run-label").textContent = "Loading…";
  $("results-verdict").classList.add("hidden");
  ["results-summary-cards", "confusion-matrix-container", "sample-predictions-grid"].forEach((id) => { $(id).innerHTML = ""; });
  clearCanvas("metric-bar-chart", "Metric bar chart: no data yet");
  $("metric-bar-table").innerHTML = "";
  $("results-summary-cards").setAttribute("aria-busy", "true");

  try {
    const data = await api(`/api/results?checkpoint_path=${encodeURIComponent(checkpointPath)}`);
    if (token !== _resultsToken) return;
    renderResults(data);
  } catch (err) {
    if (token !== _resultsToken) return;
    $("results-run-label").textContent = "Could not load";
    $("results-error").textContent = err.message;
  } finally {
    $("results-summary-cards").removeAttribute("aria-busy");
  }
}

/** A plain-language answer to "did it work?" for students who don't yet read Dice scores. */
function showVerdict(dice) {
  const box = $("results-verdict");
  let cls = "callout", title, text;
  if (dice >= 0.85) { cls += " callout-ok"; title = "Excellent — the model found the structure well."; text = `A Dice score of ${fmt(dice, 2)} means the predicted outline overlaps the correct one almost completely.`; }
  else if (dice >= 0.7) { cls += " callout-ok"; title = "Good result."; text = `Dice ${fmt(dice, 2)}: the prediction matches the correct outline fairly closely. More epochs may improve it a little.`; }
  else if (dice >= 0.4) { cls += " callout-warn"; title = "Partly learned — there is room to improve."; text = `Dice ${fmt(dice, 2)}. Try more epochs, a different learning rate, or a different model, then compare the runs.`; }
  else { cls += " callout-warn"; title = "The model hasn't learned this yet."; text = `Dice ${fmt(dice, 2)} is low. Training for more epochs usually helps, or try Resume Training to continue from this checkpoint. Very small or hard datasets also need more data.`; }
  box.className = cls;
  box.innerHTML = `<strong>${esc(title)}</strong><p>${esc(text)} <em>Dice runs from 0 (no overlap) to 1 (perfect).</em></p>`;
}

function renderResults(data) {
  const cfg = data.config || {};
  const is3d = cfg.dim === 3;
  $("results-run-label").textContent = `${runIdFromPath(data.checkpoint_path)} (epoch ${data.epoch}) — ${is3d ? "3D, " + cfg.image_size + "³ voxels" : "2D, " + cfg.image_size + "×" + cfg.image_size + " pixels"}`;

  const last = data.metrics_history[data.metrics_history.length - 1] || {};
  const cm = data.confusion_matrix;
  $("results-summary-cards").innerHTML = summaryCardsHtml([
    { label: "Final train loss", value: last.train_loss },
    { label: "Final validation loss", value: last.val_loss },
    { label: "Overall Dice", value: cm.dice },
    { label: "Overall IoU", value: cm.iou },
    { label: "Precision", value: cm.precision },
    { label: "Recall", value: cm.recall },
  ]);
  showVerdict(cm.dice);
  $("confusion-matrix-container").innerHTML = buildConfusionMatrixHtml(cm, "across the validation set", is3d ? "voxels" : "pixels");

  const labels = ["Precision", "Recall", "Dice", "IoU", "Accuracy"];
  const values = [cm.precision, cm.recall, cm.dice, cm.iou, cm.accuracy];
  const draw = () => drawBarChart($("metric-bar-chart"), labels, values, { max: 1 });
  draw();
  registerChartRedraw("metric-bar-chart", draw);
  $("metric-bar-chart").setAttribute("aria-label", "Metric bar chart: " + labels.map((l, i) => `${l} ${fmt(values[i], 3)}`).join(", "));
  renderDataTable("metric-bar-table", "Overall validation metrics", ["Metric", "Value"], labels.map((l, i) => [l, fmt(values[i], 4)]));

  fillPredictionGrid("sample-predictions-grid", data.sample_predictions);
  state.currentResultsCheckpointPath = data.checkpoint_path;
}

async function saveModelFromResults() {
  const nameInput = $("save-model-name"), msg = $("save-model-message");
  const name = nameInput.value.trim();
  msg.className = "message";
  if (!name) { msg.classList.add("error"); msg.textContent = "Please enter a name for this model."; nameInput.focus(); return; }
  msg.textContent = "Saving…";
  try {
    const data = await api("/api/model/save", { method: "POST", json: { checkpoint_path: state.currentResultsCheckpointPath, name } });
    msg.classList.add("success");
    msg.textContent = `Saved as “${data.model.name}” — find it in the Model Library.`;
  } catch (err) {
    msg.classList.add("error"); msg.textContent = err.message;
  }
}

async function saveReport() {
  const msg = $("report-message");
  msg.className = "message"; msg.textContent = "Saving…";
  try {
    const data = await api("/api/results/save_report", { method: "POST", json: { checkpoint_path: state.currentResultsCheckpointPath } });
    msg.classList.add("success");
    msg.innerHTML = `Saved as <strong>${esc(data.filename)}</strong> — <a href="/api/reports/${encodeURIComponent(data.filename)}" download>download it</a>`;
  } catch (err) {
    msg.classList.add("error"); msg.textContent = err.message;
  }
}
