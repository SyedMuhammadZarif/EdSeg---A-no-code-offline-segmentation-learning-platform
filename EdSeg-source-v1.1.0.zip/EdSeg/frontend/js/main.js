// EdSeg — start-up and event wiring.

// This app has no real page-to-page navigation (every "screen" is show/hide on
// one page), so the mouse's side back/forward buttons would only ever take the
// desktop window back to its start-up loading screen. Block them.
["mousedown", "mouseup"].forEach((eventName) => {
  window.addEventListener(eventName, (e) => {
    if (e.button === 3 || e.button === 4) { e.preventDefault(); e.stopPropagation(); }
  }, { capture: true });
});
try {
  history.pushState(null, "", location.href);
  window.addEventListener("popstate", () => history.pushState(null, "", location.href));
} catch (_) { /* history API unavailable in this context */ }

function resetToDataset() {
  state.resultsBackAction = null;
  tuningState.viewingHistoricalId = null;
  showScreen("dataset");
}

async function loadArchitectures() {
  try {
    const data = await api("/api/models/architectures");
    state.architectures = data.architectures;
  } catch (err) {
    state.architectures = [];
    toast(err.message, "error");
  }
  renderSidebarArchitectures();
}

async function loadDevices() {
  try {
    state.devices = await api("/api/devices");
  } catch (_) {
    state.devices = { cpu: true, cuda: false, mps: false };
  }
  renderSidebarDevices();
}

async function loadBuildInfo() {
  try {
    state.build = await api("/api/build_info");
  } catch (_) {
    state.build = null;
  }
  renderBuildInfo();
}

/** If something is still running in the engine (e.g. the window was reloaded), pick it back up. */
async function reattachToRunningJobs() {
  try {
    const active = await api("/api/jobs/active");
    if (active.training) {
      state.currentRunId = active.training;
      prepareTrainingView(active.training_total_epochs || 1, "Training…", { fast: true });
      beginTrainingPolling();
      toast("A training run was already in progress — showing it.", "info");
    }
    if (active.tuning) {
      tuningState.currentId = active.tuning;
      goToTuningResultsScreen();
      toast("A hyperparameter sweep was already in progress — showing it.", "info");
    }
  } catch (_) { /* nothing to re-attach to */ }
}

function on(id, event, handler) { $(id).addEventListener(event, handler); }

window.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  initTextScale();
  renderIcons();
  initDrawers();
  trainViz.init();
  _wireRestoreFocus($("dlg-generic"));
  _wireRestoreFocus($("dlg-concepts"));

  on("theme-toggle-btn", "click", toggleTheme);
  on("text-smaller-btn", "click", () => applyTextScale(_textScaleIndex - 1));
  on("text-larger-btn", "click", () => applyTextScale(_textScaleIndex + 1));
  document.querySelectorAll(".nav-item").forEach((item) => item.addEventListener("click", () => handleSidebarNav(item.dataset.nav)));

  // Dataset
  on("dataset-select", "change", previewSelectedDataset);
  on("upload-btn", "click", uploadDataset);
  on("delete-dataset-btn", "click", deleteSelectedDataset);
  on("to-setup-btn", "click", goToSetup);
  on("to-resume-btn", "click", goToResumeScreen);
  on("to-library-btn", "click", goToModelLibraryScreen);
  on("to-compare-btn", "click", goToCompareScreen);

  // Setup
  on("architecture-select", "change", updateArchitectureNote);
  on("back-to-dataset-btn", "click", () => showScreen("dataset"));
  on("start-training-btn", "click", startTraining);
  on("to-tuning-btn", "click", goToTuningSetupScreen);

  // Training
  on("stop-training-btn", "click", stopTraining);
  on("train-another-btn", "click", goToSetup);
  on("train-back-setup-btn", "click", resetToDataset);
  on("view-results-btn", "click", () => goToResultsScreen(state.lastCheckpointPath, () => showScreen("train"), "Back to training"));

  // Results
  on("back-from-results-btn", "click", () => (state.resultsBackAction || resetToDataset)());
  on("save-model-btn", "click", saveModelFromResults);
  on("save-report-btn", "click", saveReport);
  on("view-all-predictions-btn", "click", viewAllPredictionsFromResults);

  // Resume
  on("back-from-resume-list-btn", "click", () => showScreen("dataset"));
  on("back-from-resume-btn", "click", () => $("resume-config-panel").classList.add("hidden"));
  on("start-resume-btn", "click", startResumeTraining);

  // Sweeps
  on("back-from-tuning-setup-btn", "click", () => goToSetup());
  on("start-tuning-btn", "click", startTuning);
  on("stop-tuning-btn", "click", stopTuning);
  on("to-sweep-library-btn", "click", goToSweepLibraryScreen);
  on("back-from-sweep-library-btn", "click", goToTuningSetupScreen);
  on("back-from-tuning-results-btn", "click", () => (tuningState.viewingHistoricalId ? goToSweepLibraryScreen() : resetToDataset()));

  // Library / testing / gallery / compare
  on("back-from-library-btn", "click", () => showScreen("dataset"));
  on("testing-mode-single-btn", "click", () => switchTestingMode("single"));
  on("testing-mode-dataset-btn", "click", () => switchTestingMode("dataset"));
  on("run-inference-btn", "click", runInference);
  on("run-dataset-test-btn", "click", runDatasetTest);
  on("view-all-dataset-predictions-btn", "click", viewAllPredictionsFromDatasetTest);
  on("back-from-testing-btn", "click", goToModelLibraryScreen);
  on("back-from-gallery-btn", "click", () => (_galleryBack || resetToDataset)());
  on("run-compare-btn", "click", runComparison);
  on("back-from-compare-btn", "click", () => showScreen("dataset"));

  // Concepts
  initConceptsDialog();
  on("close-concepts-btn", "click", () => $("dlg-concepts").close());
  $("dlg-concepts").addEventListener("click", (e) => { if (e.target === $("dlg-concepts")) $("dlg-concepts").close(); });

  setupSliders();
  showScreen("dataset", { focus: false });

  const online = await checkBackendConnection();
  if (!online) {
    $("preview-summary").textContent = "EdSeg's engine isn't responding yet. Wait a moment, then reload this window.";
    return;
  }
  await Promise.all([loadBuildInfo(), loadDevices(), loadArchitectures()]);
  await loadDatasetList();
  const starter = state.datasets.find((d) => d.source === "bundled" && d.dim === 2);
  if (starter && !state.selectedDataset) {
    $("dataset-select").value = `${starter.source}/${starter.name}`;
    await previewSelectedDataset();
  }
  await reattachToRunningJobs();
  setInterval(checkBackendConnection, 20000);
});
