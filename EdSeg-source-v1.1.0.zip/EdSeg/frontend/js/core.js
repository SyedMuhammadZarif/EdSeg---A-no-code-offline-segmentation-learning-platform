// EdSeg — core helpers shared by every screen.
// No external libraries or network requests other than the local API: the app
// works fully offline. All dynamic text is escaped (esc) before it is placed
// in HTML, so dataset / file / model names can never inject markup.

const ICONS = {
  brain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 5 3 3 0 0 0 2 5v1a3 3 0 0 0 6 0V6a2 2 0 0 0-3-2z"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 5 3 3 0 0 1-2 5v1a3 3 0 0 1-6 0V6a2 2 0 0 1 3-2z"/></svg>',
  database: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
  "bar-chart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="20" x2="6" y2="12"/><line x1="12" y1="20" x2="12" y2="6"/><line x1="18" y1="20" x2="18" y2="14"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
  flask: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6"/><path d="M10 3v6l-6 10a1.5 1.5 0 0 0 1.3 2.2h13.4A1.5 1.5 0 0 0 20 19L14 9V3"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  scale: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="3" x2="12" y2="21"/><path d="M5 7h14"/><path d="M5 7l-3 7a3.5 3.5 0 0 0 6 0z"/><path d="M19 7l-3 7a3.5 3.5 0 0 0 6 0z"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  "check-circle": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
  cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="15" x2="23" y2="15"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="15" x2="4" y2="15"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
  package: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
};

function renderIcons(root) {
  (root || document).querySelectorAll("[data-icon]").forEach((el) => {
    const key = el.getAttribute("data-icon");
    if (ICONS[key] && !el.dataset.iconRendered) {
      el.innerHTML = ICONS[key];
      el.dataset.iconRendered = "1";
    }
  });
}

// ---------------------------------------------------------------------------
// Small utilities
// ---------------------------------------------------------------------------

const $ = (id) => document.getElementById(id);

/** Escape text for safe use inside HTML (element content AND quoted attributes). */
function esc(value) {
  return String(value === null || value === undefined ? "" : value)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

/** Only allow the PNG data URLs our own server produces to reach <img src>/CSS. */
function safeImageUrl(url) {
  return typeof url === "string" && url.startsWith("data:image/png;base64,") ? url : "";
}

function fmt(value, digits = 4) {
  return value === null || value === undefined || Number.isNaN(value) ? "n/a" : Number(value).toFixed(digits);
}

/** Last folder name of a checkpoint path, working with both / and \ separators. */
function runIdFromPath(path) {
  const parts = String(path || "").split(/[\\/]+/).filter(Boolean);
  return parts.length >= 2 ? parts[parts.length - 2] : String(path || "");
}

function formatMB(mb) {
  if (mb === null || mb === undefined) return null;
  return mb >= 1000 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.round(mb)} MB`;
}

function formatParams(n) {
  if (n >= 1e6) return `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)}M`;
  if (n >= 1e3) return `${Math.round(n / 1e3)}K`;
  return String(n);
}

// ---------------------------------------------------------------------------
// Announcements for screen readers + toasts for everyone
// ---------------------------------------------------------------------------

function announce(message, assertive = false) {
  const region = $(assertive ? "live-alert" : "live-status");
  if (!region) return;
  region.textContent = "";
  // Re-setting the text on the next frame makes repeat messages get re-read.
  requestAnimationFrame(() => { region.textContent = message; });
}

function toast(message, kind = "info", ms = 6000) {
  const region = $("toast-region");
  const node = document.createElement("div");
  node.className = `toast ${kind}`;
  node.textContent = message;
  region.appendChild(node);
  setTimeout(() => node.remove(), ms);
  if (kind === "error") announce(message, true);
}

// ---------------------------------------------------------------------------
// Accessible dialogs (native <dialog>: focus trap, Esc to close, restores focus)
// ---------------------------------------------------------------------------

function _openDialog(dialog, restoreFocusTo) {
  dialog._restoreFocus = restoreFocusTo || document.activeElement;
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
}

function _wireRestoreFocus(dialog) {
  dialog.addEventListener("close", () => {
    const target = dialog._restoreFocus;
    if (target && document.contains(target) && typeof target.focus === "function") target.focus();
  });
}

/**
 * Show a message / confirmation / text prompt. Resolves to:
 *   alert  -> true
 *   confirm-> true | false
 *   prompt -> the entered string, or null if cancelled
 */
function uiDialog({ title, message, confirmText = "OK", cancelText = "Cancel", danger = false, input = null, alertOnly = false }) {
  return new Promise((resolve) => {
    const dialog = $("dlg-generic");
    $("dlg-title").textContent = title;
    $("dlg-message").textContent = message || "";
    const okBtn = $("dlg-ok");
    okBtn.textContent = confirmText;
    okBtn.className = danger ? "danger-btn" : "";
    $("dlg-cancel").textContent = cancelText;
    $("dlg-cancel").classList.toggle("hidden", alertOnly);
    const row = $("dlg-input-row");
    row.classList.toggle("hidden", !input);
    if (input) {
      $("dlg-input-label").textContent = input.label;
      $("dlg-input").value = input.value || "";
    }

    let result = alertOnly ? true : (input ? null : false);
    const finish = () => {
      dialog.removeEventListener("close", finish);
      resolve(result);
    };
    dialog.addEventListener("close", finish);

    $("dlg-form").onsubmit = () => { result = input ? $("dlg-input").value.trim() : true; };
    $("dlg-cancel").onclick = () => { result = input ? null : false; dialog.close(); };

    _openDialog(dialog);
    (input ? $("dlg-input") : (danger && !alertOnly ? $("dlg-cancel") : okBtn)).focus();
    if (input) $("dlg-input").select();
  });
}

const uiAlert = (title, message) => uiDialog({ title, message, alertOnly: true });
const uiConfirm = (title, message, opts = {}) => uiDialog({ title, message, ...opts });
const uiPrompt = (title, message, label, value = "", opts = {}) => uiDialog({ title, message, input: { label, value }, ...opts });

// ---------------------------------------------------------------------------
// Talking to the local engine
// ---------------------------------------------------------------------------

class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

/**
 * fetch wrapper: always resolves to parsed JSON or throws ApiError with a
 * message that is safe to show to students. Never leaves a raw
 * "Failed to fetch" / JSON-parse error on screen.
 */
async function api(path, { method = "GET", json, form, signal } = {}) {
  const init = { method, signal };
  if (json !== undefined) {
    init.headers = { "Content-Type": "application/json" };
    init.body = JSON.stringify(json);
  } else if (form) {
    init.body = form;
  }
  let response;
  try {
    response = await fetch(path, init);
  } catch (err) {
    if (err && err.name === "AbortError") throw err;
    throw new ApiError("EdSeg's engine isn't responding. If you just started the app, wait a few seconds and try again; otherwise close and reopen EdSeg.", 0);
  }
  let data = null;
  try { data = await response.json(); } catch (_) { /* non-JSON body */ }
  if (!response.ok) {
    throw new ApiError((data && data.error) || `The engine returned an error (status ${response.status}).`, response.status);
  }
  return data;
}

// ---------------------------------------------------------------------------
// Preferences: theme + text size
// ---------------------------------------------------------------------------

const _chartRedrawCache = {};
function registerChartRedraw(canvasId, redrawFn) { _chartRedrawCache[canvasId] = redrawFn; }
function redrawAllRegisteredCharts() {
  Object.values(_chartRedrawCache).forEach((fn) => { try { fn(); } catch (_) { /* chart may not be drawable right now */ } });
}

function _store(key, value) { try { localStorage.setItem(key, value); } catch (_) { /* storage unavailable */ } }
function _load(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  $("theme-icon-sun").classList.toggle("hidden", theme === "light");
  $("theme-icon-moon").classList.toggle("hidden", theme === "dark");
  const btn = $("theme-toggle-btn");
  btn.setAttribute("aria-pressed", theme === "light" ? "true" : "false");
  btn.setAttribute("aria-label", theme === "light" ? "Light theme (switch to dark)" : "Dark theme (switch to light)");
  _store("edseg-theme", theme);
  redrawAllRegisteredCharts();
}

function initTheme() {
  let saved = _load("edseg-theme");
  if (saved !== "light" && saved !== "dark") {
    saved = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }
  applyTheme(saved);
}

function toggleTheme() {
  applyTheme((document.documentElement.getAttribute("data-theme") || "dark") === "dark" ? "light" : "dark");
}

const TEXT_SCALES = [0.875, 1, 1.125, 1.25, 1.5];
let _textScaleIndex = 1;

function applyTextScale(index) {
  _textScaleIndex = Math.max(0, Math.min(TEXT_SCALES.length - 1, index));
  document.documentElement.style.setProperty("--text-scale", String(TEXT_SCALES[_textScaleIndex]));
  $("text-smaller-btn").disabled = _textScaleIndex === 0;
  $("text-larger-btn").disabled = _textScaleIndex === TEXT_SCALES.length - 1;
  _store("edseg-text-scale", String(_textScaleIndex));
  requestAnimationFrame(redrawAllRegisteredCharts);
}

function initTextScale() {
  const saved = parseInt(_load("edseg-text-scale"), 10);
  applyTextScale(Number.isInteger(saved) ? saved : 1);
}

// ---------------------------------------------------------------------------
// Drawers for narrow windows (navigation on the left, system info on the right)
// ---------------------------------------------------------------------------

function _setDrawer(panelId, toggleId, open) {
  const panel = $(panelId), toggle = $(toggleId);
  panel.classList.toggle("open", open);
  toggle.setAttribute("aria-expanded", open ? "true" : "false");
  if (toggleId === "nav-toggle") toggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
  const anyOpen = $("sidebar-left").classList.contains("open") || $("sidebar-right").classList.contains("open");
  $("drawer-backdrop").classList.toggle("open", anyOpen);
}

function closeDrawers(returnFocus = false) {
  const leftOpen = $("sidebar-left").classList.contains("open");
  const rightOpen = $("sidebar-right").classList.contains("open");
  _setDrawer("sidebar-left", "nav-toggle", false);
  _setDrawer("sidebar-right", "info-toggle", false);
  if (returnFocus) {
    if (leftOpen) $("nav-toggle").focus();
    else if (rightOpen) $("info-toggle").focus();
  }
}

function initDrawers() {
  $("nav-toggle").addEventListener("click", () => {
    const open = !$("sidebar-left").classList.contains("open");
    _setDrawer("sidebar-left", "nav-toggle", open);
    if (open) $("sidebar-left").querySelector(".nav-item").focus();
  });
  $("info-toggle").addEventListener("click", () => {
    const open = !$("sidebar-right").classList.contains("open");
    _setDrawer("sidebar-right", "info-toggle", open);
    if (open) $("info-title").focus();
  });
  $("info-close").addEventListener("click", () => closeDrawers(true));
  $("drawer-backdrop").addEventListener("click", () => closeDrawers(true));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && ($("sidebar-left").classList.contains("open") || $("sidebar-right").classList.contains("open"))) {
      closeDrawers(true);
    }
  });
}
