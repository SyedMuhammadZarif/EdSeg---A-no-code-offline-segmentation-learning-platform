// EdSeg — advanced screens: resume, sweeps, model library, testing, gallery, compare, concepts.

/** A list card: one real button for the main action, separate buttons for extra actions (keyboard friendly). */
function buildListCard({ title, metaHtml, onMain, actions = [], selected = false, mainLabel }) {
  const card = document.createElement("div");
  card.className = "checkpoint-card" + (selected ? " selected" : "");
  const main = document.createElement("button");
  main.type = "button";
  main.className = "card-main";
  main.innerHTML = `<span class="checkpoint-title">${esc(title)}</span><span class="checkpoint-meta">${metaHtml}</span>`;
  if (mainLabel) main.setAttribute("aria-label", mainLabel);
  if (onMain) main.addEventListener("click", () => onMain(card)); else { main.disabled = true; main.style.cursor = "default"; main.style.color = "inherit"; main.style.background = "transparent"; }
  card.appendChild(main);
  if (actions.length) {
    const row = document.createElement("div");
    row.className = "card-actions";
    actions.forEach((a) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = a.danger ? "danger-btn" : "secondary-btn";
      b.textContent = a.label;
      if (a.aria) b.setAttribute("aria-label", a.aria);
      b.addEventListener("click", a.onClick);
      row.appendChild(b);
    });
    card.appendChild(row);
  }
  return card;
}

// ---------------------------------------------------------------------------
// Resume training
// ---------------------------------------------------------------------------

const resumeState = { checkpoints: [], selected: null, device: "auto" };

async function goToResumeScreen() {
  showScreen("resume");
  $("resume-config-panel").classList.add("hidden");
  const listEl = $("checkpoint-list"), empty = $("checkpoint-empty-message");
  listEl.innerHTML = "";
  listEl.setAttribute("aria-busy", "true");
  try {
    const data = await api("/api/checkpoints");
    resumeState.checkpoints = data.checkpoints;
  } catch (err) {
    listEl.removeAttribute("aria-busy");
    listEl.innerHTML = `<p class="message error">${esc(err.message)}</p>`;
    return;
  }
  listEl.removeAttribute("aria-busy");
  empty.classList.toggle("hidden", resumeState.checkpoints.length > 0);

  resumeState.checkpoints.forEach((ckpt) => {
    const card = buildListCard({
      title: `${ckpt.run_id} — epoch ${ckpt.epoch}`,
      metaHtml: `${esc(ckpt.architecture)} &middot; ${esc(ckpt.dataset_name)} (${esc(ckpt.dataset_source)}) &middot; learning rate ${esc(ckpt.learning_rate)} &middot; train loss ${esc(fmt(ckpt.latest_train_loss))}`,
      mainLabel: `Resume from ${ckpt.run_id}, epoch ${ckpt.epoch}`,
      onMain: (el) => selectCheckpointForResume(ckpt, el),
      actions: [
        { label: "View results", aria: `View results for ${ckpt.run_id}, epoch ${ckpt.epoch}`, onClick: () => goToResultsScreen(ckpt.path, goToResumeScreen, "Back to checkpoints") },
        { label: "Delete", danger: true, aria: `Delete checkpoint ${ckpt.run_id}, epoch ${ckpt.epoch}`, onClick: () => deleteCheckpoint(ckpt) },
      ],
    });
    listEl.appendChild(card);
  });
}

async function deleteCheckpoint(ckpt) {
  const ok = await uiConfirm("Delete this checkpoint?", `“${ckpt.run_id} — epoch ${ckpt.epoch}” will be removed. This cannot be undone.`, { confirmText: "Delete", danger: true });
  if (!ok) return;
  try {
    await api("/api/checkpoints/delete", { method: "POST", json: { checkpoint_path: ckpt.path } });
    if (resumeState.selected && resumeState.selected.path === ckpt.path) resumeState.selected = null;
    toast("Checkpoint deleted.", "success");
    await goToResumeScreen();
  } catch (err) {
    toast(err.message, "error");
  }
}

async function selectCheckpointForResume(ckpt, cardEl) {
  document.querySelectorAll("#checkpoint-list .checkpoint-card").forEach((c) => c.classList.remove("selected"));
  cardEl.classList.add("selected");
  resumeState.selected = ckpt;
  $("resume-checkpoint-label").textContent = `${ckpt.run_id} (epoch ${ckpt.epoch})`;

  const archSelect = $("resume-architecture-select");
  archSelect.innerHTML = "";
  state.architectures.forEach((a) => {
    const o = document.createElement("option");
    o.value = a.name; o.textContent = a.display_name;
    archSelect.appendChild(o);
  });
  archSelect.value = ckpt.architecture;

  const dsSelect = $("resume-dataset-select");
  dsSelect.innerHTML = "";
  state.datasets.forEach((ds) => {
    const o = document.createElement("option");
    o.value = JSON.stringify({ name: ds.name, source: ds.source });
    o.textContent = `${ds.display_name} (${ds.source}${ds.dim === 3 ? ", 3D" : ""})`;
    if (ds.name === ckpt.dataset_name && ds.source === ckpt.dataset_source) o.selected = true;
    dsSelect.appendChild(o);
  });

  const remaining = Math.max(0, 100 - ckpt.epoch);
  const slider = $("resume-epochs-slider");
  slider.max = Math.max(1, Math.min(20, remaining));
  slider.value = Math.min(5, slider.max);
  slider.dispatchEvent(new Event("input"));
  $("resume-ep-hint").textContent = remaining === 0
    ? "This run has already reached the 100-epoch maximum, so there is nothing left to resume."
    : `How many more full passes to run, continuing from epoch ${ckpt.epoch} (the total is capped at 100 epochs).`;
  $("start-resume-btn").disabled = remaining === 0;

  renderDeviceOptions("resume-device-options", () => resumeState.device, (k) => { resumeState.device = k; });
  $("resume-error-message").textContent = "";
  $("resume-config-panel").classList.remove("hidden");
  $("h-resume-settings").focus({ preventScroll: false });
}

async function startResumeTraining() {
  const ckpt = resumeState.selected;
  if (!ckpt) return;
  const errEl = $("resume-error-message");
  errEl.textContent = "";
  let dataset;
  try { dataset = JSON.parse($("resume-dataset-select").value); } catch (_) { errEl.textContent = "Choose a dataset."; return; }
  const extra = parseInt($("resume-epochs-slider").value, 10);
  $("start-resume-btn").disabled = true;
  try {
    const data = await api("/api/train/resume", { method: "POST", json: {
      checkpoint_path: ckpt.path, additional_epochs: extra,
      expected_architecture: $("resume-architecture-select").value,
      expected_dataset_name: dataset.name, expected_dataset_source: dataset.source,
      device_preference: resumeState.device,
    } });
    state.currentRunId = data.run_id;
    const arch = state.architectures.find((a) => a.name === ckpt.architecture);
    prepareTrainingView(extra, `Resuming from epoch ${ckpt.epoch}…`, {
      dim: ckpt.dim || 2, model: arch ? arch.display_name.replace(/\s*\(.*\)$/, "") : ckpt.architecture,
      size: ckpt.image_size, lr: ckpt.learning_rate,
    });
    beginTrainingPolling();
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    $("start-resume-btn").disabled = false;
  }
}

// ---------------------------------------------------------------------------
// Hyperparameter sweeps
// ---------------------------------------------------------------------------

const tuningState = {
  sweepableParams: {}, maxParamsToSweep: 3, maxValuesPerParam: 4, maxTotalTrials: 20, maxEpochsPerTrial: 15,
  selectedParamsOrder: [], valuesByParam: {}, device: "auto",
  currentId: null, active: false, viewingHistoricalId: null,
};
let _tuningTimer = null;

async function goToTuningSetupScreen() {
  if (!state.selectedDataset) { showScreen("dataset"); return; }
  showScreen("tuning-setup");
  $("tuning-error-message").textContent = "";
  const ds = state.selectedDataset;
  $("tuning-dataset-label").textContent = `${ds.display_name} (${ds.count} ${ds.dim === 3 ? "3D volumes" : "images"})`;

  if (!Object.keys(tuningState.sweepableParams).length) {
    try {
      const data = await api("/api/tuning/params");
      tuningState.sweepableParams = data.sweepable_params;
      tuningState.maxParamsToSweep = data.max_params_to_sweep;
      tuningState.maxValuesPerParam = data.max_values_per_param;
      tuningState.maxTotalTrials = data.max_total_trials;
      tuningState.maxEpochsPerTrial = data.max_epochs_per_trial;
    } catch (err) {
      $("tuning-error-message").textContent = err.message;
      return;
    }
  }
  tuningState.selectedParamsOrder = [];
  tuningState.valuesByParam = {};
  renderParamToggles(); renderParamValueSections(); updateTrialCountNote();

  const slider = $("tuning-epochs-slider");
  slider.max = tuningState.maxEpochsPerTrial;
  slider.value = Math.min(6, tuningState.maxEpochsPerTrial);
  const update = () => { $("tuning-epochs-value").textContent = slider.value; slider.setAttribute("aria-valuetext", `${slider.value} epochs per trial`); };
  slider.oninput = update; update();
  renderDeviceOptions("tuning-device-options", () => tuningState.device, (k) => { tuningState.device = k; });
}

function renderParamToggles() {
  const container = $("tuning-param-toggles");
  container.innerHTML = "";
  Object.entries(tuningState.sweepableParams).forEach(([key, info]) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "device-option";
    const selected = tuningState.selectedParamsOrder.includes(key);
    btn.setAttribute("aria-pressed", selected ? "true" : "false");
    btn.textContent = info.display_name;
    btn.addEventListener("click", () => {
      if (selected) {
        tuningState.selectedParamsOrder = tuningState.selectedParamsOrder.filter((k) => k !== key);
        delete tuningState.valuesByParam[key];
      } else {
        if (tuningState.selectedParamsOrder.length >= tuningState.maxParamsToSweep) {
          announce(`You can sweep at most ${tuningState.maxParamsToSweep} parameters. Deselect one first.`, true);
          toast(`You can sweep at most ${tuningState.maxParamsToSweep} parameters at once. Deselect one first.`, "info");
          return;
        }
        tuningState.selectedParamsOrder.push(key);
        tuningState.valuesByParam[key] = new Set();
      }
      renderParamToggles(); renderParamValueSections(); updateTrialCountNote();
      const again = $("tuning-param-toggles").querySelectorAll(".device-option");
      const idx = Object.keys(tuningState.sweepableParams).indexOf(key);
      if (again[idx]) again[idx].focus();
    });
    container.appendChild(btn);
  });
}

function getValueOptionsForParam(param) {
  if (param === "learning_rate") return LR_VALUES.map((v) => ({ label: String(v), value: v }));
  if (param === "batch_size") return batchValues().map((v) => ({ label: String(v), value: v }));
  if (param === "subset_size") {
    const total = state.selectedDataset ? state.selectedDataset.count : 24;
    const seen = new Set();
    return [0.25, 0.5, 0.75, 1.0].map((f) => Math.max(Math.min(4, total), Math.round(total * f)))
      .filter((v) => (seen.has(v) ? false : seen.add(v))).map((v) => ({ label: String(v), value: v }));
  }
  if (param === "architecture") return archsForCurrentDataset().map((a) => ({ label: a.display_name, value: a.name }));
  return [];
}

function renderParamValueSections() {
  const container = $("tuning-param-value-sections");
  container.innerHTML = "";
  tuningState.selectedParamsOrder.forEach((param) => {
    const block = document.createElement("fieldset");
    block.className = "param-value-block";
    const legend = document.createElement("legend");
    legend.className = "param-value-title";
    legend.textContent = `${tuningState.sweepableParams[param].display_name} — values to try (up to ${tuningState.maxValuesPerParam})`;
    block.appendChild(legend);
    const options = document.createElement("div");
    options.className = "device-options";
    const list = getValueOptionsForParam(param);
    const set = tuningState.valuesByParam[param];
    const fresh = set.size === 0;
    list.forEach((opt, i) => {
      if (fresh && i < 2) set.add(opt.value);
      const btn = document.createElement("button");
      btn.type = "button"; btn.className = "device-option";
      btn.setAttribute("aria-pressed", set.has(opt.value) ? "true" : "false");
      btn.textContent = opt.label;
      btn.addEventListener("click", () => {
        if (set.has(opt.value)) set.delete(opt.value);
        else {
          if (set.size >= tuningState.maxValuesPerParam) { toast(`At most ${tuningState.maxValuesPerParam} values per parameter.`, "info"); return; }
          set.add(opt.value);
        }
        btn.setAttribute("aria-pressed", set.has(opt.value) ? "true" : "false");
        updateTrialCountNote();
      });
      options.appendChild(btn);
    });
    block.appendChild(options);
    container.appendChild(block);
  });
}

function updateTrialCountNote() {
  const countEl = $("tuning-trial-count-note");
  const order = tuningState.selectedParamsOrder;
  if (!order.length) countEl.textContent = "Select at least one parameter to sweep.";
  else {
    const counts = order.map((p) => tuningState.valuesByParam[p].size);
    const total = counts.reduce((a, b) => a * b, 1);
    if (counts.some((c) => c === 0)) countEl.textContent = "Select at least one value for each parameter you're sweeping.";
    else if (order.length === 1) countEl.textContent = `This will run ${total} trial${total === 1 ? "" : "s"}.`;
    else countEl.textContent = `Grid search: ${counts.join(" × ")} = ${total} trials in total.` + (total > tuningState.maxTotalTrials ? ` Only the first ${tuningState.maxTotalTrials} will run.` : "");
  }
  $("tuning-caps-note").textContent = `Limits: up to ${tuningState.maxParamsToSweep} parameters, ${tuningState.maxValuesPerParam} values each, ${tuningState.maxTotalTrials} trials in total and ${tuningState.maxEpochsPerTrial} epochs per trial — kept short so a sweep finishes quickly.`;
}

async function startTuning() {
  const errEl = $("tuning-error-message");
  errEl.textContent = "";
  const order = tuningState.selectedParamsOrder;
  if (!order.length) { errEl.textContent = "Select at least one parameter to sweep."; return; }
  const sweep = order.map((param) => ({ param, values: Array.from(tuningState.valuesByParam[param]) }));
  if (sweep.some((p) => !p.values.length)) { errEl.textContent = "Select at least one value for each parameter you're sweeping."; return; }

  const hp = getHyperparams();
  $("start-tuning-btn").disabled = true;
  try {
    const data = await api("/api/tuning/start", { method: "POST", json: {
      dataset_name: state.selectedDataset.name, dataset_source: state.selectedDataset.source,
      model_name: hp.architecture, learning_rate: hp.learning_rate,
      epochs: parseInt($("tuning-epochs-slider").value, 10),
      batch_size: hp.batch_size, image_size: hp.image_size, val_split: hp.val_split, subset_size: hp.subset_size,
      device_preference: tuningState.device, sweep_params: sweep,
    } });
    tuningState.currentId = data.tuning_id;
    goToTuningResultsScreen();
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    $("start-tuning-btn").disabled = false;
  }
}

function goToTuningResultsScreen() {
  tuningState.viewingHistoricalId = null;
  showScreen("tuning-results");
  $("tuning-results-title").textContent = "Running sweep…";
  $("stop-tuning-btn").classList.remove("hidden");
  $("stop-tuning-btn").disabled = false;
  $("tuning-trials-list").innerHTML = "";
  $("tuning-progress-text").textContent = "Starting…";
  clearCanvas("tuning-bar-chart", "Sweep comparison chart: no data yet");
  $("tuning-bar-table").innerHTML = "";
  pollTuningStatus();
}

function pollTuningStatus() {
  tuningState.active = true;
  setRunningBadges();
  if (_tuningTimer) clearTimeout(_tuningTimer);
  const tick = async () => {
    if (!tuningState.currentId) return;
    try {
      const data = await api(`/api/tuning/status/${encodeURIComponent(tuningState.currentId)}`);
      renderTuningTrials(data);
      if (["completed", "stopped", "error"].includes(data.status)) {
        tuningState.active = false;
        setRunningBadges();
        $("stop-tuning-btn").classList.add("hidden");
        const titleEl = $("tuning-results-title");
        titleEl.textContent = { completed: "Sweep complete", stopped: "Sweep stopped early", error: "Sweep failed" }[data.status];
        if (data.status === "error") $("tuning-progress-text").textContent = String(data.error || "").split("\n")[0];
        announce(titleEl.textContent, data.status === "error");
        if (state.currentScreen === "tuning-results") titleEl.focus({ preventScroll: true });
        return;
      }
    } catch (err) {
      $("tuning-progress-text").textContent = `Lost contact with the engine (${err.message}) — retrying…`;
    }
    _tuningTimer = setTimeout(tick, 900);
  };
  tick();
}

function formatSweepValues(values) {
  return Object.entries(values).map(([k, v]) => `${k.replace(/_/g, " ")} = ${v}`).join(", ");
}

function returnToTuningResultsView() { showScreen("tuning-results", { focus: false }); }

async function goToSweepLibraryScreen() {
  showScreen("sweep-library");
  const listEl = $("sweep-library-list"), empty = $("sweep-library-empty-message");
  listEl.innerHTML = "";
  let data;
  try { data = await api("/api/sweeps"); } catch (err) { listEl.innerHTML = `<p class="message error">${esc(err.message)}</p>`; return; }
  empty.classList.toggle("hidden", data.sweeps.length > 0);
  data.sweeps.forEach((sweep) => {
    const when = new Date(sweep.created_at).toLocaleString();
    listEl.appendChild(buildListCard({
      title: `Sweep: ${sweep.sweep_params.join(", ")}`,
      metaHtml: `${sweep.trial_count} trial${sweep.trial_count === 1 ? "" : "s"} &middot; ${esc(sweep.status)} &middot; best validation Dice ${esc(fmt(sweep.best_val_dice))} &middot; ${esc(when)}`,
      mainLabel: `Open sweep of ${sweep.sweep_params.join(", ")} from ${when}`,
      onMain: () => viewSweepDetail(sweep.sweep_id),
      actions: [{
        label: "Delete", danger: true, aria: `Delete saved sweep of ${sweep.sweep_params.join(", ")} from ${when}`,
        onClick: async () => {
          if (!(await uiConfirm("Delete this saved sweep?", "Only the sweep grouping is removed — each trial's checkpoint is kept.", { confirmText: "Delete", danger: true }))) return;
          try { await api(`/api/sweeps/${encodeURIComponent(sweep.sweep_id)}`, { method: "DELETE" }); toast("Sweep deleted.", "success"); goToSweepLibraryScreen(); }
          catch (err) { toast(err.message, "error"); }
        },
      }],
    }));
  });
}

async function viewSweepDetail(sweepId) {
  let data;
  try { data = await api(`/api/sweeps/${encodeURIComponent(sweepId)}`); } catch (err) { toast(err.message, "error"); return; }
  tuningState.viewingHistoricalId = sweepId;
  showScreen("tuning-results");
  $("tuning-results-title").textContent = "Saved sweep";
  $("stop-tuning-btn").classList.add("hidden");
  renderTuningTrials(data);
}

function renderTuningTrials(data) {
  const done = data.trials.filter((t) => t.status === "completed").length;
  $("tuning-progress-text").textContent = `${done} of ${data.trials.length} trials completed — sweeping ${data.sweep_params.join(", ")}`;

  const listEl = $("tuning-trials-list");
  listEl.innerHTML = "";
  const completed = data.trials.filter((t) => t.status === "completed" && t.final_metrics);
  let bestIndex = null;
  if (completed.length) bestIndex = completed.reduce((a, b) => ((b.final_metrics.val_dice || 0) > (a.final_metrics.val_dice || 0) ? b : a)).trial_index;

  data.trials.forEach((trial) => {
    const status = { pending: "waiting", running: "training now", completed: "done" }[trial.status] || trial.status;
    const m = trial.final_metrics;
    const isBest = trial.trial_index === bestIndex;
    const metaHtml = trial.status === "completed" && m
      ? `Train loss ${esc(fmt(m.train_loss))} &middot; Val Dice ${esc(fmt(m.val_dice))} &middot; Val IoU ${esc(fmt(m.val_iou))}${isBest ? " &middot; <strong>Best so far</strong>" : ""}`
      : (trial.status === "running" ? `Epoch ${trial.metrics_so_far.length}…` : "");
    const actions = [];
    if (trial.status === "completed" && trial.checkpoint_path) {
      const label = formatSweepValues(trial.sweep_values);
      actions.push({
        label: "View full results", aria: `View full results for ${label}`,
        onClick: () => {
          const historical = tuningState.viewingHistoricalId;
          goToResultsScreen(trial.checkpoint_path, historical ? () => viewSweepDetail(historical) : returnToTuningResultsView, "Back to sweep");
        },
      }, {
        label: "Save as model", aria: `Save ${label} as a model`,
        onClick: async () => {
          const suggested = Object.entries(trial.sweep_values).map(([k, v]) => `${k}${v}`).join("_").replace(/[^A-Za-z0-9_-]/g, "");
          const name = await uiPrompt("Save as a model", "Give this trained model a name so you can find it in the Model Library.", "Model name", suggested, { confirmText: "Save" });
          if (!name) return;
          try { const r = await api("/api/model/save", { method: "POST", json: { checkpoint_path: trial.checkpoint_path, name } }); toast(`Saved as “${r.model.name}”.`, "success"); }
          catch (err) { toast(err.message, "error"); }
        },
      });
    }
    listEl.appendChild(buildListCard({ title: `${formatSweepValues(trial.sweep_values)} — ${status}`, metaHtml, selected: isBest, actions }));
  });

  const labels = data.trials.map((t) => Object.values(t.sweep_values).join(" / "));
  const values = data.trials.map((t) => (t.status === "completed" && t.final_metrics && t.final_metrics.val_dice != null ? t.final_metrics.val_dice : 0));
  const draw = () => drawBarChart($("tuning-bar-chart"), labels, values, { max: 1 });
  draw();
  registerChartRedraw("tuning-bar-chart", draw);
  $("tuning-bar-chart").setAttribute("aria-label", "Sweep comparison of validation Dice: " + labels.map((l, i) => `${l} ${fmt(values[i], 3)}`).join("; "));
  renderDataTable("tuning-bar-table", "Final validation Dice per trial", ["Trial", "Validation Dice"], labels.map((l, i) => [l, fmt(values[i], 4)]));
}

async function stopTuning() {
  if (!tuningState.currentId) return;
  $("stop-tuning-btn").disabled = true;
  try { await api(`/api/tuning/stop/${encodeURIComponent(tuningState.currentId)}`, { method: "POST" }); }
  catch (err) { toast(err.message, "error"); $("stop-tuning-btn").disabled = false; }
}

// ---------------------------------------------------------------------------
// Model library + testing
// ---------------------------------------------------------------------------

const testingState = { model: null, device: "auto", mode: "single", lastDataset: null, objectUrls: [] };

async function goToModelLibraryScreen() {
  showScreen("library");
  const listEl = $("model-library-list"), empty = $("model-library-empty-message");
  listEl.innerHTML = "";
  let data;
  try { data = await api("/api/models"); } catch (err) { listEl.innerHTML = `<p class="message error">${esc(err.message)}</p>`; return; }
  empty.classList.toggle("hidden", data.models.length > 0);
  data.models.forEach((model) => {
    listEl.appendChild(buildListCard({
      title: model.name,
      metaHtml: `${esc(model.architecture)} &middot; ${model.dim === 3 ? "3D" : "2D"} &middot; trained on ${esc(model.dataset_name)} (${esc(model.dataset_source)}) &middot; ${esc(model.trained_epochs)} epochs &middot; Val Dice ${esc(fmt(model.final_val_dice))} &middot; Val IoU ${esc(fmt(model.final_val_iou))}`,
      mainLabel: `Test model ${model.name}`,
      onMain: () => goToTestingScreen(model),
      actions: [{
        label: "Delete", danger: true, aria: `Delete model ${model.name}`,
        onClick: async () => {
          if (!(await uiConfirm("Delete this saved model?", `“${model.name}” will be removed from the library. This cannot be undone.`, { confirmText: "Delete", danger: true }))) return;
          try { await api(`/api/models/${encodeURIComponent(model.name)}`, { method: "DELETE" }); toast("Model deleted.", "success"); goToModelLibraryScreen(); }
          catch (err) { toast(err.message, "error"); }
        },
      }],
    }));
  });
}

function goToTestingScreen(model) {
  testingState.model = model;
  showScreen("testing");
  const is3d = model.dim === 3;
  $("testing-model-label").textContent = `${model.name} (${model.architecture}, ${is3d ? "3D" : "2D"}, trained on ${model.dataset_name})`;

  $("testing-image-file").value = ""; $("testing-mask-file").value = "";
  $("testing-image-file").accept = is3d ? ".nii,.gz,.npy" : ".png,.jpg,.jpeg";
  $("testing-mask-file").accept = is3d ? ".nii,.gz,.npy" : ".png,.jpg,.jpeg";
  $("testing-image-label").textContent = is3d ? "Volume to test (.nii, .nii.gz or .npy)" : "Image to test (.png or .jpg)";
  $("testing-error-message").textContent = "";
  ["testing-results-panel", "testing-dataset-results-panel"].forEach((id) => $(id).classList.add("hidden"));
  $("testing-results-images").innerHTML = ""; $("testing-results-metrics").innerHTML = "";

  switchTestingMode("single");
  populateTestingDatasetSelect(model.dim);
  renderDeviceOptions("testing-device-options", () => testingState.device, (k) => { testingState.device = k; });
}

function switchTestingMode(mode) {
  testingState.mode = mode;
  const single = mode === "single";
  $("testing-mode-single-btn").setAttribute("aria-pressed", single ? "true" : "false");
  $("testing-mode-dataset-btn").setAttribute("aria-pressed", single ? "false" : "true");
  $("testing-single-panel").classList.toggle("hidden", !single);
  $("testing-dataset-panel").classList.toggle("hidden", single);
  $("run-inference-btn").classList.toggle("hidden", !single);
  $("run-dataset-test-btn").classList.toggle("hidden", single);
  $("testing-error-message").textContent = "";
  $(single ? "testing-dataset-results-panel" : "testing-results-panel").classList.add("hidden");
}

async function populateTestingDatasetSelect(dim) {
  const select = $("testing-dataset-select");
  select.innerHTML = "";
  const matching = state.datasets.filter((d) => d.dim === dim);
  matching.forEach((ds) => {
    const o = document.createElement("option");
    o.value = JSON.stringify({ name: ds.name, source: ds.source });
    o.textContent = `${ds.display_name} (${ds.source}, ${ds.count} ${dim === 3 ? "volumes" : "pairs"})`;
    select.appendChild(o);
  });
  if (!matching.length) {
    const o = document.createElement("option");
    o.value = ""; o.textContent = `No ${dim === 3 ? "3D" : "2D"} datasets available`;
    select.appendChild(o);
  }
}

function setBusy(btn, busy, busyText, idleText) {
  btn.disabled = busy;
  btn.textContent = busy ? busyText : idleText;
}

async function runInference() {
  const imageInput = $("testing-image-file"), maskInput = $("testing-mask-file"), errEl = $("testing-error-message");
  errEl.textContent = "";
  if (!imageInput.files[0]) { errEl.textContent = "Please choose a file to test."; imageInput.focus(); return; }
  const form = new FormData();
  form.append("model_name", testingState.model.name);
  form.append("image", imageInput.files[0]);
  if (maskInput.files[0]) form.append("mask", maskInput.files[0]);
  form.append("device_preference", testingState.device);

  const btn = $("run-inference-btn");
  setBusy(btn, true, "Running…", "Run inference");
  try {
    const data = await api("/api/inference", { method: "POST", form });
    renderInferenceResult(data, imageInput.files[0], maskInput.files[0]);
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    setBusy(btn, false, "Running…", "Run inference");
  }
}

function renderInferenceResult(data, imageFile, maskFile) {
  const imagesEl = $("testing-results-images"), metricsEl = $("testing-results-metrics");
  testingState.objectUrls.forEach((u) => URL.revokeObjectURL(u));
  testingState.objectUrls = [];
  imagesEl.innerHTML = "";

  if (data.kind === "volume") {
    imagesEl.style.display = "block";
    imagesEl.appendChild(buildVolumeViewer(data.volume));
  } else {
    imagesEl.style.display = "";
    const imageUrl = URL.createObjectURL(imageFile);
    testingState.objectUrls.push(imageUrl);
    let html = `<figure class="preview-item"><img src="${imageUrl}" alt="Input image" /><figcaption class="preview-item-label">Input image</figcaption></figure>`;
    if (maskFile) {
      const maskUrl = URL.createObjectURL(maskFile);
      testingState.objectUrls.push(maskUrl);
      html += `<figure class="preview-item"><img src="${maskUrl}" alt="Ground truth mask" /><figcaption class="preview-item-label">Ground truth</figcaption></figure>`;
    }
    html += `<figure class="preview-item"><img src="${safeImageUrl(data.predicted_mask)}" alt="Predicted mask" /><figcaption class="preview-item-label">Predicted mask</figcaption></figure>`;
    imagesEl.innerHTML = html;
  }

  const cards = [{ label: "Device used", text: data.device_used }];
  if (data.dice !== undefined) cards.push({ label: "Dice (this case)", value: data.dice }, { label: "IoU (this case)", value: data.iou });
  metricsEl.innerHTML = summaryCardsHtml(cards);
  $("testing-results-panel").classList.remove("hidden");
  $("h-test-result").focus({ preventScroll: false });
  announce(data.dice !== undefined ? `Inference finished. Dice ${fmt(data.dice, 3)}, IoU ${fmt(data.iou, 3)}.` : "Inference finished. Prediction shown.");
}

async function runDatasetTest() {
  const select = $("testing-dataset-select"), errEl = $("testing-error-message");
  errEl.textContent = "";
  if (!select.value) { errEl.textContent = "Please choose a dataset to test against."; select.focus(); return; }
  const { name, source } = JSON.parse(select.value);
  const btn = $("run-dataset-test-btn");
  setBusy(btn, true, "Running… this can take a while for larger datasets", "Run full dataset test");
  try {
    const data = await api("/api/inference/dataset", { method: "POST", json: {
      model_name: testingState.model.name, dataset_name: name, dataset_source: source, device_preference: testingState.device } });
    testingState.lastDataset = data;
    renderDatasetTestResults(data);
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    setBusy(btn, false, "", "Run full dataset test");
  }
}

function renderDatasetTestResults(data) {
  $("testing-dataset-results-panel").classList.remove("hidden");
  $("testing-dataset-results-summary").textContent =
    `Tested on all ${data.total_images_tested} ${data.dim === 3 ? "volumes" : "image/mask pairs"} in ${data.dataset_name} (${data.dataset_source}), using ${data.device_used}.`;
  const cm = data.confusion_matrix;
  $("testing-dataset-results-metrics").innerHTML = summaryCardsHtml([
    { label: "Dice", value: cm.dice }, { label: "IoU", value: cm.iou }, { label: "Precision", value: cm.precision },
    { label: "Recall", value: cm.recall }, { label: "Accuracy", value: cm.accuracy },
  ]);
  $("testing-dataset-confusion-matrix").innerHTML = buildConfusionMatrixHtml(cm, `across all ${data.total_images_tested} test cases`, data.dim === 3 ? "voxels" : "pixels");
  $("h-test-dataset-result").focus({ preventScroll: false });
  announce(`Full dataset test finished. Dice ${fmt(cm.dice, 3)}.`);
}

// ---------------------------------------------------------------------------
// Prediction gallery
// ---------------------------------------------------------------------------

let _galleryBack = null;

function viewPredictionGallery(title, subtitle, predictions, back) {
  _galleryBack = back;
  showScreen("gallery");
  $("prediction-gallery-title").textContent = title;
  $("prediction-gallery-subtitle").textContent = subtitle;
  fillPredictionGrid("prediction-gallery-grid", predictions);
}

async function viewAllPredictionsFromResults() {
  const path = state.currentResultsCheckpointPath || state.lastCheckpointPath;
  if (!path) return;
  const btn = $("view-all-predictions-btn");
  setBusy(btn, true, "Loading…", "View all test predictions");
  try {
    const data = await api(`/api/results/all_predictions?checkpoint_path=${encodeURIComponent(path)}`);
    viewPredictionGallery("All validation predictions",
      `${data.total_count} prediction${data.total_count === 1 ? "" : "s"} from this run's validation set.`,
      data.predictions, () => showScreen("results"));
  } catch (err) {
    toast(err.message, "error");
  } finally {
    setBusy(btn, false, "", "View all test predictions");
  }
}

function viewAllPredictionsFromDatasetTest() {
  const data = testingState.lastDataset;
  if (!data) return;
  viewPredictionGallery("All test predictions",
    `${data.gallery_images_included} of ${data.total_images_tested} case${data.total_images_tested === 1 ? "" : "s"} from ${data.dataset_name} (${data.dataset_source}).`,
    data.predictions, () => showScreen("testing"));
}

// ---------------------------------------------------------------------------
// Compare runs
// ---------------------------------------------------------------------------

async function goToCompareScreen() {
  showScreen("compare");
  ["compare-results-panel", "compare-loss-panel", "compare-bar-panel"].forEach((id) => $(id).classList.add("hidden"));
  $("compare-error-message").textContent = "";
  const a = $("compare-select-a"), b = $("compare-select-b");
  [a, b].forEach((s) => { s.innerHTML = ""; });
  let data;
  try { data = await api("/api/checkpoints"); } catch (err) { $("compare-error-message").textContent = err.message; return; }
  data.checkpoints.forEach((c) => {
    [a, b].forEach((s) => {
      const o = document.createElement("option");
      o.value = c.path; o.textContent = `${c.run_id} — epoch ${c.epoch} (${c.architecture})`;
      s.appendChild(o);
    });
  });
  const enough = data.checkpoints.length >= 2;
  $("compare-empty-message").classList.toggle("hidden", enough);
  $("run-compare-btn").disabled = !enough;
  if (enough) b.selectedIndex = 1;
}

async function runComparison() {
  const pathA = $("compare-select-a").value, pathB = $("compare-select-b").value, errEl = $("compare-error-message");
  errEl.textContent = "";
  if (!pathA || !pathB) { errEl.textContent = "Both Run A and Run B need a checkpoint selected."; return; }
  if (pathA === pathB) { errEl.textContent = "Select two different checkpoints to compare."; return; }
  const btn = $("run-compare-btn");
  setBusy(btn, true, "Comparing…", "Compare");
  try {
    const [dataA, dataB] = await Promise.all([
      api(`/api/results?checkpoint_path=${encodeURIComponent(pathA)}`),
      api(`/api/results?checkpoint_path=${encodeURIComponent(pathB)}`),
    ]);
    renderComparison(dataA, dataB);
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    setBusy(btn, false, "", "Compare");
  }
}

function renderComparisonSummary(containerId, labelId, data) {
  $(labelId).textContent = `${runIdFromPath(data.checkpoint_path)} (epoch ${data.epoch})`;
  const last = data.metrics_history[data.metrics_history.length - 1] || {};
  const cm = data.confusion_matrix;
  $(containerId).innerHTML = summaryCardsHtml([
    { label: "Train loss", value: last.train_loss }, { label: "Val loss", value: last.val_loss },
    { label: "Dice", value: cm.dice }, { label: "IoU", value: cm.iou },
  ]);
}

function renderComparison(dataA, dataB) {
  ["compare-results-panel", "compare-loss-panel", "compare-bar-panel"].forEach((id) => $(id).classList.remove("hidden"));
  renderComparisonSummary("compare-summary-a", "compare-label-a", dataA);
  renderComparisonSummary("compare-summary-b", "compare-label-b", dataB);
  $("h-compare-summary").focus({ preventScroll: false });

  const lossA = dataA.metrics_history.map((m) => m.train_loss), lossB = dataB.metrics_history.map((m) => m.train_loss);
  const drawLoss = () => drawLineChart($("compare-loss-chart"), [
    { label: "Run A train loss", color: chartPalette()[0], dash: [], marker: "circle", values: lossA },
    { label: "Run B train loss", color: chartPalette()[1], dash: [7, 4], marker: "square", values: lossB },
  ]);
  drawLoss(); registerChartRedraw("compare-loss-chart", drawLoss);
  const rows = Math.max(lossA.length, lossB.length);
  $("compare-loss-chart").setAttribute("aria-label", `Training loss for Run A (final ${fmt(lossA[lossA.length - 1])}) and Run B (final ${fmt(lossB[lossB.length - 1])}) over their epochs. A table follows.`);
  renderDataTable("compare-loss-table", "Train loss per epoch", ["Epoch", "Run A", "Run B"],
    Array.from({ length: rows }, (_, i) => [i + 1, fmt(lossA[i]), fmt(lossB[i])]));

  const labels = ["Precision", "Recall", "Dice", "IoU", "Accuracy"];
  const pick = (cm) => [cm.precision, cm.recall, cm.dice, cm.iou, cm.accuracy];
  const vA = pick(dataA.confusion_matrix), vB = pick(dataB.confusion_matrix);
  const drawBars = () => drawGroupedBarChart($("compare-bar-chart"), labels, vA, vB, "Run A", "Run B", { max: 1 });
  drawBars(); registerChartRedraw("compare-bar-chart", drawBars);
  $("compare-bar-chart").setAttribute("aria-label", "Metric comparison. " + labels.map((l, i) => `${l}: Run A ${fmt(vA[i], 2)}, Run B ${fmt(vB[i], 2)}`).join("; "));
  renderDataTable("compare-bar-table", "Metrics for both runs", ["Metric", "Run A", "Run B"], labels.map((l, i) => [l, fmt(vA[i], 4), fmt(vB[i], 4)]));
}

// ---------------------------------------------------------------------------
// Concepts
// ---------------------------------------------------------------------------

const CONCEPTS = [
  ["What is deep learning?", "A way of teaching a computer to perform a task by showing it many examples, rather than programming explicit rules. The computer adjusts millions of internal numbers (parameters) until its predictions match the examples well, then applies what it learned to new, unseen data."],
  ["What is image segmentation?", "Labeling every individual pixel in an image as belonging to a category (for example \"this pixel is part of the object\" vs \"this pixel is background\"), producing a mask that outlines exactly where something is — more detailed than just saying an object is somewhere in the image."],
  ["What is 3D (volumetric) segmentation?", "The same idea applied to a whole scan at once. CT and MRI scans are stacks of slices — a 3D volume — and each tiny cube of the volume is called a voxel (a 3D pixel). A 3D model labels every voxel, so it can use information from neighbouring slices instead of judging each slice alone. The price is much more memory and computation, which is why EdSeg resizes volumes to a small cube and uses compact models."],
  ["What is a voxel?", "A voxel is a pixel with depth: the smallest cube of a 3D scan. A volume that is 64×64×64 has 262,144 voxels — 64 times as many values as a 64×64 picture, which is why 3D training is so much heavier."],
  ["What is a loss function?", "A single number that measures how wrong the model's current predictions are, calculated by comparing predictions to the correct answers. Training works by repeatedly adjusting the model to make this number smaller."],
  ["What is learning rate?", "How big a step the model takes each time it adjusts itself to reduce the loss. Too high and it can overshoot and never settle down (unstable training); too low and it takes a very long time to improve."],
  ["What is an epoch?", "One complete pass through the entire training dataset. Training usually runs for many epochs, since a single pass isn't enough for the model to learn well."],
  ["What is batch size?", "How many images (or volumes) the model looks at together before it updates itself once. Larger batches give a more stable, averaged-out update; smaller batches update more often but with noisier information."],
  ["What is overfitting?", "When a model starts memorizing the specific training images instead of learning general patterns. You can spot it when training loss keeps improving but validation loss (on images the model wasn't trained on) starts getting worse."],
  ["What is early stopping?", "A way to automatically stop training once validation loss stops improving for a set number of epochs (the \"patience\"), instead of always running the full requested epoch count. This saves time and helps avoid overfitting — the best-performing snapshot is what gets saved, not whatever epoch training happened to reach when it stopped."],
  ["What is a validation split?", "A portion of the dataset deliberately held back from training, used only to check how well the model performs on data it hasn't memorized — a fair test of real learning."],
  ["What is the Dice score?", "A measure of how much the predicted mask overlaps the correct mask, from 0 (no overlap) to 1 (perfect match). It counts the overlap twice relative to the combined size of both masks, which makes it forgiving of small mismatches on small objects."],
  ["What is IoU (Intersection over Union)?", "Similar to Dice — it measures overlap between predicted and correct masks from 0 to 1 — but computed as the overlapping area divided by the total area covered by either mask. IoU is always a little stricter (lower or equal) than Dice for the same prediction."],
  ["What is a confusion matrix?", "A table breaking down every pixel's prediction into four outcomes: True Positive (correctly found foreground), True Negative (correctly found background), False Positive (wrongly predicted foreground), and False Negative (missed real foreground). Precision, recall, Dice, and IoU are all calculated from these four numbers."],
  ["What makes a model \"lightweight\"?", "A lightweight model has few parameters and needs few calculations, so it trains quickly on an ordinary laptop and can run on modest hardware. Tricks include depth-wise separable convolutions (Mobile U-Net), adding instead of concatenating features (LinkNet-Lite), narrow channel widths, and replacing heavy attention with linear-time state-space layers (Light-VM-UNet). Smaller models can match bigger ones on small datasets — and overfit less."],
  ["What are skip connections, and what is attention?", "Skip connections copy detailed early features across to the decoder so fine edges aren't lost (compare the Simple CNN, which has none, against the U-Nets). Attention gates add a learned filter on those skips so the model can focus on the relevant region, as in the Attention U-Net and the 3D GMANet-style model."],
  ["What is a state-space (Mamba) model?", "A way to read a long sequence — here, an image or volume flattened into a line of pixels — while keeping a compact running memory. Unlike attention, whose cost grows with the square of the sequence length, it grows only linearly, which makes it attractive for big 3D scans. Light-VM-UNet swaps its convolution blocks for these layers. EdSeg's versions are written in plain PyTorch so they run on any CPU."],
  ["CPU vs GPU — what's the difference?", "Both can run the same calculations, but a GPU (Graphics Processing Unit) is built to do many simple calculations in parallel, which happens to be exactly what training a neural network needs — so it's often dramatically faster than a CPU, especially for large models and 3D volumes. The CPU-only EdSeg build works everywhere; the CUDA build adds NVIDIA GPU support but is several times larger to download and store."],
  ["What is a checkpoint?", "A saved snapshot of a model's exact state partway through training (its learned values, plus the settings used), so training can be paused and resumed later from exactly that point instead of starting over."],
  ["What is hyperparameter tuning?", "Systematically trying different settings (like learning rate or batch size) to see which produces the best result, rather than guessing one configuration and hoping it's good."],
];

function initConceptsDialog() {
  const accordion = $("concepts-accordion");
  accordion.innerHTML = "";
  CONCEPTS.forEach(([question, answer], i) => {
    const item = document.createElement("div");
    item.className = "concept-item";
    const h = document.createElement("h3");
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "concept-question";
    btn.setAttribute("aria-expanded", "false"); btn.setAttribute("aria-controls", `concept-answer-${i}`);
    btn.innerHTML = `<span>${esc(question)}</span><span class="concept-arrow" aria-hidden="true">&#9656;</span>`;
    const panel = document.createElement("div");
    panel.className = "concept-answer hidden"; panel.id = `concept-answer-${i}`;
    panel.setAttribute("role", "region"); panel.setAttribute("aria-label", question);
    panel.textContent = answer;
    btn.addEventListener("click", () => {
      const open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", open ? "false" : "true");
      panel.classList.toggle("hidden", open);
    });
    h.appendChild(btn); item.append(h, panel); accordion.appendChild(item);
  });
}

function openConceptsDialog() { _openDialog($("dlg-concepts")); $("close-concepts-btn").focus(); }
