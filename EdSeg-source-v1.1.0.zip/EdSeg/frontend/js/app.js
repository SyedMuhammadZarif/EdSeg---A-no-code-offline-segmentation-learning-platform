// EdSeg — shared state, screen navigation and the status sidebar.

const LR_VALUES = [0.0001, 0.0005, 0.001, 0.005, 0.01];
const BATCH_VALUES_2D = [2, 4, 8, 16, 32];
const BATCH_VALUES_3D = [1, 2, 3, 4, 6]; // volumes are big; small batches keep memory modest

const state = {
  datasets: [],
  selectedDataset: null,        // { name, source, count, kind, dim, display_name }
  architectures: [],
  devices: {},
  build: null,
  selectedDevice: "auto",
  currentRunId: null,
  trainingActive: false,
  totalEpochs: null,
  lossHistory: [],
  metricHistory: [],
  lastCheckpointPath: null,
  currentResultsCheckpointPath: null,
  resultsBackAction: null,
  currentScreen: null,
};

const SCREENS = {
  dataset: { id: "screen-dataset", title: "Choose a dataset", nav: "dataset", step: 1 },
  setup: { id: "screen-setup", title: "Model setup", nav: "setup", step: 2 },
  train: { id: "screen-train", title: "Training", nav: "train", step: 3 },
  results: { id: "screen-results", title: "Results", nav: "results", step: null },
  resume: { id: "screen-resume", title: "Resume training", nav: "resume", step: null },
  "tuning-setup": { id: "screen-tuning-setup", title: "Hyperparameter sweep", nav: "tuning", step: null },
  "tuning-results": { id: "screen-tuning-results", title: "Sweep results", nav: "tuning", step: null },
  "sweep-library": { id: "screen-sweep-library", title: "Saved sweeps", nav: "tuning", step: null },
  library: { id: "screen-library", title: "Saved models", nav: "library", step: null },
  testing: { id: "screen-testing", title: "Test a saved model", nav: "library", step: null },
  gallery: { id: "screen-gallery", title: "All test predictions", nav: null, step: null },
  compare: { id: "screen-compare", title: "Compare runs", nav: "compare", step: null },
};

let _firstScreenShown = false;

/**
 * Show exactly one screen. Moves keyboard focus to the screen's heading (so
 * screen-reader and keyboard users land at the top of the new content), updates
 * the window title and the "current page" marker in the navigation.
 */
function showScreen(key, { focus = true } = {}) {
  const screen = SCREENS[key];
  Object.values(SCREENS).forEach((s) => $(s.id).classList.add("hidden"));
  const section = $(screen.id);
  section.classList.remove("hidden");
  state.currentScreen = key;

  document.querySelectorAll(".nav-item").forEach((item) => {
    if (item.dataset.nav === screen.nav) item.setAttribute("aria-current", "page");
    else item.removeAttribute("aria-current");
  });
  updateSteps(screen.step);
  closeDrawers();
  document.title = `${screen.title} — EdSeg`;
  window.scrollTo(0, 0);

  if (focus && _firstScreenShown) {
    const heading = section.querySelector("h2[tabindex='-1']");
    if (heading) heading.focus({ preventScroll: true });
  }
  _firstScreenShown = true;
  if (typeof trainViz !== "undefined") trainViz.onScreenChange(key === "train");
  requestAnimationFrame(redrawAllRegisteredCharts);
}

function updateSteps(step) {
  const list = $("steps-indicator");
  list.classList.toggle("hidden", !step);
  list.querySelectorAll(".step-dot").forEach((dot) => {
    const n = parseInt(dot.dataset.step, 10);
    const base = dot.dataset.label || (dot.dataset.label = dot.textContent.trim());
    dot.classList.toggle("done", !!step && n < step);
    dot.textContent = base;
    if (step && n < step) {
      const sr = document.createElement("span");
      sr.className = "sr-only"; sr.textContent = " (completed)";
      dot.appendChild(sr);
    }
    if (step && n === step) dot.setAttribute("aria-current", "step");
    else dot.removeAttribute("aria-current");
  });
}

function handleSidebarNav(navKey) {
  switch (navKey) {
    case "dataset": showScreen("dataset"); break;
    case "setup":
      if (state.selectedDataset) goToSetup();
      else { showScreen("dataset"); toast("Choose a dataset first, then continue to Model Setup.", "info"); }
      break;
    case "train":
      if (state.currentRunId) showScreen("train");
      else {
        toast("No training run yet. Set one up from Model Setup.", "info");
        if (state.selectedDataset) goToSetup(); else showScreen("dataset");
      }
      break;
    case "results":
      if (state.trainingActive) { toast("Training is still running — results are available when it finishes.", "info"); showScreen("train"); }
      else if (state.lastCheckpointPath) goToResultsScreen(state.lastCheckpointPath, () => showScreen("dataset"), "Back to Dataset");
      else { toast("Train a model first to see its results.", "info"); showScreen("dataset"); }
      break;
    case "resume": goToResumeScreen(); break;
    case "tuning":
      if (state.selectedDataset) goToTuningSetupScreen();
      else { showScreen("dataset"); toast("Choose a dataset first, then you can run a sweep.", "info"); }
      break;
    case "library": goToModelLibraryScreen(); break;
    case "compare": goToCompareScreen(); break;
    case "concepts": openConceptsDialog(); break;
  }
}

// ---------------------------------------------------------------------------
// Status sidebar
// ---------------------------------------------------------------------------

function renderStatus(ok, message) {
  $("quick-status-dot").className = "status-dot " + (ok ? "status-dot-ok" : "status-dot-error");
  $("quick-status-text").textContent = ok ? "Engine online" : "Engine not responding";
  $("quick-status-sub").textContent = ok ? "Everything runs on this computer" : (message || "Close and reopen EdSeg");
  $("topbar-status-dot").className = "status-dot " + (ok ? "status-dot-ok" : "status-dot-error");
  $("topbar-status-text").textContent = ok ? "Engine online" : "Engine offline";
}

async function checkBackendConnection() {
  try {
    await api("/api/ping");
    renderStatus(true);
    return true;
  } catch (err) {
    renderStatus(false, err.message);
    return false;
  }
}

function renderSidebarDatasetInfo(meta, previewPairs) {
  const thumbs = (previewPairs || []).slice(0, 3)
    .map((p) => `<img src="${safeImageUrl(p.image)}" alt="" />`).join("");
  $("sidebar-dataset-info").innerHTML = `
    <div class="info-row"><span class="info-row-label">Name</span><span class="info-row-value">${esc(meta.display_name || meta.name)}</span></div>
    <div class="info-row"><span class="info-row-label">Type</span><span class="info-row-value">${meta.dim === 3 ? "3D volumes" : "2D images"}</span></div>
    <div class="info-row"><span class="info-row-label">Source</span><span class="info-row-value">${esc(meta.source)}</span></div>
    <div class="info-row"><span class="info-row-label">${meta.dim === 3 ? "Volumes" : "Image pairs"}</span><span class="info-row-value">${esc(meta.count)}</span></div>
    ${thumbs ? `<div class="sidebar-dataset-thumbs">${thumbs}</div>` : ""}`;
}

function renderSidebarArchitectures() {
  const container = $("sidebar-architectures-list");
  if (!state.architectures.length) { container.innerHTML = ""; return; }
  const group = (title, dim) => {
    const items = state.architectures.filter((a) => a.dim === dim);
    return `<p class="info-group-title">${title} (${items.length})</p><ul class="info-list">` +
      items.map((a) => `<li class="info-list-item"><span class="info-list-item-name">${esc(a.display_name.replace(/\s*\(.*\)$/, ""))}</span><span class="badge badge-muted">${esc(formatParams(a.parameters))}</span></li>`).join("") + "</ul>";
  };
  container.innerHTML = group("2D image models", 2) + group("3D volume models", 3);
}

function renderSidebarDevices() {
  const devices = state.devices;
  if (!devices || !Object.keys(devices).length) return;
  const rows = [
    { key: "cpu", label: "CPU" },
    { key: "cuda", label: "NVIDIA GPU (CUDA)" },
    { key: "mps", label: "Apple Silicon GPU (MPS)" },
  ];
  $("sidebar-devices-list").innerHTML = rows.map((r) => {
    const ok = !!devices[r.key];
    return `<li class="info-list-item"><span class="info-list-item-name">${r.label}</span><span class="badge ${ok ? "badge-success" : "badge-muted"}">${ok ? "Available" : "Not available"}</span></li>`;
  }).join("");
}

/**
 * "About this build": which flavour is running and what the other flavour
 * would cost in disk space. The sizes come from build_info.json, which the
 * build script writes after measuring the real folders.
 */
function renderBuildInfo() {
  const b = state.build;
  const body = $("build-info-body");
  if (!b) { body.innerHTML = '<p class="hint" style="margin:0;">Build details unavailable.</p>'; return; }

  const s = b.sizes_mb || {};
  const est = new Set(b.sizes_estimated || []);
  const size = (key) => (s[key] ? `${est.has(key) ? "≈ " : ""}${formatMB(s[key])}` : "n/a");
  const row = (name, folderKey, zipKey, here) =>
    `<tr><th scope="row">${name}${here ? ' <span class="badge">this build</span>' : ""}</th><td>${esc(size(folderKey))}</td><td>${esc(size(zipKey))}</td></tr>`;
  const isCuda = b.flavor === "cuda";
  const anyEstimate = est.size > 0;
  const sizeTable = (s.cpu_folder || s.cuda_folder)
    ? `<table class="size-table"><caption class="sr-only">Size of each EdSeg build</caption>
         <thead><tr><th scope="col">Build</th><th scope="col">On disk</th><th scope="col">Download (zip)</th></tr></thead>
         <tbody>${row("CPU-only", "cpu_folder", "cpu_zip", !isCuda)}${row("CUDA + CPU", "cuda_folder", "cuda_zip", isCuda)}</tbody></table>
       <p class="info-sub">${anyEstimate ? "Figures marked ≈ are estimates for the build you are not running; the other is measured. " : ""}The CUDA build is larger because it bundles NVIDIA's GPU libraries.</p>`
    : '<p class="info-sub">Build sizes are recorded when the desktop app is built. Typically the CPU-only build is under 1 GB and the CUDA build several gigabytes.</p>';

  body.innerHTML = `
    <p style="margin:0 0 0.5rem; font-size:0.8125rem;"><span class="badge ${isCuda ? "badge-success" : ""}">${isCuda ? "CUDA + CPU build" : "CPU-only build"}</span></p>
    <p class="hint" style="margin:0 0 0.5rem;">${esc(b.headline)}</p>
    <div class="info-row"><span class="info-row-label">PyTorch</span><span class="info-row-value">${esc(b.torch_version)}${b.cuda_runtime ? " (CUDA " + esc(b.cuda_runtime) + ")" : ""}</span></div>
    <div class="info-row"><span class="info-row-label">GPU</span><span class="info-row-value">${esc(b.gpu_name || "none in use")}</span></div>
    <div class="info-row"><span class="info-row-label">Version</span><span class="info-row-value">${esc(b.app_version)}</span></div>
    ${sizeTable}`;
}

function setRunningBadges() {
  $("nav-train-badge").classList.toggle("hidden", !state.trainingActive);
  $("nav-tuning-badge").classList.toggle("hidden", !tuningState.active);
}
