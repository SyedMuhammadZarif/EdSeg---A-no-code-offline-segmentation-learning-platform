// EdSeg — prediction cards for 2D images and the slice viewer for 3D volumes.
//
// A 3D volume arrives as three "montage" PNGs (image / ground truth /
// prediction) with every slice tiled in a grid. The viewer shows one tile at a
// time by moving the background, so scrubbing through slices is instant and
// needs no further requests. The slider, the previous/next buttons and the
// arrow keys all work, and the current slice is exposed to screen readers.

function buildSliceTile(label, url, sample) {
  const figure = document.createElement("figure");
  figure.className = "slice-tile";
  const img = document.createElement("div");
  img.className = "tile-img";
  img.setAttribute("role", "img");
  img.style.backgroundImage = url ? `url("${url}")` : "none";
  img.style.backgroundSize = `${sample.cols * 100}% ${sample.rows * 100}%`;
  img.style.aspectRatio = `${sample.tile_width} / ${sample.tile_height}`;
  img.style.height = "auto";
  const caption = document.createElement("figcaption");
  caption.textContent = label;
  figure.appendChild(img);
  figure.appendChild(caption);
  return { figure, img, label };
}

function buildVolumeViewer(sample) {
  const root = document.createElement("div");
  root.className = "sample-prediction-card slice-viewer";

  if (sample.filename) {
    const title = document.createElement("div");
    title.className = "slice-title";
    title.textContent = sample.filename;
    root.appendChild(title);
  }

  const tiles = document.createElement("div");
  tiles.className = "slice-tiles";
  const parts = [
    buildSliceTile("Image", safeImageUrl(sample.image), sample),
    buildSliceTile("Ground truth", safeImageUrl(sample.ground_truth), sample),
    buildSliceTile("Prediction", safeImageUrl(sample.prediction), sample),
  ];
  parts.forEach((p) => tiles.appendChild(p.figure));
  root.appendChild(tiles);

  const controls = document.createElement("div");
  controls.className = "slice-controls";
  const prev = document.createElement("button");
  prev.type = "button"; prev.className = "secondary-btn"; prev.textContent = "‹";
  prev.setAttribute("aria-label", "Previous slice");
  const slider = document.createElement("input");
  slider.type = "range"; slider.min = "1"; slider.max = String(sample.depth); slider.step = "1";
  slider.setAttribute("aria-label", `Slice position, 1 to ${sample.depth}`);
  const next = document.createElement("button");
  next.type = "button"; next.className = "secondary-btn"; next.textContent = "›";
  next.setAttribute("aria-label", "Next slice");
  const readout = document.createElement("span");
  readout.className = "slice-readout";
  controls.append(prev, slider, next, readout);
  root.appendChild(controls);

  const show = (zeroBased) => {
    const k = Math.max(0, Math.min(sample.depth - 1, zeroBased));
    const col = k % sample.cols, row = Math.floor(k / sample.cols);
    const px = sample.cols > 1 ? (col / (sample.cols - 1)) * 100 : 0;
    const py = sample.rows > 1 ? (row / (sample.rows - 1)) * 100 : 0;
    parts.forEach((p) => {
      p.img.style.backgroundPosition = `${px}% ${py}%`;
      p.img.setAttribute("aria-label", `${p.label}, slice ${k + 1} of ${sample.depth}`);
    });
    slider.value = String(k + 1);
    slider.setAttribute("aria-valuetext", `Slice ${k + 1} of ${sample.depth}`);
    readout.textContent = `Slice ${k + 1} / ${sample.depth}`;
    prev.disabled = k === 0;
    next.disabled = k === sample.depth - 1;
    root._current = k;
  };
  slider.addEventListener("input", () => show(parseInt(slider.value, 10) - 1));
  prev.addEventListener("click", () => show(root._current - 1));
  next.addEventListener("click", () => show(root._current + 1));
  show(Math.max(0, Math.min(sample.depth - 1, sample.default_slice || Math.floor(sample.depth / 2))));
  return root;
}

function buildImageTriple(sample) {
  const card = document.createElement("div");
  card.className = "sample-prediction-card";
  const label = sample.filename ? esc(sample.filename) : "Image";
  card.innerHTML = `
    <div class="sample-prediction-images">
      <figure class="sample-prediction-item"><img src="${safeImageUrl(sample.image)}" alt="Input image${sample.filename ? ": " + esc(sample.filename) : ""}" /><figcaption class="sample-prediction-label">${label}</figcaption></figure>
      <figure class="sample-prediction-item"><img src="${safeImageUrl(sample.ground_truth)}" alt="Ground truth mask" /><figcaption class="sample-prediction-label">Ground truth</figcaption></figure>
      <figure class="sample-prediction-item"><img src="${safeImageUrl(sample.prediction)}" alt="Predicted mask" /><figcaption class="sample-prediction-label">Prediction</figcaption></figure>
    </div>`;
  return card;
}

/** One prediction (2D image triple or 3D volume viewer) as a DOM element. */
function buildPredictionCard(sample) {
  return sample.kind === "volume" ? buildVolumeViewer(sample) : buildImageTriple(sample);
}

function fillPredictionGrid(gridId, samples) {
  const grid = $(gridId);
  grid.innerHTML = "";
  if (!samples || !samples.length) {
    grid.innerHTML = '<p class="hint">No predictions to show.</p>';
    return;
  }
  samples.forEach((s) => grid.appendChild(buildPredictionCard(s)));
}
