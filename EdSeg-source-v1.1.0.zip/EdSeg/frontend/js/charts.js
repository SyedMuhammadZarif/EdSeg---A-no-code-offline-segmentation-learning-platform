// EdSeg — dependency-free canvas charts.
//
// Accessibility: every chart sets role="img" with a text summary on its
// canvas and offers the same numbers as a real HTML table (renderDataTable).
// Series differ by line style and marker shape, not only by colour.
// Sharpness: canvases are scaled by devicePixelRatio, and text size follows
// the app's text-size setting.

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function _basePx() {
  return parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
}

/** Size the canvas backing store to its on-screen size; returns a ready 2D context in CSS pixels. */
function prepareCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  if (rect.width < 10 || rect.height < 10) return null; // hidden or not laid out yet
  const dpr = window.devicePixelRatio || 1;
  const w = Math.round(rect.width), h = Math.round(rect.height);
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
}

function clearCanvas(canvasId, label) {
  const canvas = $(canvasId);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  canvas.setAttribute("aria-label", label || "Chart: no data yet");
}

function chartPalette() {
  return [cssVar("--chart-1"), cssVar("--chart-2"), cssVar("--chart-3"), cssVar("--chart-4"), cssVar("--chart-5")];
}

function _drawMarker(ctx, shape, x, y, r) {
  ctx.beginPath();
  if (shape === "square") ctx.rect(x - r, y - r, 2 * r, 2 * r);
  else if (shape === "triangle") { ctx.moveTo(x, y - r - 1); ctx.lineTo(x + r + 1, y + r); ctx.lineTo(x - r - 1, y + r); ctx.closePath(); }
  else ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * series: [{label, color, dash:[...], marker:'circle'|'square'|'triangle', values:[...]}]
 * x axis = epoch number (1-based). Null/undefined values are skipped.
 */
function drawLineChart(canvas, series, { yMin, yMax, yFormat = (v) => v.toFixed(2), xLabel = "Epoch" } = {}) {
  const prepared = prepareCanvas(canvas);
  if (!prepared) return;
  const { ctx, w, h } = prepared;
  const base = _basePx();
  const font = `${Math.round(base * 0.78)}px sans-serif`;
  const textColor = cssVar("--text"), muted = cssVar("--text-muted");
  const axis = cssVar("--chart-axis"), grid = cssVar("--chart-grid");

  const values = series.flatMap((s) => s.values.filter((v) => v !== null && v !== undefined));
  if (!values.length) return;
  const count = Math.max(...series.map((s) => s.values.length));

  let lo = yMin !== undefined ? yMin : Math.min(...values);
  let hi = yMax !== undefined ? yMax : Math.max(...values);
  if (hi - lo < 1e-9) { lo -= 0.1; hi += 0.1; }
  if (yMin === undefined) lo -= (hi - lo) * 0.08;
  if (yMax === undefined) hi += (hi - lo) * 0.08;

  ctx.font = font;
  const labelWidth = Math.max(...[lo, hi].map((v) => ctx.measureText(yFormat(v)).width)) + 8;
  const pad = { left: Math.max(44, labelWidth + 10), right: 14, top: Math.round(base * 2.1), bottom: Math.round(base * 2.2) };
  const plotW = w - pad.left - pad.right, plotH = h - pad.top - pad.bottom;
  const xFor = (i) => pad.left + (count <= 1 ? plotW / 2 : (i / (count - 1)) * plotW);
  const yFor = (v) => pad.top + plotH - ((v - lo) / (hi - lo)) * plotH;

  // Grid + y labels
  ctx.textBaseline = "middle";
  for (let g = 0; g <= 4; g++) {
    const v = lo + ((hi - lo) * g) / 4, y = yFor(v);
    ctx.strokeStyle = grid; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + plotW, y); ctx.stroke();
    ctx.fillStyle = muted; ctx.textAlign = "right";
    ctx.fillText(yFormat(v), pad.left - 6, y);
  }
  // Axes
  ctx.strokeStyle = axis; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(pad.left, pad.top); ctx.lineTo(pad.left, pad.top + plotH); ctx.lineTo(pad.left + plotW, pad.top + plotH); ctx.stroke();

  // x ticks (whole epochs, thinned so labels never collide)
  ctx.fillStyle = muted; ctx.textAlign = "center"; ctx.textBaseline = "top";
  const step = Math.max(1, Math.ceil(count / 10));
  for (let i = 0; i < count; i += step) ctx.fillText(String(i + 1), xFor(i), pad.top + plotH + 4);
  if ((count - 1) % step !== 0 && count > 1) ctx.fillText(String(count), xFor(count - 1), pad.top + plotH + 4);
  ctx.textAlign = "right";
  ctx.fillText(xLabel, pad.left + plotW, pad.top + plotH + 4 + Math.round(base * 0.95));

  // Lines
  series.forEach((s) => {
    ctx.strokeStyle = s.color; ctx.fillStyle = s.color; ctx.lineWidth = 2.5;
    ctx.setLineDash(s.dash || []);
    ctx.beginPath();
    let started = false;
    s.values.forEach((v, i) => {
      if (v === null || v === undefined) return;
      if (!started) { ctx.moveTo(xFor(i), yFor(v)); started = true; } else ctx.lineTo(xFor(i), yFor(v));
    });
    ctx.stroke();
    ctx.setLineDash([]);
    if (count <= 40) s.values.forEach((v, i) => { if (v !== null && v !== undefined) _drawMarker(ctx, s.marker || "circle", xFor(i), yFor(v), 3.5); });
  });

  // Legend (line sample shows dash style + marker so it works without colour)
  ctx.textBaseline = "middle"; ctx.textAlign = "left";
  let lx = pad.left;
  const ly = Math.round(base * 0.95);
  series.forEach((s) => {
    ctx.strokeStyle = s.color; ctx.fillStyle = s.color; ctx.lineWidth = 2.5;
    ctx.setLineDash(s.dash || []);
    ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(lx + 24, ly); ctx.stroke();
    ctx.setLineDash([]);
    _drawMarker(ctx, s.marker || "circle", lx + 12, ly, 3.5);
    ctx.fillStyle = textColor;
    ctx.fillText(s.label, lx + 30, ly);
    lx += 30 + ctx.measureText(s.label).width + 22;
  });
}

/** Single-series bars on a fixed or automatic 0..max scale, value printed above each bar. */
function drawBarChart(canvas, labels, values, { max, colors, valueDigits = 3 } = {}) {
  const prepared = prepareCanvas(canvas);
  if (!prepared) return;
  const { ctx, w, h } = prepared;
  const base = _basePx();
  const palette = colors || chartPalette();
  const textColor = cssVar("--text"), muted = cssVar("--text-muted"), axis = cssVar("--chart-axis"), grid = cssVar("--chart-grid");
  const font = `${Math.round(base * 0.78)}px sans-serif`;
  ctx.font = font;

  const many = labels.length > 5;
  const maxVal = max || Math.max(1, ...values);
  const labelRoom = many ? Math.min(110, Math.max(...labels.map((l) => ctx.measureText(l).width)) * 0.72 + 12) : Math.round(base * 2);
  const pad = { left: 44, right: 12, top: Math.round(base * 1.6), bottom: labelRoom };
  const plotW = w - pad.left - pad.right, plotH = h - pad.top - pad.bottom;
  const gap = many ? 8 : 18;
  const barW = Math.max(6, (plotW - gap * (labels.length - 1)) / labels.length);

  ctx.textBaseline = "middle";
  for (let g = 0; g <= 4; g++) {
    const v = (maxVal * g) / 4, y = pad.top + plotH - (v / maxVal) * plotH;
    ctx.strokeStyle = grid; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + plotW, y); ctx.stroke();
    ctx.fillStyle = muted; ctx.textAlign = "right"; ctx.fillText(v.toFixed(2), pad.left - 6, y);
  }
  ctx.strokeStyle = axis; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(pad.left, pad.top); ctx.lineTo(pad.left, pad.top + plotH); ctx.lineTo(pad.left + plotW, pad.top + plotH); ctx.stroke();

  values.forEach((val, i) => {
    const bh = (Math.max(0, val) / maxVal) * plotH;
    const x = pad.left + i * (barW + gap), y = pad.top + plotH - bh;
    ctx.fillStyle = palette[i % palette.length];
    ctx.fillRect(x, y, barW, bh);
    ctx.strokeStyle = textColor; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, barW - 1, Math.max(bh - 1, 0));
    ctx.fillStyle = textColor; ctx.textAlign = "center"; ctx.textBaseline = "bottom";
    ctx.fillText(val.toFixed(valueDigits), x + barW / 2, y - 3);
    ctx.textBaseline = "top";
    if (many) {
      ctx.save();
      ctx.translate(x + barW / 2, pad.top + plotH + 8);
      ctx.rotate(-Math.PI / 4);
      ctx.textAlign = "right"; ctx.textBaseline = "middle";
      ctx.fillText(labels[i], 0, 0);
      ctx.restore();
    } else {
      ctx.fillText(labels[i], x + barW / 2, pad.top + plotH + 6);
    }
  });
}

/** Two bars per label (Run A / Run B), A solid, B hatched so they differ without colour. */
function drawGroupedBarChart(canvas, labels, valuesA, valuesB, nameA, nameB, { max = 1 } = {}) {
  const prepared = prepareCanvas(canvas);
  if (!prepared) return;
  const { ctx, w, h } = prepared;
  const base = _basePx();
  const [c1, c2] = chartPalette();
  const textColor = cssVar("--text"), muted = cssVar("--text-muted"), axis = cssVar("--chart-axis"), grid = cssVar("--chart-grid");
  ctx.font = `${Math.round(base * 0.78)}px sans-serif`;

  const pad = { left: 44, right: 12, top: Math.round(base * 3), bottom: Math.round(base * 2) };
  const plotW = w - pad.left - pad.right, plotH = h - pad.top - pad.bottom;
  const groupGap = 20, n = labels.length;
  const groupW = (plotW - groupGap * (n - 1)) / n, barW = groupW / 2 - 2;

  ctx.textBaseline = "middle";
  for (let g = 0; g <= 4; g++) {
    const v = (max * g) / 4, y = pad.top + plotH - (v / max) * plotH;
    ctx.strokeStyle = grid; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + plotW, y); ctx.stroke();
    ctx.fillStyle = muted; ctx.textAlign = "right"; ctx.fillText(v.toFixed(2), pad.left - 6, y);
  }
  ctx.strokeStyle = axis; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(pad.left, pad.top); ctx.lineTo(pad.left, pad.top + plotH); ctx.lineTo(pad.left + plotW, pad.top + plotH); ctx.stroke();

  const hatch = (x, y, bw, bh, color) => {
    ctx.fillStyle = color; ctx.globalAlpha = 0.35; ctx.fillRect(x, y, bw, bh); ctx.globalAlpha = 1;
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, bw, bh); ctx.clip();
    ctx.strokeStyle = color; ctx.lineWidth = 2;
    for (let k = -bh; k < bw; k += 6) { ctx.beginPath(); ctx.moveTo(x + k, y + bh); ctx.lineTo(x + k + bh, y); ctx.stroke(); }
    ctx.restore();
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.strokeRect(x + 0.75, y + 0.75, bw - 1.5, Math.max(bh - 1.5, 0));
  };

  labels.forEach((label, i) => {
    const gx = pad.left + i * (groupW + groupGap);
    const ha = (valuesA[i] / max) * plotH, hb = (valuesB[i] / max) * plotH;
    ctx.fillStyle = c1; ctx.fillRect(gx, pad.top + plotH - ha, barW, ha);
    hatch(gx + barW + 4, pad.top + plotH - hb, barW, hb, c2);
    ctx.fillStyle = textColor; ctx.textAlign = "center"; ctx.textBaseline = "bottom";
    ctx.fillText(valuesA[i].toFixed(2), gx + barW / 2, pad.top + plotH - ha - 2);
    ctx.fillText(valuesB[i].toFixed(2), gx + barW + 4 + barW / 2, pad.top + plotH - hb - 2);
    ctx.textBaseline = "top";
    ctx.fillText(label, gx + groupW / 2, pad.top + plotH + 6);
  });

  ctx.textBaseline = "middle"; ctx.textAlign = "left";
  const ly = Math.round(base * 0.95);
  ctx.fillStyle = c1; ctx.fillRect(pad.left, ly - 6, 14, 12);
  ctx.fillStyle = textColor; ctx.fillText(`${nameA} (solid)`, pad.left + 20, ly);
  const off = pad.left + 20 + ctx.measureText(`${nameA} (solid)`).width + 24;
  hatch(off, ly - 6, 14, 12, c2);
  ctx.fillStyle = textColor; ctx.fillText(`${nameB} (hatched)`, off + 20, ly);
}

/** Put the same numbers a chart shows into an HTML table (for screen readers and exact values). */
function renderDataTable(containerId, caption, headers, rows) {
  const container = $(containerId);
  if (!container) return;
  const head = headers.map((h, i) => `<th scope="col">${esc(h)}</th>`).join("");
  const body = rows.map((r) => `<tr>${r.map((cell, i) => (i === 0 ? `<th scope="row">${esc(cell)}</th>` : `<td>${esc(cell)}</td>`)).join("")}</tr>`).join("");
  container.innerHTML = `<table class="data-table"><caption>${esc(caption)}</caption><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

let _resizeTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(_resizeTimer);
  _resizeTimer = setTimeout(redrawAllRegisteredCharts, 120);
});
