"""
EdSeg desktop launcher.

This is what turns EdSeg from "run python backend/app.py and open a
browser" into an actual double-click desktop app: it starts the same
Flask backend in a background thread, then opens a native OS window
(via pywebview) pointing at it — no visible browser chrome, no terminal,
no manual step for the student.

This file is what PyInstaller packages into the final .exe / .app.

Important differences from running backend/app.py directly for development:
  - debug=False and use_reloader=False — Flask's debug reloader spawns a
    second process and watches files for changes, neither of which makes
    sense (or works reliably) inside a frozen/bundled executable.
  - The server always binds to 127.0.0.1 (loopback only) — this app is
    never meant to be reachable from other machines on the network.
  - If PyInstaller has bundled the app (sys.frozen is set), paths are
    resolved relative to the bundle's temp extraction folder instead of
    the source tree.
  - A loading screen is shown IMMEDIATELY (before the backend is even
    guaranteed to be ready), then the window automatically swaps to the
    real app once the backend responds. Without this, students would see
    a blank/white window for however long PyTorch takes to load — which
    can be a genuinely long time on a CUDA build — and reasonably assume
    the app had frozen or crashed.
  - The loading/error screens are written to actual temporary HTML FILES
    and loaded via load_url("file://...") rather than passed as raw HTML
    strings. Some WebView2 versions on Windows handle inline HTML
    strings unreliably (can render as a blank white window); loading a
    real file is the more broadly compatible approach.
  - All startup activity is logged to a file next to the app (see
    get_log_path()) since the packaged app runs with no visible console
    — without this, a failure on a student's machine would be completely
    silent and undiagnosable.
"""

import os
import sys

# MUST be set before `webview` (and therefore `pythonnet`) is imported.
# On Windows, pywebview opens its native window through pythonnet, which
# needs to find a working .NET runtime. Two separate failure modes have
# been observed on real student machines:
#   1. pythonnet falls back to the legacy ".NET Framework" bridge, which
#      fails with a DLL export-resolution error even when a modern .NET
#      is installed.
#   2. Forcing the modern "coreclr" runtime (fix for #1) then fails with
#      "Can not determine dotnet root" — a working .NET IS installed, but
#      not somewhere pythonnet automatically checks (PATH, standard
#      Program Files location).
# This block addresses #2 by explicitly pointing at the standard install
# locations if DOTNET_ROOT isn't already set. main() below additionally
# has a fallback: if startup still fails, it relaunches itself once with
# the OTHER runtime strategy before giving up and showing an error screen.
if sys.platform == "win32":
    os.environ.setdefault("PYTHONNET_RUNTIME", os.environ.get("EDSEG_RUNTIME_OVERRIDE", "coreclr"))

    if "DOTNET_ROOT" not in os.environ:
        _dotnet_candidates = [
            r"C:\Program Files\dotnet",
            r"C:\Program Files (x86)\dotnet",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\dotnet"),
        ]
        for _candidate in _dotnet_candidates:
            if os.path.isdir(_candidate):
                os.environ["DOTNET_ROOT"] = _candidate
                break

import secrets
import subprocess
import threading
import time
import tempfile
import traceback
import socket
from datetime import datetime

# NOTE: `webview` is imported inside run_app() (not here) so the headless
# --selftest mode below works even on a machine with no usable GUI runtime.

# How long to wait for the backend before showing an error screen instead
# of the app. CUDA-enabled PyTorch builds can take a while to initialize
# on first launch (extracting the bundle, loading CUDA libraries), so this
# is intentionally generous rather than tuned for the CPU-only case.
STARTUP_TIMEOUT_SECONDS = 120

# NOTE ON PORT 5000: macOS Monterey (2021) and later bind port 5000 by
# default for AirPlay Receiver — a very well-known gotcha for any local
# Flask app. If EdSeg hardcoded port 5000, it would silently fail to
# start on a large fraction of Mac students' machines with no obvious
# cause (the bind error happens in a background thread with no visible
# console). To avoid this entirely, the server binds to a free port
# chosen at launch time instead of a fixed one — see find_free_port().
PREFERRED_PORT = 57132  # deliberately uncommon; falls back automatically if taken

# Per-launch secret: only EdSeg's own window (opened with ?k=<secret>) may talk to the local server.
# See backend/security.py. It is never written to the log file.
os.environ.setdefault("EDSEG_TOKEN", secrets.token_urlsafe(32))
APP_KEY = os.environ["EDSEG_TOKEN"]


def find_free_port(preferred=PREFERRED_PORT):
    """
    Find a free TCP port for the backend to bind to. Tries a fixed,
    deliberately uncommon preferred port first (NOT 5000/3000/8000/8080,
    which frequently collide with AirPlay Receiver or other dev tools),
    and falls back to asking the OS for any available port if that one
    happens to be taken.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", preferred))
            return preferred
    except OSError:
        pass

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))  # port 0 = ask the OS for any free port
        return s.getsockname()[1]

LOADING_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>EdSeg is starting</title>
<style>
  html, body {
    margin: 0; height: 100%;
    background: #0b0e14;
    color: #eef1f6;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
    display: flex; align-items: center; justify-content: center;
  }
  .box { text-align: center; }
  .brand { font-size: 22px; font-weight: 700; margin-bottom: 18px; }
  .brand .accent {
    background: linear-gradient(135deg, #5b8def, #8b5cf6);
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .spinner {
    width: 34px; height: 34px; margin: 0 auto 18px auto;
    border: 3px solid #232b3a; border-top-color: #5b8def;
    border-radius: 50%; animation: spin 0.9s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .status { font-size: 14px; color: #aab2c5; }
  @media (prefers-reduced-motion: reduce) { .spinner { animation: none; } }
</style>
</head>
<body>
  <div class="box" role="status" aria-live="polite">
    <div class="brand">Ed<span class="accent">Seg</span></div>
    <div class="spinner" aria-hidden="true"></div>
    <div class="status">Starting up&hellip; this can take a little while the first time.</div>
  </div>
</body>
</html>
"""

ERROR_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>EdSeg did not start</title>
<style>
  html, body {{
    margin: 0; height: 100%;
    background: #0b0e14;
    color: #eef1f6;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
    display: flex; align-items: center; justify-content: center;
  }}
  .box {{ text-align: center; max-width: 480px; padding: 20px; }}
  .title {{ font-size: 18px; font-weight: 700; margin-bottom: 10px; color: #f26b6b; }}
  .msg {{ font-size: 14px; color: #aab2c5; line-height: 1.6; }}
  .logpath {{ font-size: 12px; color: #8f99ae; margin-top: 14px; word-break: break-all; }}
</style>
</head>
<body>
  <div class="box" role="alert">
    <div class="title">EdSeg didn't start in time</div>
    <div class="msg">
      The backend took longer than expected to respond. Try closing this
      window and reopening the app. If this keeps happening, send the log
      file below to whoever set this app up for help.
    </div>
    <div class="logpath">{log_path}</div>
  </div>
</body>
</html>
"""


def resource_path(relative_path):
    """
    Resolve a path that works both when running from source AND when
    running as a PyInstaller-frozen executable (which unpacks bundled
    files into a temporary folder referenced by sys._MEIPASS).
    """
    if getattr(sys, "frozen", False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def get_log_path():
    """
    Log file location: next to the actual executable when packaged (same
    persistent-data convention as checkpoints/models/reports), or in the
    project folder when running from source.
    """
    if getattr(sys, "frozen", False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, "edseg_launcher.log")


def log(message):
    """Append a timestamped line to the launcher log file. Never raises."""
    try:
        with open(get_log_path(), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {message}\n")
    except Exception:
        pass  # logging must never crash the app


def write_temp_html(content, filename):
    """
    Write an HTML string to a temp file and return a file:// URL to it.
    Loading a real file is more reliable across WebView2 versions than
    passing raw HTML strings directly.
    """
    temp_dir = tempfile.gettempdir()
    path = os.path.join(temp_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    # file:// URLs need forward slashes even on Windows
    return "file:///" + path.replace(os.sep, "/")


def start_flask_server(port):
    """Import and run the Flask app in this thread (blocking)."""
    try:
        log(f"Starting Flask server thread on port {port}...")
        backend_dir = resource_path("backend")
        sys.path.insert(0, backend_dir)

        # Imported here (not at module level) so `backend_dir` is on sys.path first
        import app as flask_app_module
        log("Backend module imported successfully.")

        flask_app_module.app.run(
            host="127.0.0.1",
            port=port,
            debug=False,
            use_reloader=False,
            threaded=True,
        )
    except Exception:
        log("FATAL: exception in start_flask_server:\n" + traceback.format_exc())


def wait_for_server(url, timeout):
    """Poll the server until it responds or the timeout elapses."""
    import urllib.request
    import urllib.error

    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except (urllib.error.URLError, ConnectionError, OSError):
            time.sleep(0.3)
    return False


def wait_then_switch(window, port):
    """
    Runs in a background thread once the webview GUI loop has started.
    Polls the backend, then swaps the (already-visible) loading window
    over to the real app, or to an error screen if it never comes up.
    """
    log("Polling backend for readiness...")
    ready = wait_for_server(f"http://127.0.0.1:{port}/api/ping", timeout=STARTUP_TIMEOUT_SECONDS)
    if ready:
        log("Backend ready. Switching window to the real app.")
        window.load_url(f"http://127.0.0.1:{port}/?k={APP_KEY}")
    else:
        log("Backend did NOT respond within the timeout. Showing error screen.")
        error_html = ERROR_HTML_TEMPLATE.format(log_path=get_log_path())
        error_url = write_temp_html(error_html, "edseg_error.html")
        window.load_url(error_url)


def show_native_message(message, title="EdSeg", icon=0x40):
    """Blocking native message box (Win32 via ctypes; prints on other platforms)."""
    log(f"Showing native message: {message[:80]!r}")
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, title, icon)
        except Exception:
            log("Native message box failed:\n" + traceback.format_exc())
    else:
        print(message, file=sys.stderr)


def show_native_error(message):
    """
    Last-resort error display that doesn't depend on webview/pythonnet/.NET
    at all — used only if BOTH runtime strategies below have already
    failed, meaning we can't render anything through webview itself.
    Uses the raw Win32 MessageBox API directly via ctypes.
    """
    log(f"Showing native fallback error dialog: {message}")
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, "EdSeg — Startup Error", 0x10)
        except Exception:
            log("Even the native error dialog failed:\n" + traceback.format_exc())
    else:
        print(message, file=sys.stderr)


def webview2_runtime_installed():
    """
    True if the Microsoft Edge WebView2 runtime (what pywebview uses to draw the
    app window on Windows) is really present. Checks for the runtime's files,
    not the registry: a stale registry entry can survive an uninstall, and
    without the runtime pywebview silently falls back to the ancient Internet
    Explorer engine, which shows an empty white window.
    """
    if sys.platform != "win32":
        return True
    for root in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
        if not root:
            continue
        base = os.path.join(root, "Microsoft", "EdgeWebView", "Application")
        if os.path.isdir(base):
            for version in os.listdir(base):
                if os.path.exists(os.path.join(base, version, "msedgewebview2.exe")):
                    return True
    return False


def run_in_browser_fallback():
    """
    No WebView2 runtime: serve the app and open it in the student's normal web
    browser instead of showing a blank window. A native message box (no .NET or
    web engine needed) keeps EdSeg alive; closing it quits the app.
    """
    import webbrowser

    port = find_free_port()
    log(f"WebView2 runtime not found; using the default browser on port {port}.")
    threading.Thread(target=start_flask_server, args=(port,), daemon=True).start()
    if wait_for_server(f"http://127.0.0.1:{port}/api/ping", timeout=STARTUP_TIMEOUT_SECONDS):
        webbrowser.open(f"http://127.0.0.1:{port}/?k={APP_KEY}")
        show_native_message(
            "EdSeg is open in your web browser.\n\n"
            "Keep this box open while you use EdSeg. Click OK to quit EdSeg.\n\n"
            "(To get the normal app window, install the free 'Microsoft Edge WebView2 Runtime' "
            "from Microsoft and start EdSeg again.)",
            "EdSeg is running",
        )
    else:
        show_native_error("EdSeg's engine did not start. Please check the log file:\n\n" + get_log_path())


def run_app():
    """The actual startup sequence. May raise if webview/pythonnet fails."""
    if not webview2_runtime_installed():
        run_in_browser_fallback()
        return

    import webview

    port = find_free_port()
    log(f"Selected port {port} for the backend.")

    server_thread = threading.Thread(target=start_flask_server, args=(port,), daemon=True)
    server_thread.start()

    loading_url = write_temp_html(LOADING_HTML, "edseg_loading.html")
    log(f"Loading screen written to: {loading_url}")

    # Show the loading screen immediately — don't wait for the backend
    # before the student sees *something*.
    window = webview.create_window(
        "EdSeg",
        loading_url,
        width=1440,
        height=900,
        min_size=(1000, 700),
    )
    log("webview window created.")

    # webview.start()'s `func` runs in a background thread after the GUI
    # loop is already running, so the loading screen is visible right away
    # while this polls for the backend in parallel.
    # NOTE: `args` must be an iterable of arguments (a tuple), not the
    # bare window object — passing it un-wrapped causes pywebview to try
    # to unpack it incorrectly.
    webview.start(wait_then_switch, (window, port), debug=False)
    log("webview.start() returned — window closed, app exiting normally.")


def main():
    # Headless verification of a packaged build: EdSeg.exe --selftest <report.json>
    if len(sys.argv) >= 3 and sys.argv[1] == "--selftest":
        os.environ.pop("EDSEG_TOKEN", None)   # the self-test drives the API in-process, without the window's session cookie
        sys.path.insert(0, resource_path("backend"))
        import selftest
        sys.exit(selftest.run(sys.argv[2]))

    log("=" * 60)
    log("EdSeg launcher starting.")
    current_runtime = os.environ.get("PYTHONNET_RUNTIME", "n/a")
    is_fallback_attempt = os.environ.get("EDSEG_FALLBACK_ATTEMPT") == "1"
    log(f"frozen={getattr(sys, 'frozen', False)} platform={sys.platform} "
        f"pythonnet_runtime={current_runtime} fallback_attempt={is_fallback_attempt}")

    try:
        run_app()
    except Exception:
        log("Startup failed:\n" + traceback.format_exc())

        if sys.platform == "win32" and not is_fallback_attempt:
            # First failure — automatically retry once with the OTHER .NET
            # runtime strategy. This has to be a fresh PROCESS, not a retry
            # within this one: once a Python import fails, re-attempting
            # the same import in the same process won't behave differently.
            other_runtime = "netfx" if current_runtime == "coreclr" else "coreclr"
            log(f"Retrying once in a fresh process with PYTHONNET_RUNTIME={other_runtime}...")
            env = os.environ.copy()
            env["PYTHONNET_RUNTIME"] = other_runtime
            env["EDSEG_FALLBACK_ATTEMPT"] = "1"
            try:
                subprocess.Popen([sys.executable] + sys.argv[1:], env=env)
                log("Fallback process launched. Exiting this attempt.")
            except Exception:
                log("Failed to launch fallback process:\n" + traceback.format_exc())
                show_native_error(
                    "EdSeg could not start (failed to launch a retry). "
                    f"Please check the log file for details:\n{get_log_path()}"
                )
            return
        else:
            # Either not on Windows, or this WAS already the fallback
            # attempt and it failed too — both strategies are exhausted.
            show_native_error(
                "EdSeg could not start. This is usually a missing or "
                "misconfigured .NET runtime on this computer.\n\n"
                "Please check the log file for details, and try installing "
                "the .NET Desktop Runtime from dotnet.microsoft.com if you "
                "haven't already:\n\n" + get_log_path()
            )
            return


if __name__ == "__main__":
    main()
