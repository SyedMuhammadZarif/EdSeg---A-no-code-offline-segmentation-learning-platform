"""
Build information shown in the app ("About this build").

EdSeg ships in two flavours: a small CPU-only build and a much larger build
that bundles the CUDA libraries for NVIDIA GPUs. Students deserve to know
which one they are running and what the other would cost them in disk space.

At build time, build_tools/finalize_build.py measures the real folder size
and writes build_info.json next to the executable; this module reads it
back. When running from source the numbers are simply absent.
"""

import json
import os

from device_utils import describe_torch_build, detect_available_devices
from paths import get_app_root, is_frozen

# Sizes (megabytes) of the two builds. None = not measured / unknown.
_FALLBACK_SIZES_MB = {"cpu_folder": None, "cpu_zip": None, "cuda_folder": None, "cuda_zip": None}


def _read_build_json():
    path = os.path.join(get_app_root(), "build_info.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get_build_info():
    torch_info = describe_torch_build()
    devices = detect_available_devices()
    recorded = _read_build_json()

    sizes = dict(_FALLBACK_SIZES_MB)
    sizes.update({k: v for k, v in (recorded.get("sizes_mb") or {}).items() if v is not None})

    if torch_info["flavor"] == "cpu":
        if devices["mps"]:
            headline = "Standard build — this Mac's GPU (Apple Silicon) can still be used."
        else:
            headline = "CPU-only build — works on every computer, but cannot use an NVIDIA GPU."
    else:
        headline = "CUDA build — can train on an NVIDIA GPU, and also works on CPU."

    return {
        "flavor": torch_info["flavor"],
        "torch_version": torch_info["torch_version"],
        "cuda_runtime": torch_info["cuda_runtime"],
        "gpu_name": torch_info["gpu_name"],
        "devices": devices,
        "packaged": is_frozen(),
        "app_version": recorded.get("app_version", "dev"),
        "built_on": recorded.get("built_on"),
        "sizes_mb": sizes,
        "sizes_estimated": recorded.get("sizes_estimated", []),
        "headline": headline,
    }
