"""
Device detection/selection for CPU vs GPU (CUDA or Apple Silicon MPS), plus
a description of which kind of PyTorch this build ships with — the app needs
to tell students plainly whether a missing GPU is because this is the small
CPU-only build or because their computer has no compatible GPU.
"""

import torch


def detect_available_devices():
    """Return a dict describing what compute devices are usable on this machine."""
    return {
        "cpu": True,  # always available
        "cuda": torch.cuda.is_available(),
        "mps": torch.backends.mps.is_available() if hasattr(torch.backends, "mps") else False,
    }


def describe_torch_build():
    """
    What kind of PyTorch is running: 'cpu' (CPU-only wheel, no CUDA libraries
    inside) or 'cuda' (CUDA libraries are bundled), plus the GPU's name when
    one is usable.
    """
    built_with_cuda = torch.version.cuda is not None
    gpu_name = None
    try:
        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
    except Exception:
        gpu_name = None
    return {
        "torch_version": torch.__version__.split("+")[0],
        "flavor": "cuda" if built_with_cuda else "cpu",
        "cuda_runtime": torch.version.cuda,
        "gpu_name": gpu_name,
        "num_threads": torch.get_num_threads(),
    }


def resolve_device(preference="auto"):
    """
    preference: 'auto', 'cpu', 'cuda', or 'mps'.

    'auto' picks the best available: cuda > mps > cpu.
    Explicit choices fall back to cpu (with a note) if unavailable, rather
    than crashing — this matters for the UI's CPU/GPU toggle.
    """
    available = detect_available_devices()

    if preference == "cpu":
        return torch.device("cpu"), "cpu"

    if preference == "cuda":
        if available["cuda"]:
            return torch.device("cuda"), "cuda"
        return torch.device("cpu"), "cpu (requested cuda, not available)"

    if preference == "mps":
        if available["mps"]:
            return torch.device("mps"), "mps"
        return torch.device("cpu"), "cpu (requested mps, not available)"

    # auto
    if available["cuda"]:
        return torch.device("cuda"), "cuda"
    if available["mps"]:
        return torch.device("mps"), "mps"
    return torch.device("cpu"), "cpu"
