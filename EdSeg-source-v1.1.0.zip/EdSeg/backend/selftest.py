"""
Headless self-test used to verify a PACKAGED EdSeg build.

    EdSeg.exe --selftest <report.json>

It exercises what a student's first session would: import every bundled
library, build and run every model (2D and 3D), call the API, and train for
a short while on both a bundled 2D and a bundled 3D dataset. It writes a JSON
report (the windowed .exe has no console to print to) and exits with code 0
when everything passed.

Set EDSEG_DATA_DIR to a scratch folder first so the test's checkpoints are not
written into the build folder.
"""

import json
import os
import sys
import time
import traceback


def _step(report, name, fn):
    started = time.time()
    try:
        detail = fn()
        report["steps"].append({"name": name, "ok": True, "seconds": round(time.time() - started, 2), "detail": detail})
        return True
    except Exception as exc:  # report every failure instead of stopping at the first
        report["steps"].append({"name": name, "ok": False, "seconds": round(time.time() - started, 2),
                                "error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-1500:]})
        return False


def run(out_path):
    report = {"ok": False, "frozen": bool(getattr(sys, "frozen", False)), "python": sys.version.split()[0], "steps": []}

    def libs():
        import flask, numpy, PIL, nibabel, torch
        return {"torch": torch.__version__, "cuda_built": torch.version.cuda, "cuda_available": torch.cuda.is_available(),
                "numpy": numpy.__version__, "flask": flask.__version__, "nibabel": nibabel.__version__, "pillow": PIL.__version__}

    def all_models():
        import torch
        import models
        from losses_metrics import BCEDiceLoss
        results = {}
        for arch in models.describe_architectures():
            model = models.build_model(arch["name"])
            shape = (2, 1, 32, 32, 32) if arch["dim"] == 3 else (2, 1, 64, 64)
            x = torch.rand(*shape)
            out = model(x)
            assert out.shape == x.shape, f"{arch['name']}: output {tuple(out.shape)} != input {tuple(x.shape)}"
            BCEDiceLoss()(out, (torch.rand(*shape) > 0.5).float()).backward()
            results[arch["name"]] = arch["parameters"]
        return results

    def api_calls():
        from app import app
        client = app.test_client()
        assert client.get("/api/ping").status_code == 200
        info = client.get("/api/build_info").get_json()
        datasets = client.get("/api/datasets").get_json()["datasets"]
        archs = client.get("/api/models/architectures").get_json()["architectures"]
        ping = client.get("/api/ping")
        assert "script-src 'self'" in ping.headers.get("Content-Security-Policy", ""), "Content-Security-Policy header missing"
        assert ping.headers.get("X-Content-Type-Options") == "nosniff", "security headers missing"
        assert client.get("/api/ping", headers={"Host": "attacker.example"}).status_code == 400, "foreign Host header was accepted"
        page = client.get("/")
        assert page.status_code == 200 and b"EdSeg" in page.data, "frontend index.html is missing"
        for asset in ("/style.css", "/js/core.js", "/js/charts.js", "/js/viewer.js", "/js/app.js",
                      "/js/screens-main.js", "/js/screens-advanced.js", "/js/trainviz.js", "/js/main.js", "/trainviz.css"):
            assert client.get(asset).status_code == 200, f"frontend asset missing: {asset}"
        return {"flavor": info["flavor"], "datasets": [(d["name"], d["kind"], d["count"]) for d in datasets], "architectures": len(archs)}

    def access_control():
        # Build a throwaway Flask app with the SAME protections the real server installs, with a token, and
        # confirm that requests without the session cookie are refused while the right key gets in.
        from flask import Flask
        import security
        probe = Flask("probe")
        security.install(probe, "selftest-token")

        @probe.route("/api/x")
        def _x():
            return "ok"

        c = probe.test_client()
        assert c.get("/api/x").status_code == 403, "API answered without a session cookie"
        assert c.post("/api/x", headers={"Origin": "http://evil.example", "Content-Type": "text/plain"}, data="{}").status_code in (403, 405)
        assert c.get("/api/x", headers={"Host": "attacker.example"}).status_code == 400
        assert c.get("/?k=selftest-token").status_code == 302
        assert c.get("/api/x").status_code == 200, "session cookie was not accepted"
        return {"cookie_enforced": True}

    def train(dataset, model, size):
        def run_it():
            from train import train_model
            result = train_model(dataset, "bundled", model, learning_rate=0.005, epochs=2, batch_size=4,
                                 image_size=size, device_preference="cpu")
            last = result["metrics_history"][-1]
            assert result["checkpoint_paths"], "no checkpoint was written"
            return {"epochs": len(result["metrics_history"]), "val_dice": round(last["val_dice"], 3)}
        return run_it

    def inference_and_results():
        from train import train_model
        import results, inference, model_library
        r = train_model("sample_blobs_3d", "bundled", "unet3d_lite", epochs=1, batch_size=4, image_size=32, device_preference="cpu")
        summary = results.build_results_summary(r["checkpoint_paths"][-1])
        assert summary["sample_predictions"] and summary["sample_predictions"][0]["kind"] == "volume"
        model_library.save_model(r["checkpoint_paths"][-1], "selftest3d")
        out = inference.run_inference_on_dataset("selftest3d", "sample_blobs_3d", "bundled", "cpu")
        model_library.delete_model("selftest3d")
        return {"volumes_tested": out["total_images_tested"], "dice": round(out["confusion_matrix"]["dice"], 3)}

    _step(report, "libraries import", libs)
    _step(report, "all models forward+backward", all_models)
    _step(report, "API + frontend files", api_calls)
    _step(report, "access control (cookie, host check)", access_control)
    _step(report, "train 2D (mini_unet, sample_shapes)", train("sample_shapes", "mini_unet", 64))
    _step(report, "train 2D (light_vm_unet_2d, sample_shapes)", train("sample_shapes", "light_vm_unet_2d", 64))
    _step(report, "train 3D (unet3d_lite, sample_blobs_3d)", train("sample_blobs_3d", "unet3d_lite", 32))
    _step(report, "train 3D (light_vm_unet_3d, sample_blobs_3d)", train("sample_blobs_3d", "light_vm_unet_3d", 32))
    _step(report, "train 3D (gmanet_3d, sample_blobs_3d)", train("sample_blobs_3d", "gmanet_3d", 32))
    _step(report, "results + save + dataset inference (3D)", inference_and_results)

    report["ok"] = all(s["ok"] for s in report["steps"])
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    return 0 if report["ok"] else 1
