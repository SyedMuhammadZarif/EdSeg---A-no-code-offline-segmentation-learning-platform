"""
Pure-PyTorch state-space ("Mamba-style") building blocks.

The official Mamba implementation (`mamba_ssm`) needs a CUDA-only compiled
kernel, which would make EdSeg's CPU-only build impossible. This module
implements the same *idea* — a selective state-space model (SSM) that
scans a sequence in linear time — in plain PyTorch so it runs on CPU, CUDA
and Apple Silicon alike, and so students can read the whole thing.

The scan itself is a parallel prefix scan (Hillis-Steele): instead of a
slow Python loop over every token, it needs only log2(L) vectorised steps.
It is exact (not an approximation) and numerically stable because every
decay factor lies in (0, 1].

Used by the Light-VM-UNet models (2D and 3D) in models_lite.py / models_3d.py.
"""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def parallel_linear_scan(a, b):
    """
    Solve h[t] = a[t] * h[t-1] + b[t] (with h[-1] = 0) along the LAST axis
    for every leading index at once. a and b have identical shape (..., L).
    """
    length = a.shape[-1]
    step = 1
    while step < length:
        a_prev = F.pad(a[..., :-step], (step, 0), value=1.0)
        b_prev = F.pad(b[..., :-step], (step, 0), value=0.0)
        b = b + a * b_prev
        a = a * a_prev
        step *= 2
    return b


class SelectiveSSM(nn.Module):
    """
    The "S6" selective state-space layer at the heart of Mamba: the step
    size (delta) and the input/output projections (B, C) depend on the
    current token, which is what lets it decide what to remember or ignore.
    Input and output shape: (batch, length, channels).
    """

    def __init__(self, channels, state_dim=8, dt_rank=None):
        super().__init__()
        self.channels = channels
        self.state_dim = state_dim
        self.dt_rank = dt_rank or max(1, math.ceil(channels / 16))

        self.x_proj = nn.Linear(channels, self.dt_rank + 2 * state_dim, bias=False)
        self.dt_proj = nn.Linear(self.dt_rank, channels)

        # A is stored as a log so it stays negative (stable decay) after exp.
        a_init = torch.arange(1, state_dim + 1, dtype=torch.float32).repeat(channels, 1)
        self.A_log = nn.Parameter(torch.log(a_init))
        self.D = nn.Parameter(torch.ones(channels))

        # Initialise the step size to a sensible range (as in the Mamba paper).
        dt = torch.exp(torch.rand(channels) * (math.log(0.1) - math.log(0.001)) + math.log(0.001)).clamp(min=1e-4)
        with torch.no_grad():
            self.dt_proj.bias.copy_(dt + torch.log(-torch.expm1(-dt)))

    def forward(self, x):
        x_dbl = self.x_proj(x)                                           # (B, L, R + 2N)
        dt, b_mat, c_mat = torch.split(x_dbl, [self.dt_rank, self.state_dim, self.state_dim], dim=-1)
        delta = F.softplus(self.dt_proj(dt))                             # (B, L, C)

        a_mat = -torch.exp(self.A_log)                                   # (C, N)
        decay = torch.exp(delta.unsqueeze(-1) * a_mat)                   # (B, L, C, N)
        drive = delta.unsqueeze(-1) * b_mat.unsqueeze(2) * x.unsqueeze(-1)

        h = parallel_linear_scan(decay.permute(0, 2, 3, 1), drive.permute(0, 2, 3, 1))  # (B, C, N, L)
        y = (h * c_mat.permute(0, 2, 1).unsqueeze(1)).sum(dim=2)         # (B, C, L)
        y = y.permute(0, 2, 1) + x * self.D
        return y


class VSSModule(nn.Module):
    """
    "Vision State-Space" module as described for LightM-UNet: expand the
    channels, run one branch through depth-wise conv -> SiLU -> SSM -> norm,
    gate it with a second SiLU branch, and project back. Works on a
    flattened token sequence (batch, length, channels).
    """

    def __init__(self, channels, expand=2, state_dim=8, conv_kernel=3):
        super().__init__()
        inner = channels * expand
        self.in_proj = nn.Linear(channels, inner * 2)
        self.conv = nn.Conv1d(inner, inner, conv_kernel, padding=conv_kernel // 2, groups=inner)
        self.ssm = SelectiveSSM(inner, state_dim=state_dim)
        self.norm = nn.LayerNorm(inner)
        self.out_proj = nn.Linear(inner, channels)

    def forward(self, x):
        u, gate = self.in_proj(x).chunk(2, dim=-1)
        u = F.silu(self.conv(u.transpose(1, 2)).transpose(1, 2))
        u = self.norm(self.ssm(u))
        return self.out_proj(u * F.silu(gate))


class RVMLayer(nn.Module):
    """
    Residual Vision Mamba layer: LayerNorm -> VSS module with a learnable
    residual shortcut -> LayerNorm -> linear projection (which can also
    change the channel count). Operates on feature maps of ANY spatial
    dimensionality: (B, C, H, W) or (B, C, D, H, W).
    """

    def __init__(self, in_channels, out_channels, state_dim=8):
        super().__init__()
        self.norm1 = nn.LayerNorm(in_channels)
        self.vss = VSSModule(in_channels, state_dim=state_dim)
        self.skip_scale = nn.Parameter(torch.ones(1))
        self.norm2 = nn.LayerNorm(in_channels)
        self.proj = nn.Linear(in_channels, out_channels)

    def forward(self, x):
        spatial = x.shape[2:]
        tokens = x.flatten(2).transpose(1, 2)                            # (B, L, C)
        normed = self.norm1(tokens)
        mixed = self.vss(normed) + self.skip_scale * normed
        out = self.proj(self.norm2(mixed))                               # (B, L, C_out)
        return out.transpose(1, 2).reshape(x.shape[0], -1, *spatial)
