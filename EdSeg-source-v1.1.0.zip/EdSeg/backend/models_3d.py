"""
Lightweight 3D architectures for EdSeg (volumetric segmentation: CT / MRI).

  * UNet3DLite    — a narrow 3D U-Net (the standard baseline for volumes)
  * GMANet3D      — gated, multi-scale attention network (3D)
  * LightVM3DUNet — Mamba-style state-space blocks in 3D (Light-VM-UNet)

All take a (batch, 1, depth, height, width) volume and return one-channel
logits of the same size. Spatial sizes must be divisible by 8 (the app
resizes volumes accordingly). They use Instance/Group normalisation rather
than BatchNorm because 3D training uses tiny batches (often 1-2 volumes),
where BatchNorm statistics become unreliable.

A note on honesty: these are compact, readable re-implementations of each
architecture's central ideas, sized for CPU training and teaching. They are
not the research authors' released code and ship without pretrained weights.
In particular "GMANet" is an educational interpretation (gated skip
attention + multi-scale channel attention), see the model description.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from models_lite import LightVMUNet


def _conv3(cin, cout, k=3):
    return nn.Sequential(
        nn.Conv3d(cin, cout, k, padding=k // 2, bias=False),
        nn.InstanceNorm3d(cout, affine=True),
        nn.LeakyReLU(0.01, inplace=True),
    )


def _double_conv3(cin, cout):
    return nn.Sequential(_conv3(cin, cout), _conv3(cout, cout))


class UNet3DLite(nn.Module):
    name = "unet3d_lite"
    display_name = "Lightweight 3D U-Net"
    dim = 3
    speed = "medium"
    description = ("The classic U-Net with 3D convolutions so it sees the whole volume (not one slice at a "
                   "time), kept narrow (8 base channels) so it trains on a CPU. The sensible 3D baseline.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=8):
        super().__init__()
        c = base_channels
        self.enc1 = _double_conv3(in_channels, c)
        self.enc2 = _double_conv3(c, c * 2)
        self.enc3 = _double_conv3(c * 2, c * 4)
        self.pool = nn.MaxPool3d(2)
        self.bottleneck = _double_conv3(c * 4, c * 8)
        self.up3 = nn.ConvTranspose3d(c * 8, c * 4, 2, stride=2)
        self.dec3 = _double_conv3(c * 8, c * 4)
        self.up2 = nn.ConvTranspose3d(c * 4, c * 2, 2, stride=2)
        self.dec2 = _double_conv3(c * 4, c * 2)
        self.up1 = nn.ConvTranspose3d(c * 2, c, 2, stride=2)
        self.dec1 = _double_conv3(c * 2, c)
        self.out_conv = nn.Conv3d(c, out_channels, 1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        b = self.bottleneck(self.pool(e3))
        d3 = self.dec3(torch.cat([self.up3(b), e3], 1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], 1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], 1))
        return self.out_conv(d1)


class _AttentionGate3D(nn.Module):
    def __init__(self, gate_ch, skip_ch, inter_ch):
        super().__init__()
        self.w_gate = nn.Sequential(nn.Conv3d(gate_ch, inter_ch, 1), nn.InstanceNorm3d(inter_ch, affine=True))
        self.w_skip = nn.Sequential(nn.Conv3d(skip_ch, inter_ch, 1), nn.InstanceNorm3d(inter_ch, affine=True))
        self.psi = nn.Sequential(nn.Conv3d(inter_ch, 1, 1), nn.Sigmoid())

    def forward(self, gate, skip):
        return skip * self.psi(F.relu(self.w_gate(gate) + self.w_skip(skip), inplace=True))


class _MultiScaleChannelAttention3D(nn.Module):
    """
    Multi-scale reconstruction attention (inspired by the EMRA block of
    LGMANet): an ECA-style channel gate (global pool -> small 1D conv ->
    sigmoid) followed by parallel 1x1x1 / 3x3x3 / dilated 3x3x3 branches
    that are concatenated and fused.
    """

    def __init__(self, channels):
        super().__init__()
        self.eca = nn.Conv1d(1, 1, 3, padding=1, bias=False)
        branch = max(channels // 2, 4)
        self.b1 = nn.Conv3d(channels, branch, 1)
        self.b3 = nn.Conv3d(channels, branch, 3, padding=1)
        self.b5 = nn.Conv3d(channels, branch, 3, padding=2, dilation=2)  # 5x5x5 receptive field, 3x3x3 cost
        self.fuse = nn.Sequential(nn.Conv3d(branch * 3, channels, 1), nn.InstanceNorm3d(channels, affine=True),
                                  nn.LeakyReLU(0.01, inplace=True))

    def forward(self, x):
        w = x.mean(dim=(2, 3, 4)).unsqueeze(1)                        # (B, 1, C)
        w = torch.sigmoid(self.eca(w)).transpose(1, 2).reshape(x.shape[0], -1, 1, 1, 1)
        x = x * w
        return self.fuse(torch.cat([self.b1(x), self.b3(x), self.b5(x)], 1))


class _DenseLocalBlock3D(nn.Module):
    """Three densely connected 3x3x3 convs (each sees all earlier outputs) — local detail."""

    def __init__(self, cin, cout):
        super().__init__()
        growth = max(cout // 2, 4)
        self.c1 = _conv3(cin, growth)
        self.c2 = _conv3(cin + growth, growth)
        self.c3 = _conv3(cin + 2 * growth, growth)
        self.out = _conv3(cin + 3 * growth, cout, k=1)

    def forward(self, x):
        o1 = self.c1(x)
        o2 = self.c2(torch.cat([x, o1], 1))
        o3 = self.c3(torch.cat([x, o1, o2], 1))
        return self.out(torch.cat([x, o1, o2, o3], 1))


class GMANet3D(nn.Module):
    name = "gmanet_3d"
    display_name = "GMANet 3D (gated multi-scale attention)"
    dim = 3
    speed = "slow"
    description = ("Educational 3D build of a gated multi-scale attention network: dense local-detail blocks in "
                   "the encoder, attention-GATED skip connections, and multi-scale channel attention in the "
                   "decoder. Heavier than the 3D U-Net — expect slower epochs on CPU.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=8):
        super().__init__()
        c = base_channels
        self.enc1 = _DenseLocalBlock3D(in_channels, c)
        self.enc2 = _DenseLocalBlock3D(c, c * 2)
        self.enc3 = _DenseLocalBlock3D(c * 2, c * 4)
        self.pool = nn.MaxPool3d(2)
        self.bottleneck = nn.Sequential(_double_conv3(c * 4, c * 8), _MultiScaleChannelAttention3D(c * 8))

        self.up3 = nn.ConvTranspose3d(c * 8, c * 4, 2, stride=2)
        self.gate3 = _AttentionGate3D(c * 4, c * 4, c * 2)
        self.dec3 = nn.Sequential(_conv3(c * 8, c * 4), _MultiScaleChannelAttention3D(c * 4))
        self.up2 = nn.ConvTranspose3d(c * 4, c * 2, 2, stride=2)
        self.gate2 = _AttentionGate3D(c * 2, c * 2, c)
        self.dec2 = nn.Sequential(_conv3(c * 4, c * 2), _MultiScaleChannelAttention3D(c * 2))
        self.up1 = nn.ConvTranspose3d(c * 2, c, 2, stride=2)
        self.gate1 = _AttentionGate3D(c, c, max(c // 2, 2))
        self.dec1 = nn.Sequential(_conv3(c * 2, c), _MultiScaleChannelAttention3D(c))
        self.out_conv = nn.Conv3d(c, out_channels, 1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        b = self.bottleneck(self.pool(e3))
        g3 = self.up3(b)
        d3 = self.dec3(torch.cat([g3, self.gate3(g3, e3)], 1))
        g2 = self.up2(d3)
        d2 = self.dec2(torch.cat([g2, self.gate2(g2, e2)], 1))
        g1 = self.up1(d2)
        d1 = self.dec1(torch.cat([g1, self.gate1(g1, e1)], 1))
        return self.out_conv(d1)


class LightVM3DUNet(LightVMUNet):
    name = "light_vm_unet_3d"
    display_name = "Light-VM3D-UNet (Mamba state-space, 3D)"
    dim = 3
    speed = "slow"
    description = ("The 3D version of Light-VM-UNet: Mamba-style state-space layers scan the flattened "
                   "volume in linear time to capture long-range context. Compact educational build that "
                   "runs on CPU; the stem halves resolution to keep the scan affordable.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=12):
        super().__init__(in_channels, out_channels, dim=3, base_channels=base_channels)
