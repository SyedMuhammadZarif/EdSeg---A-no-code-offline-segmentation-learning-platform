"""
Additional lightweight 2D architectures for EdSeg — deliberately NOT all
U-Nets, so students can compare genuinely different design ideas:

  * MobileUNet        — depth-wise separable convolutions (MobileNet idea)
  * AttentionUNet     — attention gates that filter what the skips carry
  * UNetPlusPlus      — nested, densely connected skip pathways (U-Net++)
  * LinkNetLite       — residual encoder with ADDITIVE skips (LinkNet idea)
  * DeepLabLite       — dilated "atrous" pyramid pooling (DeepLab idea)
  * LightVMUNet       — Mamba-style state-space blocks (Light-VM-UNet);
                        this same class also builds the 3D variant

Every model takes a single-channel image and returns single-channel logits
(before sigmoid), exactly like the original models in models.py, and is
kept small enough to train on a laptop CPU. These are compact, readable
re-implementations of each *idea* for teaching — not copies of the
research code, and they ship without pretrained weights.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from ssm import RVMLayer


def _conv_bn_relu(cin, cout, k=3):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, padding=k // 2, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


def _double_conv(cin, cout):
    return nn.Sequential(_conv_bn_relu(cin, cout), _conv_bn_relu(cout, cout))


# ---------------------------------------------------------------------------
# MobileUNet — depth-wise separable convolutions
# ---------------------------------------------------------------------------

def _separable(cin, cout):
    return nn.Sequential(
        nn.Conv2d(cin, cin, 3, padding=1, groups=cin, bias=False),
        nn.BatchNorm2d(cin),
        nn.ReLU6(inplace=True),
        nn.Conv2d(cin, cout, 1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU6(inplace=True),
    )


def _separable_block(cin, cout):
    return nn.Sequential(_separable(cin, cout), _separable(cout, cout))


class MobileUNet(nn.Module):
    name = "mobile_unet"
    display_name = "Mobile U-Net (depth-wise separable, very light)"
    dim = 2
    speed = "fastest"
    description = ("Replaces ordinary convolutions with depth-wise separable ones (the MobileNet trick): "
                   "far fewer parameters and calculations for similar accuracy. Built for phones and laptops.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=16):
        super().__init__()
        c = base_channels
        self.stem = _conv_bn_relu(in_channels, c)
        self.enc1 = _separable_block(c, c * 2)
        self.enc2 = _separable_block(c * 2, c * 4)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = _separable_block(c * 4, c * 8)
        self.up2 = nn.ConvTranspose2d(c * 8, c * 4, 2, stride=2)
        self.dec2 = _separable_block(c * 8, c * 4)
        self.up1 = nn.ConvTranspose2d(c * 4, c * 2, 2, stride=2)
        self.dec1 = _separable_block(c * 4, c * 2)
        self.up0 = nn.ConvTranspose2d(c * 2, c, 2, stride=2)
        self.dec0 = _separable_block(c * 2, c)
        self.out_conv = nn.Conv2d(c, out_channels, 1)

    def forward(self, x):
        s0 = self.stem(x)
        s1 = self.enc1(self.pool(s0))
        s2 = self.enc2(self.pool(s1))
        b = self.bottleneck(self.pool(s2))
        d2 = self.dec2(torch.cat([self.up2(b), s2], 1))
        d1 = self.dec1(torch.cat([self.up1(d2), s1], 1))
        d0 = self.dec0(torch.cat([self.up0(d1), s0], 1))
        return self.out_conv(d0)


# ---------------------------------------------------------------------------
# Attention U-Net
# ---------------------------------------------------------------------------

class AttentionGate(nn.Module):
    """Learns a 0-1 map telling the skip connection which regions matter."""

    def __init__(self, gate_ch, skip_ch, inter_ch):
        super().__init__()
        self.w_gate = nn.Sequential(nn.Conv2d(gate_ch, inter_ch, 1), nn.BatchNorm2d(inter_ch))
        self.w_skip = nn.Sequential(nn.Conv2d(skip_ch, inter_ch, 1), nn.BatchNorm2d(inter_ch))
        self.psi = nn.Sequential(nn.Conv2d(inter_ch, 1, 1), nn.BatchNorm2d(1), nn.Sigmoid())

    def forward(self, gate, skip):
        attn = self.psi(F.relu(self.w_gate(gate) + self.w_skip(skip), inplace=True))
        return skip * attn


class AttentionUNet(nn.Module):
    name = "attention_unet"
    display_name = "Attention U-Net (gated skips, small)"
    dim = 2
    speed = "fast"
    description = ("A small U-Net whose skip connections pass through 'attention gates' that learn to "
                   "suppress irrelevant background and highlight the structure of interest.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=12):
        super().__init__()
        c = base_channels
        self.enc1 = _double_conv(in_channels, c)
        self.enc2 = _double_conv(c, c * 2)
        self.enc3 = _double_conv(c * 2, c * 4)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = _double_conv(c * 4, c * 8)
        self.up3 = nn.ConvTranspose2d(c * 8, c * 4, 2, stride=2)
        self.att3 = AttentionGate(c * 4, c * 4, c * 2)
        self.dec3 = _double_conv(c * 8, c * 4)
        self.up2 = nn.ConvTranspose2d(c * 4, c * 2, 2, stride=2)
        self.att2 = AttentionGate(c * 2, c * 2, c)
        self.dec2 = _double_conv(c * 4, c * 2)
        self.up1 = nn.ConvTranspose2d(c * 2, c, 2, stride=2)
        self.att1 = AttentionGate(c, c, max(c // 2, 1))
        self.dec1 = _double_conv(c * 2, c)
        self.out_conv = nn.Conv2d(c, out_channels, 1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        b = self.bottleneck(self.pool(e3))
        g3 = self.up3(b)
        d3 = self.dec3(torch.cat([g3, self.att3(g3, e3)], 1))
        g2 = self.up2(d3)
        d2 = self.dec2(torch.cat([g2, self.att2(g2, e2)], 1))
        g1 = self.up1(d2)
        d1 = self.dec1(torch.cat([g1, self.att1(g1, e1)], 1))
        return self.out_conv(d1)


# ---------------------------------------------------------------------------
# U-Net++ (nested skips)
# ---------------------------------------------------------------------------

class UNetPlusPlus(nn.Module):
    name = "unet_plus_plus"
    display_name = "U-Net++ (nested skips, small)"
    dim = 2
    speed = "medium"
    description = ("Instead of one skip connection per level, U-Net++ fills the gap between encoder and "
                   "decoder with a grid of nested, densely connected convolutions.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=8):
        super().__init__()
        c = base_channels
        ch = [c, c * 2, c * 4, c * 8]
        self.pool = nn.MaxPool2d(2)
        self.x00 = _double_conv(in_channels, ch[0])
        self.x10 = _double_conv(ch[0], ch[1])
        self.x20 = _double_conv(ch[1], ch[2])
        self.x30 = _double_conv(ch[2], ch[3])
        self.up10 = nn.ConvTranspose2d(ch[1], ch[0], 2, stride=2)
        self.up20 = nn.ConvTranspose2d(ch[2], ch[1], 2, stride=2)
        self.up30 = nn.ConvTranspose2d(ch[3], ch[2], 2, stride=2)
        self.x01 = _double_conv(ch[0] * 2, ch[0])
        self.x11 = _double_conv(ch[1] * 2, ch[1])
        self.x21 = _double_conv(ch[2] * 2, ch[2])
        self.up11 = nn.ConvTranspose2d(ch[1], ch[0], 2, stride=2)
        self.up21 = nn.ConvTranspose2d(ch[2], ch[1], 2, stride=2)
        self.x02 = _double_conv(ch[0] * 3, ch[0])
        self.x12 = _double_conv(ch[1] * 3, ch[1])
        self.up12 = nn.ConvTranspose2d(ch[1], ch[0], 2, stride=2)
        self.x03 = _double_conv(ch[0] * 4, ch[0])
        self.out_conv = nn.Conv2d(ch[0], out_channels, 1)

    def forward(self, x):
        x00 = self.x00(x)
        x10 = self.x10(self.pool(x00))
        x20 = self.x20(self.pool(x10))
        x30 = self.x30(self.pool(x20))
        x01 = self.x01(torch.cat([x00, self.up10(x10)], 1))
        x11 = self.x11(torch.cat([x10, self.up20(x20)], 1))
        x21 = self.x21(torch.cat([x20, self.up30(x30)], 1))
        x02 = self.x02(torch.cat([x00, x01, self.up11(x11)], 1))
        x12 = self.x12(torch.cat([x10, x11, self.up21(x21)], 1))
        x03 = self.x03(torch.cat([x00, x01, x02, self.up12(x12)], 1))
        return self.out_conv(x03)


# ---------------------------------------------------------------------------
# LinkNet-lite (residual encoder, additive skips)
# ---------------------------------------------------------------------------

class _ResBlock(nn.Module):
    def __init__(self, cin, cout, stride):
        super().__init__()
        self.conv1 = nn.Sequential(nn.Conv2d(cin, cout, 3, stride, 1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))
        self.conv2 = nn.Sequential(nn.Conv2d(cout, cout, 3, 1, 1, bias=False), nn.BatchNorm2d(cout))
        self.shortcut = (nn.Identity() if (cin == cout and stride == 1)
                         else nn.Sequential(nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout)))

    def forward(self, x):
        return F.relu(self.conv2(self.conv1(x)) + self.shortcut(x), inplace=True)


class _LinkDecoder(nn.Module):
    """LinkNet decoder block: 1x1 squeeze -> transposed conv x2 -> 1x1 expand."""

    def __init__(self, cin, cout):
        super().__init__()
        mid = max(cin // 4, 4)
        self.block = nn.Sequential(
            nn.Conv2d(cin, mid, 1, bias=False), nn.BatchNorm2d(mid), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(mid, mid, 2, stride=2, bias=False), nn.BatchNorm2d(mid), nn.ReLU(inplace=True),
            nn.Conv2d(mid, cout, 1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class LinkNetLite(nn.Module):
    name = "linknet_lite"
    display_name = "LinkNet-Lite (residual, additive skips)"
    dim = 2
    speed = "fast"
    description = ("A residual encoder (like a tiny ResNet) with decoder blocks that ADD, rather than "
                   "concatenate, the encoder features — fewer parameters and very quick to train.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=12):
        super().__init__()
        c = base_channels
        self.stem = nn.Sequential(nn.Conv2d(in_channels, c, 3, padding=1, bias=False), nn.BatchNorm2d(c), nn.ReLU(inplace=True))
        self.enc1 = _ResBlock(c, c * 2, 2)
        self.enc2 = _ResBlock(c * 2, c * 4, 2)
        self.enc3 = _ResBlock(c * 4, c * 8, 2)
        self.dec3 = _LinkDecoder(c * 8, c * 4)
        self.dec2 = _LinkDecoder(c * 4, c * 2)
        self.dec1 = _LinkDecoder(c * 2, c)
        self.head = nn.Sequential(nn.Conv2d(c, c, 3, padding=1, bias=False), nn.BatchNorm2d(c), nn.ReLU(inplace=True),
                                  nn.Conv2d(c, out_channels, 1))

    def forward(self, x):
        s0 = self.stem(x)
        e1 = self.enc1(s0)
        e2 = self.enc2(e1)
        e3 = self.enc3(e2)
        d3 = self.dec3(e3) + e2
        d2 = self.dec2(d3) + e1
        d1 = self.dec1(d2) + s0
        return self.head(d1)


# ---------------------------------------------------------------------------
# DeepLab-lite (atrous spatial pyramid pooling)
# ---------------------------------------------------------------------------

class _ASPP(nn.Module):
    def __init__(self, cin, cout, rates=(1, 2, 4)):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Sequential(nn.Conv2d(cin, cout, 3, padding=r, dilation=r, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))
            for r in rates
        ])
        self.pool_branch = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(cin, cout, 1, bias=False), nn.ReLU(inplace=True))
        self.project = nn.Sequential(nn.Conv2d(cout * (len(rates) + 1), cout, 1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))

    def forward(self, x):
        outs = [b(x) for b in self.branches]
        pooled = self.pool_branch(x)
        outs.append(pooled.expand(-1, -1, x.shape[2], x.shape[3]))
        return self.project(torch.cat(outs, 1))


class DeepLabLite(nn.Module):
    name = "deeplab_lite"
    display_name = "DeepLab-Lite (dilated pyramid, small)"
    dim = 2
    speed = "fast"
    description = ("Looks at the image at several scales at once using dilated ('atrous') convolutions "
                   "in parallel, then merges them — a different way to capture context than a U-Net's skips.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=16):
        super().__init__()
        c = base_channels
        self.low = nn.Sequential(_conv_bn_relu(in_channels, c), _conv_bn_relu(c, c))
        self.down1 = nn.Sequential(nn.MaxPool2d(2), _conv_bn_relu(c, c * 2), _conv_bn_relu(c * 2, c * 2))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), _conv_bn_relu(c * 2, c * 4), _conv_bn_relu(c * 4, c * 4))
        self.aspp = _ASPP(c * 4, c * 4)
        self.low_reduce = nn.Sequential(nn.Conv2d(c * 2, c, 1, bias=False), nn.BatchNorm2d(c), nn.ReLU(inplace=True))
        self.fuse = nn.Sequential(_conv_bn_relu(c * 4 + c, c * 2), _conv_bn_relu(c * 2, c * 2))
        self.out_conv = nn.Conv2d(c * 2 + c, out_channels, 1)

    def forward(self, x):
        l0 = self.low(x)
        l1 = self.down1(l0)
        deep = self.aspp(self.down2(l1))
        deep = F.interpolate(deep, size=l1.shape[2:], mode="bilinear", align_corners=False)
        mid = self.fuse(torch.cat([deep, self.low_reduce(l1)], 1))
        mid = F.interpolate(mid, size=l0.shape[2:], mode="bilinear", align_corners=False)
        return self.out_conv(torch.cat([mid, l0], 1))


# ---------------------------------------------------------------------------
# Light-VM-UNet (2D and 3D) — Mamba-style state-space blocks
# ---------------------------------------------------------------------------

def _nd(dim):
    if dim == 2:
        return nn.Conv2d, nn.MaxPool2d, "bilinear"
    return nn.Conv3d, nn.MaxPool3d, "trilinear"


class _DecoderBlock(nn.Module):
    """Upsample, ADD the skip (as LightM-UNet does), depth-wise conv with a learnable residual, ReLU."""

    def __init__(self, dim, in_channels, out_channels):
        super().__init__()
        conv, _, self.mode = _nd(dim)
        self.dw = conv(in_channels, in_channels, 3, padding=1, groups=in_channels)
        self.scale = nn.Parameter(torch.ones(1))
        self.project = conv(in_channels, out_channels, 1)

    def forward(self, x, skip):
        x = F.interpolate(x, size=skip.shape[2:], mode=self.mode, align_corners=False)
        x = x + skip
        x = F.relu(self.dw(x) + self.scale * x)
        return self.project(x)


class LightVMUNet(nn.Module):
    """
    Light-VM-UNet: a U-Net whose convolutional/attention blocks are replaced
    by Residual Vision-Mamba (RVM) layers, which model long-range context in
    LINEAR time. Follows the LightM-UNet layout (stem -> 3 encoder blocks
    -> RVM bottleneck -> 3 additive-skip decoder blocks) at a much smaller
    width, and runs in pure PyTorch so it works on CPU.

    dim=2 builds the 2D version, dim=3 the 3D version (volumes).
    """

    def __init__(self, in_channels=1, out_channels=1, dim=2, base_channels=16, depths=(1, 1, 2)):
        super().__init__()
        self.dim = dim
        conv, pool, self.mode = _nd(dim)
        c = base_channels
        # The stem halves the resolution so the state-space scan runs over 4x
        # (2D) or 8x (3D) fewer tokens — this is what keeps CPU training fast.
        self.stem = nn.Sequential(conv(in_channels, c, 3, stride=2, padding=1), nn.ReLU(inplace=True),
                                  conv(c, c, 3, padding=1, groups=c), conv(c, c, 1))
        self.pool = pool(2)

        self.encoders = nn.ModuleList()
        for i, n_layers in enumerate(depths):
            cin, cout = c * 2 ** i, c * 2 ** (i + 1)
            layers = [RVMLayer(cin, cin, state_dim=4) for _ in range(n_layers - 1)]
            layers.append(RVMLayer(cin, cout, state_dim=4))
            self.encoders.append(nn.Sequential(*layers))

        top = c * 2 ** len(depths)
        self.bottleneck = nn.Sequential(RVMLayer(top, top, state_dim=4), RVMLayer(top, top, state_dim=4))
        self.decoders = nn.ModuleList([
            _DecoderBlock(dim, c * 2 ** (i + 1), c * 2 ** i) for i in reversed(range(len(depths)))
        ])
        self.head = nn.Sequential(conv(c, c, 3, padding=1, groups=c), conv(c, out_channels, 1))

    def forward(self, x):
        size = x.shape[2:]
        x = self.stem(x)
        skips = []
        for i, enc in enumerate(self.encoders):
            x = enc(x)
            skips.append(x)
            if i < len(self.encoders) - 1:
                x = self.pool(x)
        x = self.bottleneck(self.pool(x))
        for dec, skip in zip(self.decoders, reversed(skips)):
            x = dec(x, skip)
        x = self.head(x)
        return F.interpolate(x, size=size, mode=self.mode, align_corners=False)


class LightVM2DUNet(LightVMUNet):
    name = "light_vm_unet_2d"
    display_name = "Light-VM2D-UNet (Mamba state-space, light)"
    dim = 2
    speed = "medium"
    description = ("Replaces the U-Net's convolution blocks with Mamba-style state-space layers that read "
                   "the image as a sequence — long-range context at linear cost. A compact educational "
                   "version of Light-VM-UNet / LightM-UNet; runs on CPU.")

    def __init__(self, in_channels=1, out_channels=1, base_channels=16):
        super().__init__(in_channels, out_channels, dim=2, base_channels=base_channels)
