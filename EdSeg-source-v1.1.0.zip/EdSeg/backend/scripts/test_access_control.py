"""
Access-control checks against a REAL running server (so cookies, redirects and the
Host header behave exactly as they do for the app window).

    python backend/scripts/test_access_control.py

Starts backend/app.py with a known token on a free port, then verifies:
  * the API refuses requests that lack the session cookie (other programs, other sites)
  * a cross-site style POST is refused (CSRF)
  * a wrong Host header is refused (DNS rebinding)
  * opening /?k=<token> sets an HttpOnly + SameSite=Strict cookie and then everything works
  * the security headers (CSP etc.) are present, and the UI makes no CSP-violating requests
"""

import http.client
import json
import os
import socket
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(os.path.dirname(HERE), "app.py")
TOKEN = "unit-test-token-" + "x" * 24

with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    PORT = s.getsockname()[1]

scratch = tempfile.mkdtemp(prefix="edseg_ac_", dir=os.environ.get("TEMP"))
env = dict(os.environ, EDSEG_TOKEN=TOKEN, EDSEG_PORT=str(PORT), EDSEG_DATA_DIR=scratch)
server = subprocess.Popen([sys.executable, APP], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

failures = []


def check(label, ok, extra=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {label} {extra}")
    if not ok:
        failures.append(label)


def request(method, path, headers=None, body=None, host=None):
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
    h = {"Host": host or f"127.0.0.1:{PORT}"}
    h.update(headers or {})
    conn.request(method, path, body=body, headers=h)
    r = conn.getresponse()
    data = r.read()
    out = (r.status, dict((k.lower(), v) for k, v in r.getheaders()), data)
    conn.close()
    return out


try:
    for _ in range(60):
        try:
            request("GET", "/api/ping"); break
        except OSError:
            time.sleep(0.5)

    status, _, _ = request("GET", "/api/ping")
    check("/api/ping stays open for the launcher's readiness check", status == 200)

    status, _, _ = request("GET", "/api/datasets")
    check("API refuses a request with no session cookie (another program)", status == 403)
    status, _, _ = request("GET", "/")
    check("the page itself refuses a request with no cookie or key", status == 403)
    status, _, _ = request("GET", "/?k=wrong-key")
    check("a wrong key is refused", status == 403)

    status, _, _ = request("POST", "/api/train/start", {"Origin": "http://evil.example", "Content-Type": "text/plain"},
                           json.dumps({"dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet", "epochs": 1}))
    check("a cross-site style POST (text/plain, foreign Origin) is refused", status == 403)

    status, _, body = request("GET", "/api/ping", host="attacker.example")
    check("a foreign Host header (DNS rebinding) is refused", status == 400, body[:60].decode(errors="ignore"))
    status, _, _ = request("GET", f"/?k={TOKEN}", host=f"evil.example:{PORT}")
    check("...even with the right key", status == 400)

    status, headers, _ = request("GET", f"/?k={TOKEN}")
    cookie = headers.get("set-cookie", "")
    check("the right key redirects to a clean URL", status == 302 and headers.get("location") == "/")
    check("...and sets an HttpOnly, SameSite=Strict cookie", "HttpOnly" in cookie and "SameSite=Strict" in cookie, cookie[:60] + "...")
    session = cookie.split(";")[0]

    status, headers, _ = request("GET", "/", {"Cookie": session})
    check("the page loads with the cookie", status == 200)
    status, _, body = request("GET", "/api/datasets", {"Cookie": session})
    check("the API works with the cookie", status == 200 and b"sample_shapes" in body)
    status, _, _ = request("GET", "/js/app.js", {"Cookie": session})
    check("static files load with the cookie", status == 200)

    csp = headers.get("content-security-policy", "")
    check("Content-Security-Policy present and blocks external scripts", "script-src 'self'" in csp and "frame-ancestors 'none'" in csp)
    check("X-Content-Type-Options / X-Frame-Options / Referrer-Policy present",
          headers.get("x-content-type-options") == "nosniff" and headers.get("x-frame-options") == "DENY" and headers.get("referrer-policy") == "no-referrer")
    _, api_headers, _ = request("GET", "/api/datasets", {"Cookie": session})
    check("API responses are not cacheable", api_headers.get("cache-control") == "no-store")

    # The app must not rely on anything the CSP forbids: scan the shipped frontend for inline scripts / external URLs.
    frontend = os.path.join(os.path.dirname(os.path.dirname(HERE)), "frontend")
    html = open(os.path.join(frontend, "index.html"), encoding="utf-8").read()
    import re
    inline = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>", html)
    handlers = re.findall(r"\son(?:click|load|error|change)=", html)
    external = re.findall(r"(?:src|href)=[\"']https?://", html)
    check("index.html has no inline scripts, inline event handlers or external resources", not inline and not handlers and not external,
          f"inline={len(inline)} handlers={len(handlers)} external={len(external)}")
finally:
    server.terminate()

print("\n" + "=" * 50)
print("ALL CHECKS PASSED" if not failures else f"{len(failures)} CHECK(S) FAILED: {failures}")
sys.exit(1 if failures else 0)
