"""
Generate the bundled synthetic 3D sample dataset (datasets/sample_blobs_3d).

Each volume is a 40x48x48 (depth x height x width) scan with one or two bright
ellipsoids ("lesions") of varying size, position and brightness on a smooth
gradient background plus noise; the mask marks the ellipsoids. It is tiny
(a couple of MB in total), trains in seconds on a CPU, and is meant purely for
learning how 3D segmentation works — it is not medical data.

    python backend/scripts/generate_sample_volumes.py
"""

import os
import numpy as np
import nibabel as nib

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "datasets", "sample_blobs_3d")
COUNT = 24
SHAPE = (40, 48, 48)  # depth, height, width


def make_case(rng):
    d, h, w = SHAPE
    zz, yy, xx = np.meshgrid(np.arange(d), np.arange(h), np.arange(w), indexing="ij")
    background = 0.15 + 0.1 * (xx / w) + 0.05 * (yy / h)
    mask = np.zeros(SHAPE, dtype=bool)
    image = background.astype(np.float32)
    for _ in range(int(rng.integers(1, 3))):
        c = [rng.uniform(0.3, 0.7) * s for s in SHAPE]
        r = [rng.uniform(0.10, 0.22) * s for s in SHAPE]
        blob = (((zz - c[0]) / r[0]) ** 2 + ((yy - c[1]) / r[1]) ** 2 + ((xx - c[2]) / r[2]) ** 2) <= 1.0
        mask |= blob
        image[blob] += rng.uniform(0.35, 0.6)
    image += rng.normal(0, 0.06, SHAPE).astype(np.float32)
    return np.clip(image * 255, 0, 255).astype(np.uint8), mask.astype(np.uint8)  # 8-bit keeps the file small


def main():
    rng = np.random.default_rng(7)
    os.makedirs(os.path.join(OUT, "images"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "masks"), exist_ok=True)
    affine = np.diag([1.0, 1.0, 1.0, 1.0])
    for i in range(COUNT):
        image, mask = make_case(rng)
        # NIfTI stores (x, y, z): transpose from (depth, height, width) to match how EdSeg reads it back.
        nib.save(nib.Nifti1Image(image.transpose(2, 1, 0), affine), os.path.join(OUT, "images", f"blobs_{i:03d}.nii.gz"))
        nib.save(nib.Nifti1Image(mask.transpose(2, 1, 0), affine), os.path.join(OUT, "masks", f"blobs_{i:03d}.nii.gz"))
    print(f"wrote {COUNT} volumes to {OUT}")


if __name__ == "__main__":
    main()
