"""
End-to-end check against REAL public datasets (downloaded separately; see
tools/prepare_datasets.py). Skips cleanly if they are not present.

    python backend/scripts/test_real_datasets.py [--datasets D:/Edseg/test_datasets] [--quick]

For each dataset it uploads the prepared zip through the real API, previews
it, trains for a couple of epochs, fetches Results, saves the model and runs
single-case and full-dataset inference. Uses EDSEG_DATA_DIR so nothing is
written into the project folder.
"""

import argparse
import io
import os
import sys
import tempfile
import time

parser = argparse.ArgumentParser()
parser.add_argument("--datasets", default=r"D:\Edseg\test_datasets")
parser.add_argument("--quick", action="store_true", help="fewer epochs/cases")
args = parser.parse_args()

scratch = os.path.join(os.path.dirname(os.path.abspath(args.datasets)), "_scratch_realdata_test")
import shutil
shutil.rmtree(scratch, ignore_errors=True)  # always start clean so saved-model names never collide with an earlier run
os.environ["EDSEG_DATA_DIR"] = scratch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402

client = app.test_client()
failures = []


def check(label, ok, extra=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {label} {extra}")
    if not ok:
        failures.append(label)


def wait_done(run_id, timeout=3600):
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = client.get(f"/api/train/status/{run_id}").get_json()
        if st["status"] in ("completed", "stopped", "error"):
            return st
        time.sleep(0.5)
    raise TimeoutError(run_id)


def run_case(zip_name, dataset_name, models, epochs, subset, expect_dim, image_size=None, batch=4):
    zip_path = os.path.join(args.datasets, zip_name)
    if not os.path.exists(zip_path):
        print(f"-- skipping {zip_name} (not found)")
        return
    print(f"\n=== {dataset_name} ({expect_dim}D) ===")
    with open(zip_path, "rb") as f:
        r = client.post("/api/datasets/upload", data={"file": (io.BytesIO(f.read()), zip_name), "name": dataset_name},
                        content_type="multipart/form-data")
    body = r.get_json()
    check("upload accepted", r.status_code == 200, str(body)[:120])
    if r.status_code != 200:
        return
    ds = body["dataset"]
    check("dataset kind detected", ds["dim"] == expect_dim, f"(kind={ds['kind']}, count={ds['count']})")

    r = client.get(f"/api/datasets/{dataset_name}/preview?source=custom&count=4")
    pv = r.get_json()
    check("preview returns 4 pairs", r.status_code == 200 and len(pv["pairs"]) == 4)

    for model in models:
        t0 = time.time()
        r = client.post("/api/train/start", json={
            "dataset_name": dataset_name, "dataset_source": "custom", "model_name": model,
            "learning_rate": 0.005, "epochs": epochs, "batch_size": batch, "val_split": 0.2,
            "subset_size": subset, "image_size": image_size, "device_preference": "cpu"})
        check(f"{model}: training starts", r.status_code == 200, str(r.get_json())[:150])
        if r.status_code != 200:
            continue
        st = wait_done(r.get_json()["run_id"])
        check(f"{model}: training completed", st["status"] == "completed", (st.get("error") or "")[:300])
        if st["status"] != "completed":
            continue
        m = st["metrics_so_far"]
        check(f"{model}: {len(m)} epochs, loss {m[0]['train_loss']:.3f} -> {m[-1]['train_loss']:.3f}, "
              f"val dice {m[-1]['val_dice']:.3f} ({time.time() - t0:.0f}s)", len(m) == epochs)
        check(f"{model}: live preview produced", st["latest_preview"] is not None)
        ckpt = st["final_result"]["checkpoint_paths"][-1]

        r = client.get("/api/results", query_string={"checkpoint_path": ckpt})
        res = r.get_json()
        check(f"{model}: results computed", r.status_code == 200 and res["sample_predictions"], str(res)[:100] if r.status_code != 200 else "")
        if r.status_code == 200:
            kinds = {s.get("kind") for s in res["sample_predictions"]}
            check(f"{model}: sample kind matches data", kinds == ({"volume"} if expect_dim == 3 else {"image"}), str(kinds))

        safe = f"{model}_{dataset_name}".replace("-", "_")[:40]
        r = client.post("/api/model/save", json={"checkpoint_path": ckpt, "name": safe})
        check(f"{model}: saved to library", r.status_code == 200, str(r.get_json())[:100])

    # inference on the whole dataset with the last saved model
    if models:
        safe = f"{models[-1]}_{dataset_name}".replace("-", "_")[:40]
        r = client.post("/api/inference/dataset", json={"model_name": safe, "dataset_name": dataset_name,
                                                          "dataset_source": "custom", "device_preference": "cpu"})
        d = r.get_json()
        check("full-dataset inference", r.status_code == 200 and d["total_images_tested"] == ds["count"], str(d)[:120] if r.status_code != 200 else f"(dice {d['confusion_matrix']['dice']:.3f})")

        # single-case inference using the first case on disk
        folder = os.path.join(scratch, "datasets", "custom", dataset_name)
        img = sorted(os.listdir(os.path.join(folder, "images")))[0]
        base = os.path.join(folder, "images", img)
        msk = os.path.join(folder, "masks", sorted(os.listdir(os.path.join(folder, "masks")))[0])
        with open(base, "rb") as fi, open(msk, "rb") as fm:
            r = client.post("/api/inference", data={"model_name": safe, "image": (io.BytesIO(fi.read()), img),
                                                     "mask": (io.BytesIO(fm.read()), os.path.basename(msk)),
                                                     "device_preference": "cpu"}, content_type="multipart/form-data")
        d = r.get_json()
        check("single-case inference with ground truth", r.status_code == 200 and "dice" in d, str(d)[:150] if r.status_code != 200 else f"(dice {d['dice']:.3f})")

        # a 3D model must reject a 2D picture and vice-versa with a clear message
        wrong = (io.BytesIO(b"x"), "wrong.png") if expect_dim == 3 else (io.BytesIO(b"x"), "wrong.nii.gz")
        r = client.post("/api/inference", data={"model_name": safe, "image": wrong}, content_type="multipart/form-data")
        check("wrong file kind rejected with a 400", r.status_code == 400, str(r.get_json())[:140])

    r = client.delete(f"/api/datasets/{dataset_name}")
    check("custom dataset deleted", r.status_code == 200)


E = 2 if args.quick else 3
run_case("kvasir_seg.zip", "kvasir_test", ["mini_unet", "mobile_unet", "linknet_lite", "attention_unet", "deeplab_lite",
                                            "unet_plus_plus", "light_vm_unet_2d"] if not args.quick else ["mini_unet", "light_vm_unet_2d"],
         E, 60, 2, image_size=96, batch=8)
run_case("hippocampus_3d.zip", "hippo_test", ["unet3d_lite", "light_vm_unet_3d", "gmanet_3d"] if not args.quick else ["unet3d_lite"],
         E, 24, 3, image_size=32, batch=2)

print("\n" + "=" * 50)
print("ALL CHECKS PASSED" if not failures else f"{len(failures)} CHECK(S) FAILED: {failures}")
sys.exit(1 if failures else 0)
