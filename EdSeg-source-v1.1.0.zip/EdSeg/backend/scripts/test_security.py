"""
Security / robustness checks for file paths that arrive over the API.

A student's computer runs EdSeg's local server, so every path or name in a
request must be confined to the folders EdSeg manages. This script tries the
classic escapes and confirms each one is refused with a clear error.

    python backend/scripts/test_security.py
"""

import io
import os
import sys
import tempfile

scratch = tempfile.mkdtemp(prefix="edseg_sec_", dir=os.environ.get("TEMP"))
os.environ["EDSEG_DATA_DIR"] = scratch
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402

client = app.test_client()
failures = []


def check(label, ok, extra=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {label} {extra}")
    if not ok:
        failures.append(label)


outside = os.path.join(tempfile.gettempdir(), "not_a_checkpoint.pt")
with open(outside, "wb") as f:
    f.write(b"not a real checkpoint")

r = client.get("/api/results", query_string={"checkpoint_path": outside})
check("results refuses a checkpoint outside the checkpoints folder", r.status_code == 400, r.get_json()["error"][:70])

r = client.post("/api/checkpoints/delete", json={"checkpoint_path": outside})
check("delete refuses a path outside the checkpoints folder", r.status_code == 400 and os.path.exists(outside))

r = client.post("/api/model/save", json={"checkpoint_path": outside, "name": "evil"})
check("save-model refuses a checkpoint outside the checkpoints folder", r.status_code == 400)

r = client.post("/api/train/resume", json={"checkpoint_path": outside})
check("resume refuses a checkpoint outside the checkpoints folder", r.status_code in (400, 404))

for bad in ("..\\..\\evil", "../evil", "a/b", "x.y", ""):
    r = client.post("/api/inference", data={"model_name": bad, "image": (io.BytesIO(b"x"), "a.png")},
                    content_type="multipart/form-data")
    check(f"inference rejects model name {bad!r}", r.status_code in (400, 404))

r = client.get("/api/datasets/..%5Cevil/preview?source=custom")
check("preview rejects a traversal dataset name", r.status_code in (400, 404))
r = client.get("/api/datasets/sample_shapes/preview?source=bogus")
check("preview rejects an unknown source", r.status_code == 400)
r = client.delete("/api/datasets/sample_shapes")
check("bundled datasets cannot be deleted", r.status_code in (400, 404))
r = client.delete("/api/datasets/..%5C..%5Cevil")
check("dataset delete rejects traversal", r.status_code in (400, 404))

r = client.get("/api/reports/..%5C..%5Csecret.json")
check("report download rejects traversal", r.status_code == 404)
r = client.get("/api/sweeps/..%5C..%5Cevil")
check("sweep lookup rejects traversal", r.status_code in (400, 404))

# Oversized upload gets a friendly JSON error instead of a stack trace
app.config["MAX_CONTENT_LENGTH"] = 1024
r = client.post("/api/datasets/upload", data={"name": "big", "file": (io.BytesIO(b"x" * 5000), "big.zip")},
                content_type="multipart/form-data")
check("oversized upload -> 413 with a readable message", r.status_code == 413 and "too large" in r.get_json()["error"].lower())

# A 3D model refuses a 2D picture and the reverse, with a clear message
import torch  # noqa: E402
import models  # noqa: E402
import model_library  # noqa: E402
from train import save_checkpoint, CHECKPOINTS_ROOT  # noqa: E402

m = models.build_model("unet3d_lite")
opt = torch.optim.Adam(m.parameters())
cfg = {"architecture": "unet3d_lite", "dataset_name": "sample_blobs_3d", "dataset_source": "bundled", "learning_rate": 0.001,
       "batch_size": 2, "val_split": 0.2, "subset_size": None, "image_size": 32, "dim": 3, "total_pairs_used": 24, "seed": 1}
path = save_checkpoint("sec_run", 1, m, opt, cfg, [{"epoch": 1, "train_loss": 0.5, "val_loss": 0.5, "val_dice": 0.5, "val_iou": 0.3}])
r = client.post("/api/model/save", json={"checkpoint_path": path, "name": "sec3d"})
check("a checkpoint inside the folder can be saved", r.status_code == 200)
r = client.post("/api/inference", data={"model_name": "sec3d", "image": (io.BytesIO(b"x"), "photo.png")}, content_type="multipart/form-data")
check("3D model refuses a 2D picture", r.status_code == 400, r.get_json().get("error", "")[:70])
r = client.post("/api/train/start", json={"dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "unet3d_lite", "epochs": 1})
check("3D model on a 2D dataset is refused up front", r.status_code == 400 or (r.status_code == 200), r.get_json().get("error", "")[:90] if r.status_code != 200 else "(accepted; will error in job)")
if r.status_code == 200:  # starting is allowed to be asynchronous; the job must fail with a clear message
    import time
    rid = r.get_json()["run_id"]
    for _ in range(50):
        st = client.get(f"/api/train/status/{rid}").get_json()
        if st["status"] != "running":
            break
        time.sleep(0.2)
    check("...and the job reports a readable dimension error", st["status"] == "error" and "3D model" in st["error"], st["error"].split("\n")[0][:90])

print("\n" + "=" * 50)
print("ALL CHECKS PASSED" if not failures else f"{len(failures)} CHECK(S) FAILED: {failures}")
sys.exit(1 if failures else 0)
