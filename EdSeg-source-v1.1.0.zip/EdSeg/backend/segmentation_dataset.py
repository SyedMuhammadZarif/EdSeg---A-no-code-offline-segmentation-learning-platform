"""
PyTorch Datasets for 2D (image) and 3D (volume) segmentation pairs.

Builds on top of dataset_utils (Stage 1) — reuses the same validation
logic so training always operates on already-confirmed-valid data.
"""

import os
import random
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader

import dataset_utils
import volume_utils


class SegmentationDataset(Dataset):
    """
    Loads (image, mask) pairs from a validated dataset folder, resizing to
    a fixed square size and normalizing to [0, 1]. Masks are binarized
    (threshold 0.5) so this currently supports binary segmentation.
    """

    def __init__(self, dataset_path, pairs, image_size=128):
        self.dataset_path = dataset_path
        self.pairs = pairs
        self.image_size = image_size
        self.images_dir = os.path.join(dataset_path, "images")
        self.masks_dir = os.path.join(dataset_path, "masks")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img_name, mask_name = self.pairs[idx]

        img = Image.open(os.path.join(self.images_dir, img_name)).convert("L")
        mask = Image.open(os.path.join(self.masks_dir, mask_name)).convert("L")

        img = img.resize((self.image_size, self.image_size), Image.BILINEAR)
        mask = mask.resize((self.image_size, self.image_size), Image.NEAREST)

        img_arr = np.asarray(img, dtype=np.float32) / 255.0
        mask_arr = (np.asarray(mask, dtype=np.float32) / 255.0 > 0.5).astype(np.float32)

        img_tensor = torch.from_numpy(img_arr).unsqueeze(0)   # (1, H, W)
        mask_tensor = torch.from_numpy(mask_arr).unsqueeze(0)  # (1, H, W)

        return img_tensor, mask_tensor


class VolumeDataset(Dataset):
    """
    3D counterpart of SegmentationDataset: loads (volume, mask) pairs of
    .nii/.nii.gz/.npy files, normalises intensities, and resizes both to a
    cube of side `volume_size`. Items are (1, S, S, S) tensors. Preprocessed
    volumes are cached (see volume_utils) so later epochs are fast.
    """

    def __init__(self, dataset_path, pairs, volume_size=48):
        self.pairs = pairs
        self.volume_size = volume_utils.normalize_volume_size(volume_size)
        self.images_dir = os.path.join(dataset_path, "images")
        self.masks_dir = os.path.join(dataset_path, "masks")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img_name, mask_name = self.pairs[idx]
        image = volume_utils.load_volume(os.path.join(self.images_dir, img_name), self.volume_size, is_mask=False)
        mask = volume_utils.load_volume(os.path.join(self.masks_dir, mask_name), self.volume_size, is_mask=True)
        return image, mask


def build_dataloaders(dataset_name, dataset_source, image_size=128, batch_size=8,
                       val_split=0.2, subset_size=None, seed=42):
    """
    Resolve a dataset by name/source, optionally take a random subset,
    split into train/val, and return (train_loader, val_loader, total_pairs_used).
    For 3D datasets `image_size` is the side length of the cube volumes are
    resized to. Works for both 2D image datasets and 3D volume datasets.
    """
    dataset_path = dataset_utils.resolve_dataset_path(dataset_name, dataset_source)
    pairs = dataset_utils.validate_dataset_folder(dataset_path)  # raises if invalid

    rng = random.Random(seed)
    shuffled = pairs[:]
    rng.shuffle(shuffled)

    if subset_size is not None and subset_size < len(shuffled):
        shuffled = shuffled[:subset_size]

    val_count = max(1, int(len(shuffled) * val_split)) if len(shuffled) > 1 else 0
    val_pairs = shuffled[:val_count]
    train_pairs = shuffled[val_count:]

    if len(train_pairs) == 0:
        raise ValueError("Not enough images to form a training set after applying the validation split.")

    if dataset_utils.dataset_kind(dataset_path) == "3d":
        train_ds = VolumeDataset(dataset_path, train_pairs, volume_size=image_size)
        val_ds = VolumeDataset(dataset_path, val_pairs, volume_size=image_size) if val_pairs else None
    else:
        train_ds = SegmentationDataset(dataset_path, train_pairs, image_size=image_size)
        val_ds = SegmentationDataset(dataset_path, val_pairs, image_size=image_size) if val_pairs else None

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False) if val_ds else None

    return train_loader, val_loader, len(shuffled)
