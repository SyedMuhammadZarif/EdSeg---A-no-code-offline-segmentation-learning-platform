"""
Core training loop for SegLearn — Stage 3, extended in Stage 4 with
resume-from-checkpoint support.

Trains a chosen model on a chosen dataset with given hyperparameters,
tracks per-epoch metrics, and saves a checkpoint every N epochs (default
5) plus always at the final epoch. Checkpoints store everything needed
to resume later: model weights, optimizer state, and the full config
(architecture, dataset, hyperparameters).

This module has no Flask/API dependency — it's callable directly as a
function, which is what the test scripts do, and what the Stage 5 API
layer will wrap.
"""

import os
import io
import base64
import time
import uuid
import random
import copy
import gc
import json
import math
import numpy as np
from PIL import Image
import torch
import torch.optim as optim

import models as model_defs
from segmentation_dataset import build_dataloaders
from losses_metrics import BCEDiceLoss, dice_score, iou_score
from device_utils import resolve_device
import dataset_utils
import volume_utils

from paths import get_persistent_data_root, resolve_inside

CHECKPOINTS_ROOT = os.path.join(get_persistent_data_root(), "checkpoints")

# Hard ceiling on how many epochs a single training run can request,
# enforced server-side (not just as a UI slider limit) so it can't be
# bypassed by calling the API directly.
MAX_EPOCHS = 100

# Default working resolution per kind of data. 2D images are resized to a
# square of this side; 3D volumes to a cube (kept small so CPU training of
# volumes stays practical).
DEFAULT_IMAGE_SIZE_2D = 128
DEFAULT_VOLUME_SIZE_3D = 48
MIN_IMAGE_SIZE_2D, MAX_IMAGE_SIZE_2D = 32, 256


class CheckpointMismatchError(Exception):
    """Raised when a resume request's architecture/dataset doesn't match the checkpoint."""
    pass


def _tensor_to_base64_image(tensor_2d):
    """Convert a single-channel (H, W) tensor in [0, 1] to a base64 PNG data URL."""
    arr = (tensor_2d.detach().cpu().numpy() * 255).clip(0, 255).astype(np.uint8)
    im = Image.fromarray(arr, mode="L")
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def _make_preview(images, masks, probs):
    """
    Live-preview payload for the first sample of a validation batch. For 3D
    volumes this is the axial slice that contains the most foreground.
    """
    if images.dim() == 5:
        k = volume_utils.best_slice_index(masks[0, 0].detach().cpu().numpy())
        return {
            "image": _tensor_to_base64_image(_normalise_for_display(images[0, 0, k])),
            "ground_truth": _tensor_to_base64_image(masks[0, 0, k]),
            "prediction": _tensor_to_base64_image((probs[0, 0, k] > 0.5).float()),
            "slice_index": int(k),
            "depth": int(images.shape[2]),
        }
    return {
        "image": _tensor_to_base64_image(images[0, 0]),
        "ground_truth": _tensor_to_base64_image(masks[0, 0]),
        "prediction": _tensor_to_base64_image((probs[0, 0] > 0.5).float()),
    }


def _normalise_for_display(slice_2d):
    lo, hi = float(slice_2d.min()), float(slice_2d.max())
    return (slice_2d - lo) / (hi - lo) if hi > lo else slice_2d * 0


def _run_validation(model, val_loader, loss_fn, device, want_preview=False):
    """
    Run one full validation pass, return average loss, dice, iou.

    If want_preview is True, also returns a 'preview' key with the first
    validation sample's (image, ground-truth mask, predicted mask) as
    base64 PNGs — used for the live "watch it improve" panel in the UI.
    This is intentionally NOT included when want_preview is False, so
    existing callers (Stage 3/4/5 scripts) are completely unaffected.
    """
    model.eval()
    total_loss, total_dice, total_iou, n_batches = 0.0, 0.0, 0.0, 0
    preview = None

    with torch.no_grad():
        for images, masks in val_loader:
            images, masks = images.to(device), masks.to(device)
            logits = model(images)
            loss = loss_fn(logits, masks)
            probs = torch.sigmoid(logits)

            if want_preview and preview is None:
                preview = _make_preview(images, masks, probs)

            total_loss += loss.item()
            total_dice += dice_score(probs, masks).item()
            total_iou += iou_score(probs, masks).item()
            n_batches += 1

    if n_batches == 0:
        return {"val_loss": None, "val_dice": None, "val_iou": None, "preview": None}

    return {
        "val_loss": total_loss / n_batches,
        "val_dice": total_dice / n_batches,
        "val_iou": total_iou / n_batches,
        "preview": preview,
    }


def _checkpoint_summary(run_id, filename, path, epoch, config, metrics_history):
    """Small JSON-able description of a checkpoint (stored next to it for fast listing)."""
    last = metrics_history[-1] if metrics_history else {}
    return {
        "run_id": run_id,
        "filename": filename,
        "path": path,
        "epoch": epoch,
        "architecture": config["architecture"],
        "dataset_name": config["dataset_name"],
        "dataset_source": config["dataset_source"],
        "learning_rate": config["learning_rate"],
        "latest_train_loss": last.get("train_loss"),
        "latest_val_dice": last.get("val_dice"),
        "dim": config.get("dim", 2),
        "image_size": config.get("image_size"),
    }


def _sidecar_path(checkpoint_path):
    return os.path.splitext(checkpoint_path)[0] + ".meta.json"


def save_checkpoint(run_id, epoch, model, optimizer, config, metrics_history):
    """Save a checkpoint to checkpoints/<run_id>/epoch_<n>.pt (plus a small .meta.json summary)."""
    run_dir = os.path.join(CHECKPOINTS_ROOT, run_id)
    os.makedirs(run_dir, exist_ok=True)

    checkpoint = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "config": config,
        "metrics_history": metrics_history,
    }
    path = os.path.join(run_dir, f"epoch_{epoch}.pt")
    torch.save(checkpoint, path)
    try:
        summary = _checkpoint_summary(run_id, os.path.basename(path), path, epoch, config, metrics_history)
        with open(_sidecar_path(path), "w", encoding="utf-8") as f:
            json.dump(summary, f)
    except Exception:
        pass  # the sidecar is only a speed-up; list_checkpoints falls back to reading the .pt
    return path


def load_checkpoint(checkpoint_path):
    """
    Load a checkpoint file from disk. Raises FileNotFoundError if missing and
    ValueError if the path is outside the checkpoints folder. Loaded with
    weights_only=True so a tampered file cannot run code while loading.
    """
    checkpoint_path = resolve_inside(checkpoint_path, CHECKPOINTS_ROOT)
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    return torch.load(checkpoint_path, weights_only=True, map_location="cpu")


def _run_epoch_loop(model, optimizer, loss_fn, train_loader, val_loader, device,
                     start_epoch, end_epoch, checkpoint_every, run_id, config,
                     metrics_history, progress_callback=None, stop_event=None,
                     generate_previews=False, early_stopping_enabled=False,
                     early_stopping_patience=5):
    """
    Shared training loop used by both a fresh run (train_model) and a
    resumed run (resume_training). Runs epochs [start_epoch, end_epoch]
    inclusive, appending to metrics_history and saving checkpoints.

    If stop_event (a threading.Event) is provided and gets set, the loop
    stops cleanly before starting the next epoch, and — if the most
    recently completed epoch wasn't already checkpointed — forces a
    checkpoint save so no progress is lost when a student stops a run
    early.

    If generate_previews is True, a live preview (input image / ground
    truth / predicted mask) is included when calling progress_callback —
    but never stored in metrics_history or the saved checkpoint, keeping
    those lightweight.

    If early_stopping_enabled is True, training stops automatically once
    validation loss hasn't improved for `early_stopping_patience`
    consecutive epochs — a standard technique to avoid overfitting and
    wasted computation once a model has stopped genuinely improving. The
    model's weights are restored to whichever epoch actually had the best
    validation loss (not just whatever epoch training happened to stop
    at) before the final checkpoint is saved, matching standard practice
    ("restore best weights").
    """
    checkpoint_paths = []
    last_completed_epoch = None
    last_checkpoint_epoch = None

    best_val_loss = float("inf")
    best_state_dict = None
    best_optimizer_state = None
    best_epoch = None
    epochs_without_improvement = 0
    stopped_early = False

    for epoch in range(start_epoch, end_epoch + 1):
        if stop_event is not None and stop_event.is_set():
            break

        model.train()
        epoch_start = time.time()
        total_train_loss, n_batches = 0.0, 0

        for images, masks in train_loader:
            images, masks = images.to(device), masks.to(device)

            optimizer.zero_grad()
            logits = model(images)
            loss = loss_fn(logits, masks)
            if not math.isfinite(loss.item()):
                raise RuntimeError(
                    "Training diverged: the loss became NaN or infinite. This usually means the "
                    "learning rate is too high. Try a smaller learning rate."
                )
            loss.backward()
            optimizer.step()

            total_train_loss += loss.item()
            n_batches += 1

        avg_train_loss = total_train_loss / max(n_batches, 1)
        val_metrics = _run_validation(model, val_loader, loss_fn, device, want_preview=generate_previews) if val_loader else {
            "val_loss": None, "val_dice": None, "val_iou": None, "preview": None
        }
        preview = val_metrics.pop("preview", None)

        epoch_metrics = {
            "epoch": epoch,
            "train_loss": avg_train_loss,
            "epoch_seconds": time.time() - epoch_start,
            **val_metrics,
        }
        metrics_history.append(epoch_metrics)
        last_completed_epoch = epoch

        # Early stopping bookkeeping — only meaningful if we actually have
        # a validation loss to judge improvement against.
        if early_stopping_enabled and val_metrics.get("val_loss") is not None:
            if val_metrics["val_loss"] < best_val_loss - 1e-6:
                best_val_loss = val_metrics["val_loss"]
                best_state_dict = copy.deepcopy(model.state_dict())
                best_optimizer_state = copy.deepcopy(optimizer.state_dict())
                best_epoch = epoch
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1

        if progress_callback:
            if generate_previews and preview is not None:
                progress_callback({**epoch_metrics, "preview": preview})
            else:
                progress_callback(epoch_metrics)

        is_checkpoint_epoch = (epoch % checkpoint_every == 0) or (epoch == end_epoch)
        if is_checkpoint_epoch:
            path = save_checkpoint(run_id, epoch, model, optimizer, config, metrics_history)
            checkpoint_paths.append(path)
            last_checkpoint_epoch = epoch

        if early_stopping_enabled and epochs_without_improvement >= early_stopping_patience:
            stopped_early = True
            break

    # If early stopping triggered, restore the model to its best epoch's
    # weights before the final save — the whole point of early stopping is
    # to end up with the best-performing snapshot, not just the last one
    # trained before patience ran out.
    if stopped_early and best_state_dict is not None and best_epoch != last_completed_epoch:
        model.load_state_dict(best_state_dict)
        optimizer.load_state_dict(best_optimizer_state)
        path = save_checkpoint(run_id, best_epoch, model, optimizer, config, metrics_history)
        checkpoint_paths.append(path)
        last_checkpoint_epoch = best_epoch
        last_completed_epoch = best_epoch  # report the checkpoint's true epoch, not where the loop happened to exit
    # Otherwise (stop_event triggered, or no early stopping) — if we
    # stopped early and the last completed epoch wasn't already
    # checkpointed, save one now so the student doesn't lose progress.
    elif last_completed_epoch is not None and last_completed_epoch != last_checkpoint_epoch:
        path = save_checkpoint(run_id, last_completed_epoch, model, optimizer, config, metrics_history)
        checkpoint_paths.append(path)

    return metrics_history, checkpoint_paths


def resolve_working_size(dim, image_size=None):
    """
    Working resolution for a run: a square side for 2D images, a cube side for
    3D volumes. None means "use the default". 2D sizes are rounded to a multiple
    of 16 (the deepest models downsample four times); 3D sizes to a multiple of 8.
    """
    if dim == 3:
        return volume_utils.normalize_volume_size(image_size or DEFAULT_VOLUME_SIZE_3D)
    size = int(image_size or DEFAULT_IMAGE_SIZE_2D)
    size = max(MIN_IMAGE_SIZE_2D, min(MAX_IMAGE_SIZE_2D, size))
    return max(MIN_IMAGE_SIZE_2D, int(round(size / 16)) * 16)


def check_model_matches_dataset(model_name, dataset_name, dataset_source):
    """
    A 2D model cannot learn from 3D volumes (or the reverse). Check this up
    front and explain it, instead of failing later with a cryptic tensor-shape
    error. Returns the shared dimensionality (2 or 3).
    """
    model_dim = model_defs.model_dimension(model_name)
    dataset_path = dataset_utils.resolve_dataset_path(dataset_name, dataset_source)
    dataset_utils.validate_dataset_folder(dataset_path)
    data_dim = 3 if dataset_utils.dataset_kind(dataset_path) == "3d" else 2
    if model_dim != data_dim:
        raise ValueError(
            f"'{model_name}' is a {model_dim}D model but dataset '{dataset_name}' contains "
            f"{'3D volumes' if data_dim == 3 else '2D images'}. Pick a {data_dim}D model."
        )
    return data_dim


def train_model(
    dataset_name,
    dataset_source,
    model_name,
    learning_rate=1e-3,
    epochs=10,
    batch_size=8,
    val_split=0.2,
    subset_size=None,
    image_size=None,
    device_preference="auto",
    checkpoint_every=5,
    run_id=None,
    progress_callback=None,
    stop_event=None,
    generate_previews=False,
    early_stopping_enabled=False,
    early_stopping_patience=5,
    seed=None,
):
    """
    Run a full training job from scratch. Returns a dict with run_id,
    final metrics history, checkpoint paths, and the resolved device used.

    Every run is seeded — if `seed` isn't explicitly provided, one is
    generated automatically and used, and the actual value is recorded in
    the returned config (checkpoint["config"]["seed"]) so any run is, in
    principle, reproducible later by re-passing that same seed. This
    covers model weight initialization and (since PyTorch's DataLoader
    shuffling draws from the same global RNG when no separate generator
    is given) training batch order too — nothing about a run's numerical
    behavior is left to whatever the ambient global random state happens
    to be at the moment it starts.

    Hyperparameter sweeps (see tuning.py) explicitly pass the SAME fixed
    seed to every trial instead of letting each trial get its own
    auto-generated one — that's what makes trials within one sweep
    directly comparable, differing only by the parameter actually being
    swept rather than also by independent initialization noise.

    progress_callback, if provided, is called after every epoch with a
    dict of that epoch's metrics — this is the hook Stage 5/6 will use to
    stream live progress to the UI.

    `epochs` is clamped to MAX_EPOCHS server-side — this is a real,
    enforced cap, not just a UI slider limit, so it can't be bypassed by
    calling the API directly.
    """
    requested_epochs = epochs
    epochs = min(epochs, MAX_EPOCHS)

    # Validate foundational parameters. These previously had NO server-side
    # floor check at all (only the upper MAX_EPOCHS cap and the frontend
    # slider's `min` attribute, which is trivially bypassed by calling the
    # API directly) — epochs=0 in particular was confirmed to silently
    # produce a job that reports "completed" with zero metrics and zero
    # checkpoints: a broken, unusable run with no error to explain why.
    # Unlike the upper bound (where clamping down an excessive request is
    # reasonable), there's no sensible way to "helpfully" interpret
    # epochs=0 or a negative batch size — these are rejected outright.
    if epochs < 1:
        raise ValueError(f"epochs must be at least 1 (got {requested_epochs}).")
    if batch_size < 1:
        raise ValueError(f"batch_size must be at least 1 (got {batch_size}).")
    if learning_rate <= 0:
        raise ValueError(f"learning_rate must be greater than 0 (got {learning_rate}).")
    if not (0 < val_split < 1):
        raise ValueError(f"val_split must be between 0 and 1, exclusive (got {val_split}).")
    if subset_size is not None and subset_size < 2:
        raise ValueError(f"subset_size must be at least 2 if provided (got {subset_size}).")

    run_id = run_id or f"{model_name}_{dataset_name}_{time.strftime('%Y-%m-%d_%H-%M-%S')}_{uuid.uuid4().hex[:4]}"

    dim = check_model_matches_dataset(model_name, dataset_name, dataset_source)
    image_size = resolve_working_size(dim, image_size)

    device, device_label = resolve_device(device_preference)

    train_loader, val_loader, total_pairs_used = build_dataloaders(
        dataset_name, dataset_source,
        image_size=image_size, batch_size=batch_size,
        val_split=val_split, subset_size=subset_size,
    )

    # Every run gets an explicit seed — auto-generated here if the caller
    # didn't supply one — rather than leaving weight init and batch
    # shuffling order to whatever the ambient global RNG state happens to
    # be. The actual value used is recorded below so the run is, in
    # principle, reproducible later.
    if seed is None:
        seed = random.randint(0, 2**31 - 1)
    torch.manual_seed(seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)

    model = model_defs.build_model(model_name).to(device)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = BCEDiceLoss()

    config = {
        "architecture": model_name,
        "dataset_name": dataset_name,
        "dataset_source": dataset_source,
        "learning_rate": learning_rate,
        "batch_size": batch_size,
        "val_split": val_split,
        "subset_size": subset_size,
        "image_size": image_size,
        "dim": dim,
        "total_pairs_used": total_pairs_used,
        "early_stopping_enabled": early_stopping_enabled,
        "early_stopping_patience": early_stopping_patience if early_stopping_enabled else None,
        "seed": seed,
    }

    metrics_history, checkpoint_paths = _run_epoch_loop(
        model, optimizer, loss_fn, train_loader, val_loader, device,
        start_epoch=1, end_epoch=epochs, checkpoint_every=checkpoint_every,
        run_id=run_id, config=config, metrics_history=[],
        progress_callback=progress_callback, stop_event=stop_event,
        generate_previews=generate_previews,
        early_stopping_enabled=early_stopping_enabled,
        early_stopping_patience=early_stopping_patience,
    )

    # Release this run's GPU memory back to the caching allocator's free
    # pool now that model/optimizer are genuinely no longer needed. Not
    # strictly required for correctness within a single uniform workload,
    # but this app runs many independent training jobs back-to-back in
    # one long-lived process — most notably hyperparameter sweeps, where
    # each trial can use a different batch size or even architecture.
    # Clearing between runs avoids memory fragmentation across
    # differently-shaped trials, which could otherwise cause a later
    # trial to hit an out-of-memory error even when the GPU has enough
    # total free memory for it.
    del model, optimizer
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    return {
        "run_id": run_id,
        "device_used": device_label,
        "config": config,
        "metrics_history": metrics_history,
        "checkpoint_paths": checkpoint_paths,
        "epochs_were_clamped": requested_epochs > MAX_EPOCHS,
    }


def resume_training(
    checkpoint_path,
    additional_epochs,
    expected_architecture=None,
    expected_dataset_name=None,
    expected_dataset_source=None,
    device_preference="auto",
    checkpoint_every=5,
    progress_callback=None,
    stop_event=None,
    generate_previews=False,
    early_stopping_enabled=None,
    early_stopping_patience=None,
    seed=None,
):
    """
    Resume training from a saved checkpoint for additional_epochs more
    epochs. Restores model weights, optimizer state, and continues
    appending to the same metrics history and the same run's checkpoint
    folder.

    If expected_architecture / expected_dataset_name / expected_dataset_source
    are provided (e.g. from what the student selected in the UI) and they
    don't match what's actually stored in the checkpoint, raises
    CheckpointMismatchError with a clear message rather than silently
    proceeding with mismatched settings.

    The TOTAL epoch count (checkpoint's epoch + additional_epochs) is
    clamped to MAX_EPOCHS server-side, same as a fresh run.

    early_stopping_enabled/patience default to whatever the checkpoint's
    original run used (so resuming preserves the original setting) unless
    explicitly overridden.
    """
    checkpoint = load_checkpoint(checkpoint_path)
    config = checkpoint["config"]

    if expected_architecture is not None and expected_architecture != config["architecture"]:
        raise CheckpointMismatchError(
            f"Architecture mismatch: this checkpoint was trained with "
            f"'{config['architecture']}', but '{expected_architecture}' was selected. "
            f"Select '{config['architecture']}' to resume this checkpoint."
        )
    if expected_dataset_name is not None and expected_dataset_name != config["dataset_name"]:
        raise CheckpointMismatchError(
            f"Dataset mismatch: this checkpoint was trained on "
            f"'{config['dataset_name']}', but '{expected_dataset_name}' was selected. "
            f"Select '{config['dataset_name']}' to resume this checkpoint."
        )
    if expected_dataset_source is not None and expected_dataset_source != config["dataset_source"]:
        raise CheckpointMismatchError(
            f"Dataset source mismatch: this checkpoint used a '{config['dataset_source']}' "
            f"dataset, but source '{expected_dataset_source}' was selected."
        )

    if early_stopping_enabled is None:
        early_stopping_enabled = config.get("early_stopping_enabled", False)
    if early_stopping_patience is None:
        early_stopping_patience = config.get("early_stopping_patience") or 5
    config["early_stopping_enabled"] = early_stopping_enabled
    config["early_stopping_patience"] = early_stopping_patience if early_stopping_enabled else None

    device, device_label = resolve_device(device_preference)

    check_model_matches_dataset(config["architecture"], config["dataset_name"], config["dataset_source"])
    train_loader, val_loader, _ = build_dataloaders(
        config["dataset_name"], config["dataset_source"],
        image_size=config["image_size"], batch_size=config["batch_size"],
        val_split=config["val_split"], subset_size=config["subset_size"],
    )

    model = model_defs.build_model(config["architecture"]).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])

    optimizer = optim.Adam(model.parameters(), lr=config["learning_rate"])
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

    loss_fn = BCEDiceLoss()

    # Weights are loaded from the checkpoint, not freshly initialized, so
    # seeding here doesn't control weight init the way it does in
    # train_model() — but it still controls the batch shuffling order for
    # the epochs about to run, which is otherwise left to whatever the
    # ambient global RNG state happens to be. Recorded as a distinct
    # "resume_seed" (rather than overwriting the original run's "seed")
    # so the original training's seed record stays intact.
    if seed is None:
        seed = random.randint(0, 2**31 - 1)
    torch.manual_seed(seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    config["resume_seed"] = seed

    run_id = os.path.basename(os.path.dirname(checkpoint_path))
    start_epoch = checkpoint["epoch"] + 1
    requested_end_epoch = checkpoint["epoch"] + additional_epochs
    end_epoch = min(requested_end_epoch, MAX_EPOCHS)
    metrics_history = list(checkpoint["metrics_history"])  # copy, don't mutate the loaded checkpoint's list

    metrics_history, checkpoint_paths = _run_epoch_loop(
        model, optimizer, loss_fn, train_loader, val_loader, device,
        start_epoch=start_epoch, end_epoch=end_epoch, checkpoint_every=checkpoint_every,
        run_id=run_id, config=config, metrics_history=metrics_history,
        progress_callback=progress_callback, stop_event=stop_event,
        generate_previews=generate_previews,
        early_stopping_enabled=early_stopping_enabled,
        early_stopping_patience=early_stopping_patience,
    )

    # See the matching comment in train_model() — releases this run's GPU
    # memory now that model/optimizer are genuinely no longer needed.
    del model, optimizer
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    return {
        "run_id": run_id,
        "device_used": device_label,
        "config": config,
        "metrics_history": metrics_history,
        "checkpoint_paths": checkpoint_paths,
        "resumed_from_epoch": checkpoint["epoch"],
        "epochs_were_clamped": requested_end_epoch > MAX_EPOCHS,
    }


def delete_checkpoint(checkpoint_path):
    """
    Delete a single checkpoint file. If it was the last file in its run's
    folder, the now-empty folder is removed too. Validates the path is
    actually inside CHECKPOINTS_ROOT to prevent deleting arbitrary files.
    """
    try:
        checkpoint_path = resolve_inside(checkpoint_path, CHECKPOINTS_ROOT)
    except ValueError:
        raise ValueError("Refusing to delete a path outside the checkpoints folder.")
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    os.remove(checkpoint_path)
    sidecar = _sidecar_path(checkpoint_path)
    if os.path.exists(sidecar):
        os.remove(sidecar)

    run_dir = os.path.dirname(checkpoint_path)
    if os.path.isdir(run_dir) and not os.listdir(run_dir):
        os.rmdir(run_dir)


def list_checkpoints():
    """
    Scan the checkpoints folder and return metadata for every saved
    checkpoint across all runs — used by the Stage 5 API and the Stage 7
    "Resume Training" screen. Uses each checkpoint's small .meta.json
    summary when present (loading a multi-hundred-MB .pt just to list it
    would make this screen crawl); older checkpoints without one are read
    once and get a summary written for next time.
    """
    results = []
    if not os.path.isdir(CHECKPOINTS_ROOT):
        return results

    for run_id in sorted(os.listdir(CHECKPOINTS_ROOT)):
        run_dir = os.path.join(CHECKPOINTS_ROOT, run_id)
        if not os.path.isdir(run_dir):
            continue

        for filename in sorted(os.listdir(run_dir)):
            if not filename.endswith(".pt"):
                continue
            path = os.path.join(run_dir, filename)
            sidecar = _sidecar_path(path)
            try:
                summary = None
                if os.path.exists(sidecar) and os.path.getmtime(sidecar) >= os.path.getmtime(path) - 2:
                    with open(sidecar, encoding="utf-8") as f:
                        summary = json.load(f)
                    summary["path"] = path  # the folder may have moved since it was written
                if summary is None:
                    ckpt = torch.load(path, weights_only=True, map_location="cpu")
                    summary = _checkpoint_summary(run_id, filename, path, ckpt["epoch"], ckpt["config"], ckpt["metrics_history"])
                    try:
                        with open(sidecar, "w", encoding="utf-8") as f:
                            json.dump(summary, f)
                    except OSError:
                        pass
                results.append(summary)
            except Exception:
                continue  # skip unreadable/corrupt checkpoint files

    return results
