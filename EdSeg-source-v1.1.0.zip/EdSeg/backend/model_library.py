"""
Model library for SegLearn — Stage 5.

Lets a student "save" a specific checkpoint as a named final model in
/models/, distinct from the working checkpoints/ folder used during
training. Saved models are what the Stage 10 testing/inference screen
loads. Internally this reuses the exact same checkpoint file format
(model weights + optimizer state + config + metrics history) so no
conversion is needed — saving is just copying a checkpoint file into
/models/ under a student-chosen name.

Each saved model also gets a small <name>.meta.json summary so the library
list loads instantly even when the weights file is large (a full-size U-Net
checkpoint is several hundred MB).
"""

import os
import re
import json
import shutil
import torch

from paths import get_persistent_data_root, resolve_inside

MODELS_ROOT = os.path.join(get_persistent_data_root(), "models")

_SAFE_NAME = re.compile(r"^[A-Za-z0-9_-]+$")


class ModelLibraryError(Exception):
    pass


def _model_path(name):
    """Path of a saved model by name; rejects anything that is not a plain safe name."""
    if not isinstance(name, str) or not _SAFE_NAME.match(name):
        raise ModelLibraryError(f"Saved model '{name}' not found.")
    return os.path.join(MODELS_ROOT, f"{name}.pt")


def _sidecar(path):
    return os.path.splitext(path)[0] + ".meta.json"


def save_model(checkpoint_path, display_name):
    """
    Copy a checkpoint file into /models/<safe_name>.pt so it appears in
    the model library, independent of the training run's checkpoint folder.
    """
    from train import CHECKPOINTS_ROOT
    try:
        checkpoint_path = resolve_inside(checkpoint_path, CHECKPOINTS_ROOT)
    except ValueError as e:
        raise ModelLibraryError(str(e))
    if not os.path.exists(checkpoint_path):
        raise ModelLibraryError(f"Checkpoint not found: {checkpoint_path}")

    safe_name = "".join(c for c in display_name.strip().replace(" ", "_") if c.isalnum() or c in ("-", "_"))
    if not safe_name:
        raise ModelLibraryError("Please provide a name with at least one letter or number.")

    os.makedirs(MODELS_ROOT, exist_ok=True)
    target_path = os.path.join(MODELS_ROOT, f"{safe_name}.pt")

    if os.path.exists(target_path):
        raise ModelLibraryError(
            f"A model named '{safe_name}' already exists. Choose a different name, "
            f"or delete the existing one first if you meant to replace it."
        )

    shutil.copyfile(checkpoint_path, target_path)

    return describe_model(target_path)


def describe_model(path):
    """Read a saved model file's metadata without loading it onto a device."""
    sidecar = _sidecar(path)
    if os.path.exists(sidecar) and os.path.getmtime(sidecar) >= os.path.getmtime(path) - 2:
        try:
            with open(sidecar, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            pass

    ckpt = torch.load(path, weights_only=True, map_location="cpu")
    name = os.path.splitext(os.path.basename(path))[0]
    last_metrics = ckpt["metrics_history"][-1] if ckpt["metrics_history"] else {}
    config = ckpt["config"]

    info = {
        "name": name,
        "path": path,
        "architecture": config["architecture"],
        "dataset_name": config["dataset_name"],
        "dataset_source": config["dataset_source"],
        "trained_epochs": ckpt["epoch"],
        "final_train_loss": last_metrics.get("train_loss"),
        "final_val_dice": last_metrics.get("val_dice"),
        "final_val_iou": last_metrics.get("val_iou"),
        "dim": config.get("dim", 2),
        "image_size": config.get("image_size"),
    }
    try:
        with open(sidecar, "w", encoding="utf-8") as f:
            json.dump(info, f)
    except OSError:
        pass
    return info


def list_saved_models():
    """List all models saved to the library."""
    if not os.path.isdir(MODELS_ROOT):
        return []

    results = []
    for filename in sorted(os.listdir(MODELS_ROOT)):
        if not filename.endswith(".pt"):
            continue
        try:
            results.append(describe_model(os.path.join(MODELS_ROOT, filename)))
        except Exception:
            continue  # skip unreadable files
    return results


def delete_model(name):
    """Remove a saved model (weights + summary) from the library."""
    path = _model_path(name)
    if not os.path.exists(path):
        raise ModelLibraryError(f"Saved model '{name}' not found.")
    os.remove(path)
    if os.path.exists(_sidecar(path)):
        os.remove(_sidecar(path))


def load_model_for_inference(name, device):
    """
    Load a saved model's weights onto the given device, ready for a
    forward pass. Returns (model, config).
    """
    import models as model_defs

    path = _model_path(name)
    if not os.path.exists(path):
        raise ModelLibraryError(f"Saved model '{name}' not found.")

    ckpt = torch.load(path, weights_only=True, map_location="cpu")
    model = model_defs.build_model(ckpt["config"]["architecture"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    return model, ckpt["config"]
