"""
Access control for EdSeg's local web server.

EdSeg runs a small web server on 127.0.0.1 so its window (or browser tab) can
talk to the training engine. Binding to loopback keeps other COMPUTERS out, but
on its own it does not stop:

  * other programs / other users on the same computer calling the API, or
  * a web page open in the student's browser sending requests to 127.0.0.1
    (cross-site request forgery), or
  * "DNS rebinding", where a hostile site's name is pointed at 127.0.0.1.

So every launch generates a random secret. The app window opens
http://127.0.0.1:<port>/?k=<secret> once; the server answers by setting an
HttpOnly, SameSite=Strict cookie and redirecting to a clean URL. From then on
every request must carry that cookie. SameSite=Strict means a browser will not
send it on cross-site requests, and other programs never see the secret.

The Host header must also name loopback, which defeats DNS rebinding. Standard
hardening headers (including a strict Content-Security-Policy) go on every
response. /api/ping stays open so the launcher can tell the server is up; it
returns nothing but "ok".

Enforcement is active whenever a token is configured (the launcher sets
EDSEG_TOKEN; `python backend/app.py` generates one and prints the URL). Unit
tests that call the Flask test client directly run without a token, but the
Host check and security headers always apply.
"""

import hmac
import os
import secrets
from urllib.parse import urlsplit

from flask import jsonify, make_response, redirect, request

COOKIE_NAME = "edseg_session"
ALLOWED_HOSTS = {"127.0.0.1", "localhost", "::1"}

# 'unsafe-inline' for styles only: the UI sets a few style="" attributes. Scripts are same-origin files only.
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; "
    "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
)


def new_token():
    return secrets.token_urlsafe(32)


def _same(a, b):
    return bool(a) and bool(b) and hmac.compare_digest(str(a), str(b))


def install(app, token=None):
    """Register the access checks and security headers on a Flask app."""

    @app.before_request
    def _guard():
        hostname = urlsplit("//" + (request.host or "")).hostname
        if hostname not in ALLOWED_HOSTS:
            return jsonify({"error": "This address is not allowed. EdSeg only answers on 127.0.0.1 / localhost."}), 400
        if not token or request.path == "/api/ping":
            return None
        # First visit from the app window: trade the one-time key in the URL for a session cookie.
        if request.path == "/" and _same(request.args.get("k"), token):
            response = redirect("/")
            response.set_cookie(COOKIE_NAME, token, httponly=True, samesite="Strict", path="/")
            return response
        if _same(request.cookies.get(COOKIE_NAME), token):
            return None
        if request.path.startswith("/api/"):
            return jsonify({"error": "Not authorised. Open EdSeg from its own window or launcher."}), 403
        return make_response("EdSeg: please open this app from its own window or launcher.", 403)

    @app.after_request
    def _headers(response):
        response.headers["Content-Security-Policy"] = CONTENT_SECURITY_POLICY
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store" if request.path.startswith("/api/") else response.headers.get("Cache-Control", "no-cache")
        return response


def configured_token():
    """The token for this process (set by the launcher), or None when access control is off (tests)."""
    return os.environ.get("EDSEG_TOKEN") or None
