"""
3D volume support for EdSeg.

Reading (NIfTI .nii / .nii.gz and NumPy .npy), preprocessing to a fixed cube
size, a small in-memory cache, and helpers that turn a volume into a single
"montage" PNG (all slices tiled in a grid) so the browser can scrub through
slices without hundreds of separate image requests.

Axis convention: every volume is stored as (depth, height, width). NIfTI
files are (x, y, z) on disk, so they are transposed to (z, y, x); .npy
arrays are assumed to already be (depth, height, width). Images and masks go
through the identical transform, so they always stay aligned.
"""

import base64
import io
import math
import os
import threading
from collections import OrderedDict

import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg")
VOLUME_EXTENSIONS = (".nii.gz", ".nii", ".npy")

# Volumes are resized to a cube whose side is a multiple of 8 (the 3D models
# downsample three times).
MIN_VOLUME_SIZE = 16
MAX_VOLUME_SIZE = 128
VOLUME_SIZE_MULTIPLE = 8

# Preprocessed volumes are cached so repeated epochs / sweep trials do not
# re-decompress and re-resize the same .nii.gz over and over.
_CACHE_BYTE_LIMIT = int(os.environ.get("EDSEG_VOLUME_CACHE_MB", "1024")) * 1024 * 1024
_cache = OrderedDict()
_cache_bytes = 0
_cache_lock = threading.Lock()


class VolumeError(Exception):
    """Raised when a volume file cannot be read or is not a usable 3D volume."""
    pass


def split_ext(filename):
    """('scan01.nii.gz') -> ('scan01', '.nii.gz'); extension lower-cased."""
    lower = filename.lower()
    for ext in VOLUME_EXTENSIONS + IMAGE_EXTENSIONS:
        if lower.endswith(ext):
            return filename[: len(filename) - len(ext)], ext
    stem, ext = os.path.splitext(filename)
    return stem, ext.lower()


def is_volume_file(filename):
    return split_ext(filename)[1] in VOLUME_EXTENSIONS


def is_image_file(filename):
    return split_ext(filename)[1] in IMAGE_EXTENSIONS


def normalize_volume_size(size):
    """Clamp to the allowed range and round to a multiple of 8."""
    size = int(size)
    size = max(MIN_VOLUME_SIZE, min(MAX_VOLUME_SIZE, size))
    return max(MIN_VOLUME_SIZE, int(round(size / VOLUME_SIZE_MULTIPLE)) * VOLUME_SIZE_MULTIPLE)


def _npy_to_dhw(arr):
    """Reduce a .npy array to 3 dimensions (drops a singleton channel axis, else uses the first channel)."""
    if arr.ndim == 4:
        if arr.shape[0] == 1:
            return arr[0]
        if arr.shape[-1] == 1:
            return arr[..., 0]
        return arr[0]
    return arr


def volume_shape(path):
    """Cheap shape check (reads only the header for NIfTI) as (depth, height, width)."""
    ext = split_ext(path)[1]
    try:
        if ext == ".npy":
            shape = tuple(_npy_to_dhw(np.load(path, mmap_mode="r", allow_pickle=False)).shape)
        else:
            import nibabel as nib
            raw = tuple(nib.load(path).shape)
            shape = raw[:3][::-1] if len(raw) >= 3 else raw
    except Exception as e:
        raise VolumeError(f"'{os.path.basename(path)}' could not be read as a 3D volume ({e}).")
    if len(shape) != 3:
        raise VolumeError(f"'{os.path.basename(path)}' is {len(shape)}-dimensional; a 3D volume is required.")
    return shape


def read_volume_raw(path):
    """Load a volume as a float32 array shaped (depth, height, width)."""
    ext = split_ext(path)[1]
    try:
        if ext == ".npy":
            arr = _npy_to_dhw(np.asarray(np.load(path, allow_pickle=False), dtype=np.float32))
        else:
            import nibabel as nib
            arr = np.asarray(nib.load(path).dataobj, dtype=np.float32)
            while arr.ndim > 3:
                arr = arr[..., 0]  # multi-channel / 4D: use the first channel or time point
            if arr.ndim == 3:
                arr = np.ascontiguousarray(arr.transpose(2, 1, 0))
    except Exception as e:
        raise VolumeError(f"'{os.path.basename(path)}' could not be read as a 3D volume ({e}).")
    if arr.ndim != 3:
        raise VolumeError(f"'{os.path.basename(path)}' is {arr.ndim}-dimensional; a 3D volume is required.")
    if not np.isfinite(arr).all():
        arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    return arr


def _resize(tensor_5d, size, mode):
    if mode == "nearest":
        return F.interpolate(tensor_5d, size=(size, size, size), mode="nearest")
    return F.interpolate(tensor_5d, size=(size, size, size), mode="trilinear", align_corners=False)


def preprocess_image_volume(arr, size):
    """Robust intensity normalisation (clip outliers, z-score) + resize -> (1, S, S, S)."""
    lo, hi = np.percentile(arr, [0.5, 99.5])
    if hi > lo:
        arr = np.clip(arr, lo, hi)
    std = float(arr.std())
    arr = (arr - float(arr.mean())) / (std if std > 1e-6 else 1.0)
    t = torch.from_numpy(np.ascontiguousarray(arr, dtype=np.float32))[None, None]
    return _resize(t, size, "trilinear")[0]


def preprocess_mask_volume(arr, size):
    """Foreground = any positive label. Resized as a soft mask then re-thresholded so thin structures survive."""
    t = torch.from_numpy((arr > 0).astype(np.float32))[None, None]
    return (_resize(t, size, "trilinear")[0] >= 0.5).float()


def _cache_key(path, size, is_mask):
    st = os.stat(path)
    return (os.path.abspath(path), st.st_mtime_ns, st.st_size, int(size), bool(is_mask))


def load_volume(path, size, is_mask=False, use_cache=True):
    """Cached load + preprocess. Returns a (1, S, S, S) float tensor (do not modify in place)."""
    global _cache_bytes
    if not use_cache:
        arr = read_volume_raw(path)
        return preprocess_mask_volume(arr, size) if is_mask else preprocess_image_volume(arr, size)
    key = _cache_key(path, size, is_mask)
    with _cache_lock:
        if key in _cache:
            _cache.move_to_end(key)
            return _cache[key]
    arr = read_volume_raw(path)
    tensor = preprocess_mask_volume(arr, size) if is_mask else preprocess_image_volume(arr, size)
    nbytes = tensor.numel() * tensor.element_size()
    with _cache_lock:
        if key not in _cache:
            _cache[key] = tensor
            _cache_bytes += nbytes
            while _cache_bytes > _CACHE_BYTE_LIMIT and len(_cache) > 1:
                _, old = _cache.popitem(last=False)
                _cache_bytes -= old.numel() * old.element_size()
    return tensor


def clear_cache():
    global _cache_bytes
    with _cache_lock:
        _cache.clear()
        _cache_bytes = 0


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def best_slice_index(mask_dhw):
    """Axial slice with the most foreground (or the middle slice if the mask is empty)."""
    counts = mask_dhw.reshape(mask_dhw.shape[0], -1).sum(axis=1)
    if counts.max() > 0:
        return int(np.argmax(counts))
    return int(mask_dhw.shape[0] // 2)


def to_display_uint8(arr, binary=False):
    """Scale an array to 0-255 for display."""
    arr = np.asarray(arr, dtype=np.float32)
    if binary:
        return (arr > 0.5).astype(np.uint8) * 255
    lo, hi = np.percentile(arr, [1.0, 99.5])
    if hi <= lo:
        lo, hi = float(arr.min()), float(arr.max())
    if hi <= lo:
        return np.zeros(arr.shape, dtype=np.uint8)
    return (np.clip((arr - lo) / (hi - lo), 0, 1) * 255).astype(np.uint8)


def _png_data_url(img):
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("utf-8")


def slice_to_data_url(slice_hw_uint8, thumb=None):
    """One axial slice -> PNG data URL (flipped so anatomy displays upright)."""
    img = Image.fromarray(np.ascontiguousarray(slice_hw_uint8[::-1]), mode="L")
    if thumb:
        img.thumbnail((thumb, thumb))
    return _png_data_url(img)


def volume_to_montage(vol_dhw_uint8):
    """
    Tile every axial slice of a (D, H, W) uint8 volume into one PNG.
    Returns (data_url, cols, rows).
    """
    depth, height, width = vol_dhw_uint8.shape
    cols = int(math.ceil(math.sqrt(depth)))
    rows = int(math.ceil(depth / cols))
    sheet = np.zeros((rows * height, cols * width), dtype=np.uint8)
    for i in range(depth):
        r, c = divmod(i, cols)
        sheet[r * height:(r + 1) * height, c * width:(c + 1) * width] = vol_dhw_uint8[i][::-1]
    return _png_data_url(Image.fromarray(sheet, mode="L")), cols, rows


def build_volume_sample(image_dhw, gt_dhw, pred_dhw, filename=None):
    """
    Everything the browser's slice viewer needs for one volume: three montage
    PNGs (image / ground truth / prediction) plus tiling info.
    image_dhw is a float array; gt/pred are 0/1 arrays. All shaped (D, H, W).
    """
    image_url, cols, rows = volume_to_montage(to_display_uint8(image_dhw))
    gt_url, _, _ = volume_to_montage(to_display_uint8(gt_dhw, binary=True))
    pred_url, _, _ = volume_to_montage(to_display_uint8(pred_dhw, binary=True))
    depth, height, width = image_dhw.shape
    return {
        "kind": "volume",
        "filename": filename,
        "depth": int(depth),
        "tile_width": int(width),
        "tile_height": int(height),
        "cols": cols,
        "rows": rows,
        "default_slice": best_slice_index(gt_dhw if np.asarray(gt_dhw).sum() > 0 else pred_dhw),
        "image": image_url,
        "ground_truth": gt_url,
        "prediction": pred_url,
    }
