# Building EdSeg as a Desktop App (Windows & Mac)

This produces the actual double-click desktop app. PyInstaller **cannot
cross-compile**: build on Windows for the Windows app and on a Mac for the Mac app.

## Two builds — and how big they are

| Build | What it adds | Download (zip) | On disk | Who it is for |
|---|---|---|---|---|
| **CPU-only** | Runs on any computer. Uses the processor. | see note¹ | see note¹ | Students, shared downloads, laptops |
| **CUDA + CPU** | Adds NVIDIA GPU training. Also runs on CPU. | ≈ 2.8 GB² | ≈ 5.6 GB² | A computer with an NVIDIA GPU |

¹ The CPU-only build's real measured size is printed at the end of
`build_tools/finalize_build.py`, written into the app's `build_info.json`,
and shown in the app (right-hand **System info** panel → *About this build*).
² Estimate: the CUDA PyTorch wheel alone is 2.6 GB (the CPU wheel is 0.12 GB), and
it expands further when unpacked. It is replaced by a measured value the first
time a CUDA build is made.

The CUDA build is bigger only because it bundles NVIDIA's GPU libraries
(cuDNN, cuBLAS, …). The app *code* is identical. If most of your users have no
NVIDIA GPU, distribute the CPU-only build and keep the CUDA build for yourself.

## App icon

`icon.ico` (Windows) and `icon.icns` (Mac) are already wired into `launcher.spec`.

## Onedir, not onefile

The build is a **folder**:
```
dist/EdSeg/
├── EdSeg.exe          (small launcher)
├── _internal/         (Python, PyTorch, the web UI, sample datasets)
└── build_info.json    (written by finalize_build.py)
```
Students double-click `EdSeg.exe`; the whole folder must stay together (zip it
to share). Onefile mode would re-extract everything on every launch.

## Step by step (Windows)

Use a fresh virtual environment per build flavour so the wrong PyTorch can
never end up in the wrong build:

```
python -m venv build_cpu_venv
build_cpu_venv\Scripts\activate
pip install Flask Pillow "numpy<2.3" nibabel pywebview pyinstaller
pip install torch --index-url https://download.pytorch.org/whl/cpu
```

For the CUDA build use a *separate* venv (`build_cuda_venv`) and
`pip install torch --index-url https://download.pytorch.org/whl/cu126`
(check `nvidia-smi`; the index must be supported by your driver).

Then, from the project root:

```
pyinstaller launcher.spec --noconfirm --clean
python build_tools/finalize_build.py --dist dist/EdSeg --flavor cpu --out release --scratch scratch
```
(`--flavor cuda` for the CUDA build.) `finalize_build.py`:
1. removes C++ headers and CMake files PyTorch ships but the app never loads;
2. runs the packaged app headless (`EdSeg.exe --selftest`) — it builds and runs
   all 13 models, trains 2D and 3D models for a couple of epochs, and
   exercises the API; **the build fails if any of that fails**;
3. measures the real folder and zip sizes and records them in `build_info.json`;
4. writes the final zip.

Everything is written under the folders you pass, so you control which drive
is used (pip and PyInstaller also honour `PIP_CACHE_DIR`, `TEMP` and
`PYINSTALLER_CONFIG_DIR` if you want their caches off the system drive).

> Windows will show a "Windows protected your PC" SmartScreen warning the first
> time (the app isn't code-signed). Choose **More info → Run anyway**.

## Building on Mac

Same steps with `source build_cpu_venv/bin/activate`. On Apple Silicon the
standard PyTorch wheel includes GPU (MPS) support, so there is no separate CUDA
build. Then sign ad hoc and zip:

```
codesign --force --deep --sign - dist/EdSeg.app
ditto -c -k --sequesterRsrc --keepParent dist/EdSeg.app EdSeg.zip
```
If a recipient gets "EdSeg.app is damaged", have them run `xattr -cr /path/to/EdSeg.app`.
First launch: right-click → Open.

## Testing checklist (after building, on each platform)

Run `EdSeg.exe --selftest report.json` (automatic in `finalize_build.py`), then
by hand on a machine without Python:

- [ ] Double-clicking opens a window within a few seconds (no console)
- [ ] Dataset screen lists *Sample Shapes* (2D) and *Sample Blobs 3D*
- [ ] Training a 2D and a 3D model completes and the charts update
- [ ] Results screen shows numbers; the 3D slice viewer scrubs
- [ ] A `checkpoints/` folder appears **next to the app**, not inside `_internal`
- [ ] Resume, Save model, Test on a new file, Compare runs all work
- [ ] Closing and reopening keeps saved models and checkpoints
- [ ] *About this build* shows the right flavour and sizes
- [ ] Keyboard only: Tab reaches everything, focus is always visible, Esc closes dialogs

## Why checkpoints/models/reports sit next to the app

`_internal` is part of the app and is replaced on update. Student data
(`checkpoints/`, `models/`, `reports/`, `sweeps/`, `datasets/custom/`) is written
next to `EdSeg.exe` (see `backend/paths.py`) so it survives updates. Set the
`EDSEG_DATA_DIR` environment variable to put it somewhere else (the automated
tests do this).

## Rebuilding

Delete `build/` and `dist/` first (or pass `--clean`).
