"""
Convert downloaded public datasets into EdSeg's folder layout.

    <out>/<name>/images/<case>.<ext>
    <out>/<name>/masks/<case>.<ext>

and also write <out>/<name>.zip, which is exactly what the app's
"Upload your own dataset" box accepts.

Supported inputs (put the raw downloads in --raw):
  kvasir-seg.zip          Kvasir-SEG polyp segmentation (2D endoscopy images)
  Task04_Hippocampus.tar  Medical Segmentation Decathlon: hippocampus MRI (3D)
  Task09_Spleen.tar       Medical Segmentation Decathlon: spleen CT (3D)

Licences (check before redistributing): Kvasir-SEG is free for research and
educational use (Simula); the Decathlon datasets are CC-BY-SA 4.0.

Archives are never extracted wholesale: members are read by name and written
to fixed output paths, so a malicious archive cannot write elsewhere.

Usage:
    python tools/prepare_datasets.py --raw D:/Edseg/test_datasets/raw --out D:/Edseg/test_datasets
"""

import argparse
import os
import re
import shutil
import tarfile
import zipfile


def _zip_dataset(folder, zip_path):
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as zf:  # volumes are already gzip-compressed
        for sub in ("images", "masks"):
            for name in sorted(os.listdir(os.path.join(folder, sub))):
                zf.write(os.path.join(folder, sub, name), f"{sub}/{name}")


def prepare_kvasir(raw_zip, out_root):
    out = os.path.join(out_root, "kvasir_seg")
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "images"))
    os.makedirs(os.path.join(out, "masks"))
    n = 0
    with zipfile.ZipFile(raw_zip) as zf:
        for info in zf.infolist():
            parts = info.filename.replace("\\", "/").split("/")
            if info.is_dir() or len(parts) < 2 or parts[-2] not in ("images", "masks"):
                continue
            leaf = os.path.basename(parts[-1])
            if not re.match(r"^[A-Za-z0-9_.-]+\.(jpg|jpeg|png)$", leaf, re.I):
                continue
            with zf.open(info) as src, open(os.path.join(out, parts[-2], leaf), "wb") as dst:
                shutil.copyfileobj(src, dst)
            n += parts[-2] == "images"
    _zip_dataset(out, out + ".zip")
    return out, n


def prepare_msd(raw_tar, out_root, name, max_cases=None):
    out = os.path.join(out_root, name)
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "images"))
    os.makedirs(os.path.join(out, "masks"))
    wanted = {}
    with tarfile.open(raw_tar) as tf:
        for member in tf.getmembers():
            base = os.path.basename(member.name)
            if not member.isfile() or base.startswith("._") or not base.endswith(".nii.gz"):
                continue
            folder = os.path.basename(os.path.dirname(member.name))
            if folder in ("imagesTr", "labelsTr"):
                wanted[(folder, base)] = member
        cases = sorted(b for (f, b) in wanted if f == "imagesTr" and ("labelsTr", b) in wanted)
        if max_cases:
            cases = cases[:max_cases]
        for base in cases:
            for folder, dest in (("imagesTr", "images"), ("labelsTr", "masks")):
                with tf.extractfile(wanted[(folder, base)]) as src, open(os.path.join(out, dest, base), "wb") as dst:
                    shutil.copyfileobj(src, dst)
    _zip_dataset(out, out + ".zip")
    return out, len(cases)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--spleen-cases", type=int, default=12, help="how many spleen CT volumes to keep (they are large)")
    args = ap.parse_args()

    jobs = [
        ("kvasir-seg.zip", lambda p: prepare_kvasir(p, args.out)),
        ("Task04_Hippocampus.tar", lambda p: prepare_msd(p, args.out, "hippocampus_3d")),
        ("Task09_Spleen.tar", lambda p: prepare_msd(p, args.out, "spleen_ct_3d", args.spleen_cases)),
    ]
    for filename, fn in jobs:
        path = os.path.join(args.raw, filename)
        if not os.path.exists(path):
            print(f"skip {filename}: not downloaded")
            continue
        try:
            folder, n = fn(path)
            print(f"{filename}: {n} cases -> {folder}")
        except (tarfile.TarError, zipfile.BadZipFile, EOFError) as e:
            print(f"skip {filename}: archive is incomplete or corrupt ({e})")


if __name__ == "__main__":
    main()
