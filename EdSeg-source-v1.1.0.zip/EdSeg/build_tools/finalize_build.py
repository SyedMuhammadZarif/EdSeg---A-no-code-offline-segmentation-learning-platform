"""
Finish a PyInstaller build of EdSeg:

  1. prune files the app never loads at run time (C++ headers, CMake files)
  2. run the packaged EdSeg.exe headless (--selftest) and require it to pass
  3. measure the real folder size and a real zip size
  4. write build_info.json next to EdSeg.exe (the app's "About this build"
     card reads it, so students see the true size of the build they have)
  5. produce the final distributable zip

    python build_tools/finalize_build.py --dist D:/build/dist/EdSeg --flavor cpu --out D:/release --scratch D:/scratch

Everything is written under --out / --scratch, so nothing lands on a drive
you did not choose.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile

# Sizes (MB) of the build we did NOT make here, shown as estimates in the app.
# CUDA figures: the torch 2.14.1+cu126 Windows wheel is 2.6 GB to download and
# unpacks to roughly twice that.
ESTIMATES_MB = {"cuda_folder": 5600, "cuda_zip": 2800}

PRUNE_DIRS = [
    os.path.join("torch", "include"),
    os.path.join("torch", "share"),
    os.path.join("torch", "bin"),          # build tools (protoc, torch_shm_manager is kept below)
]
KEEP_FILES = {os.path.join("torch", "bin", "torch_shm_manager.exe")}


def folder_size_mb(path):
    total = 0
    for root, _, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total / (1024 * 1024)


def prune(internal_dir):
    removed = 0.0
    for rel in PRUNE_DIRS:
        target = os.path.join(internal_dir, rel)
        if not os.path.isdir(target):
            continue
        keep = [os.path.join(internal_dir, k) for k in KEEP_FILES]
        for root, _, files in os.walk(target, topdown=False):
            for name in files:
                full = os.path.join(root, name)
                if full in keep:
                    continue
                removed += os.path.getsize(full) / (1024 * 1024)
                os.remove(full)
            try:
                os.rmdir(root)
            except OSError:
                pass
    return removed


def make_zip(src_folder, zip_path):
    if os.path.exists(zip_path):
        os.remove(zip_path)
    base = os.path.dirname(src_folder)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, _, files in os.walk(src_folder):
            for name in files:
                full = os.path.join(root, name)
                zf.write(full, os.path.relpath(full, base))
    return os.path.getsize(zip_path) / (1024 * 1024)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dist", required=True, help="PyInstaller output folder containing EdSeg.exe")
    ap.add_argument("--flavor", required=True, choices=["cpu", "cuda"])
    ap.add_argument("--out", required=True, help="folder for the final zip")
    ap.add_argument("--scratch", required=True, help="scratch folder for the self-test's data")
    ap.add_argument("--version", default="1.1.0")
    args = ap.parse_args()

    dist = os.path.abspath(args.dist)
    exe = os.path.join(dist, "EdSeg.exe")
    assert os.path.exists(exe), f"{exe} not found"
    internal = os.path.join(dist, "_internal")
    os.makedirs(args.out, exist_ok=True)
    os.makedirs(args.scratch, exist_ok=True)

    # Licence + third-party notices must travel with the binary (MIT/BSD/Apache require it).
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for name in ("LICENSE", "THIRD_PARTY_NOTICES.txt"):
        source = os.path.join(project_root, name)
        if os.path.exists(source):
            shutil.copyfile(source, os.path.join(dist, name))
        else:
            sys.exit(f"{name} is missing from the project - refusing to build a release without it")

    before = folder_size_mb(dist)
    freed = prune(internal)
    print(f"pruned {freed:.0f} MB of unused build files ({before:.0f} -> {folder_size_mb(dist):.0f} MB)")

    # Headless self-test of the packaged exe
    report = os.path.join(args.scratch, f"selftest_{args.flavor}.json")
    if os.path.exists(report):
        os.remove(report)
    env = dict(os.environ, EDSEG_DATA_DIR=os.path.join(args.scratch, "selftest_data"), TEMP=args.scratch, TMP=args.scratch)
    started = time.time()
    proc = subprocess.run([exe, "--selftest", report], env=env, timeout=1800)
    print(f"self-test exit code {proc.returncode} in {time.time() - started:.0f}s")
    if not os.path.exists(report):
        sys.exit("self-test produced no report - the packaged app failed to start")
    result = json.load(open(report, encoding="utf-8"))
    for step in result["steps"]:
        print(("  PASS " if step["ok"] else "  FAIL ") + step["name"] + ("" if step["ok"] else " -> " + step.get("error", "")))
    if not result["ok"]:
        sys.exit("self-test FAILED")

    # Clean anything the self-test may have left next to the exe, then measure
    for leftover in ("checkpoints", "models", "reports", "sweeps"):
        path = os.path.join(dist, leftover)
        if os.path.isdir(path) and not os.listdir(path):
            os.rmdir(path)

    folder_mb = folder_size_mb(dist)
    zip_name = f"EdSeg-{'CPU-only' if args.flavor == 'cpu' else 'CUDA'}-Windows.zip"
    zip_path = os.path.join(args.out, zip_name)

    sizes = {f"{args.flavor}_folder": round(folder_mb), f"{args.flavor}_zip": None}
    estimated = []
    for key, value in ESTIMATES_MB.items():
        if not key.startswith(args.flavor):
            sizes[key] = value
            estimated.append(key)

    def write_info():
        info = {"app_version": args.version, "flavor": args.flavor, "built_on": time.strftime("%Y-%m-%d"),
                "sizes_mb": sizes, "sizes_estimated": estimated}
        with open(os.path.join(dist, "build_info.json"), "w", encoding="utf-8") as f:
            json.dump(info, f, indent=2)

    write_info()
    first = make_zip(dist, zip_path)       # first pass measures the zip...
    sizes[f"{args.flavor}_zip"] = round(first)
    write_info()
    final = make_zip(dist, zip_path)       # ...second pass includes the recorded number
    sizes[f"{args.flavor}_zip"] = round(final)
    write_info()                            # (differs from `final` by a few KB at most)

    print(f"\nBuild folder: {folder_mb:.0f} MB   Zip: {final:.0f} MB   -> {zip_path}")
    print(json.dumps({"sizes_mb": sizes, "estimated": estimated}))


if __name__ == "__main__":
    main()
