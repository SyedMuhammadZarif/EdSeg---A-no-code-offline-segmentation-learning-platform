"""
Build THIRD_PARTY_NOTICES.txt: the licence notices that must travel with EdSeg's binary
(MIT / BSD / Apache-2.0 all require the copyright notice and licence text to be reproduced).

It reads the licence files that every installed package ships in its own metadata, so the
output always matches the exact versions that went into a build.

    python build_tools/collect_licenses.py --lock requirements-lock.txt --out THIRD_PARTY_NOTICES.txt
"""

import argparse
import importlib.metadata as md
import re

HEADER = """EdSeg – third-party software notices
====================================

EdSeg itself is released under the MIT licence (see LICENSE). It includes and depends on the
open-source components listed below, each under its own licence. Their notices and licence texts
follow, as required by those licences.

Not bundled, but used at run time:
  * Microsoft Edge WebView2 Runtime – provided by Windows / Microsoft Edge; licensed by Microsoft.
    EdSeg ships only the small Microsoft.Web.WebView2 .NET wrapper libraries (redistributable under
    Microsoft's WebView2 SDK licence), via pywebview.

Build tool (its output is not covered by its licence):
  * PyInstaller – GPL-2.0-or-later WITH a special exception that permits distributing programs it
    builds under any licence. (Full text is included below.)

Interface icons: the small line icons in the user interface follow the Feather / Lucide icon sets
and are used under their licences, reproduced here.

----------------------------------------------------------------------------
Feather Icons – MIT License
Copyright (c) 2013-2017 Cole Bemis

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

----------------------------------------------------------------------------
Lucide – ISC License
Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT).
All other copyright (c) for Lucide are held by Lucide Contributors 2022.

Permission to use, copy, modify, and/or distribute this software for any purpose with or without
fee is hereby granted, provided that the above copyright notice and this permission notice appear
in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE
AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.

"""

LICENSE_FILE = re.compile(r"(^|/)(LICEN[CS]E|COPYING|NOTICE|AUTHORS)[^/]*$", re.I)


def licence_summary(meta):
    expr = meta.get("License-Expression")
    if expr:
        return expr
    classifiers = [c.split("::")[-1].strip() for c in (meta.get_all("Classifier") or []) if c.startswith("License")]
    if classifiers:
        return ", ".join(classifiers)
    text = (meta.get("License") or "").strip().split("\n")[0]
    return text[:80] if text else "see licence text below / not declared in metadata"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lock", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    names = []
    for line in open(args.lock, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#"):
            names.append(re.split(r"[=<>~! ]", line, maxsplit=1)[0])

    rows, bodies = [], []
    for name in sorted(set(names), key=str.lower):
        try:
            dist = md.distribution(name)
        except md.PackageNotFoundError:
            continue
        meta = dist.metadata
        rows.append(f"  {meta['Name']} {dist.version} – {licence_summary(meta)}")
        texts = []
        for f in dist.files or []:
            if LICENSE_FILE.search(str(f).replace("\\", "/")):
                try:
                    texts.append((str(f), dist.locate_file(f).read_bytes().decode("utf-8", errors="replace")))
                except OSError:
                    pass
        home = meta.get("Home-page") or next((u.split(",")[-1].strip() for u in (meta.get_all("Project-URL") or []) if "ome" in u or "ource" in u), "")
        body = [f"\n{'-' * 76}\n{meta['Name']} {dist.version}" + (f"  ({home})" if home else ""), f"Licence: {licence_summary(meta)}"]
        if texts:
            for fname, text in texts:
                body.append(f"\n[{fname}]\n{text.strip()}")
        else:
            body.append("(No licence file is distributed inside this package; see the project's website for its licence.)")
        bodies.append("\n".join(body))

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(HEADER)
        f.write("Components and their declared licences\n--------------------------------------\n")
        f.write("\n".join(rows) + "\n\n")
        f.write("Licence texts\n=============\n")
        f.write("\n".join(bodies) + "\n")
    print(f"wrote {args.out}: {len(rows)} components")


if __name__ == "__main__":
    main()
