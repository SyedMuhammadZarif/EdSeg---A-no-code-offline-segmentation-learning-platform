"""
Verification script for issues raised about hyperparameter sweep hygiene:
  1. Every trial in a sweep uses a fixed seed, so trials differ ONLY by
     the swept parameter(s), not by uncontrolled random weight
     initialization noise on top of that.
  2. A normal (non-sweep) standalone training run is NOT seeded by
     default — natural run-to-run variability is preserved there.
  3. GPU cleanup (torch.cuda.empty_cache() + gc.collect()) runs at the
     end of every training run without error (can't verify actual CUDA
     memory release on a CPU-only machine, but confirms the code path
     is correct and doesn't crash on any device).

Run with:
    python backend/scripts/test_sweep_reproducibility.py
"""

import sys
import os
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from train import train_model, CHECKPOINTS_ROOT
from tuning import run_sweep


def cleanup():
    if os.path.isdir(CHECKPOINTS_ROOT):
        for entry in os.listdir(CHECKPOINTS_ROOT):
            shutil.rmtree(os.path.join(CHECKPOINTS_ROOT, entry), ignore_errors=True)


def main():
    cleanup()
    checks_passed = True

    base_kwargs = dict(
        dataset_name="sample_shapes", dataset_source="bundled", model_name="mini_unet",
        learning_rate=1e-3, epochs=3, batch_size=4, subset_size=16, device_preference="cpu",
    )

    # --- Check 1: same seed -> bit-identical results ---
    result_a = train_model(**base_kwargs, run_id="repro_test_a", seed=42)
    result_b = train_model(**base_kwargs, run_id="repro_test_b", seed=42)
    losses_a = [round(m["train_loss"], 8) for m in result_a["metrics_history"]]
    losses_b = [round(m["train_loss"], 8) for m in result_b["metrics_history"]]
    same_seed_identical = losses_a == losses_b
    print(f"[Check 1] Same seed produces bit-identical results -> {'PASS' if same_seed_identical else 'FAIL'}")
    checks_passed &= same_seed_identical
    cleanup()

    # --- Check 2: different seed -> different results ---
    result_c = train_model(**base_kwargs, run_id="repro_test_c", seed=999)
    losses_c = [round(m["train_loss"], 8) for m in result_c["metrics_history"]]
    different_seed_differs = losses_a != losses_c
    print(f"[Check 2] Different seed produces different results -> {'PASS' if different_seed_differs else 'FAIL'}")
    checks_passed &= different_seed_differs
    cleanup()

    # --- Check 3: unseeded (normal standalone run) still varies naturally ---
    result_d = train_model(**base_kwargs, run_id="repro_test_d")
    result_e = train_model(**base_kwargs, run_id="repro_test_e")
    losses_d = [round(m["train_loss"], 8) for m in result_d["metrics_history"]]
    losses_e = [round(m["train_loss"], 8) for m in result_e["metrics_history"]]
    unseeded_varies = losses_d != losses_e
    print(f"[Check 3] Unseeded standalone runs still vary naturally (no regression) -> "
          f"{'PASS' if unseeded_varies else 'FAIL'}")
    checks_passed &= unseeded_varies
    cleanup()

    # --- Check 4: a real sweep run through tuning.py completes without error
    #     and every trial completes (confirms the seed + cleanup wiring is
    #     integrated correctly at the actual sweep level, not just in
    #     direct train_model() calls) ---
    print("\nRunning a real 2-trial sweep through tuning.py...")
    summary = run_sweep(
        base_config={
            "dataset_name": "sample_shapes", "dataset_source": "bundled", "model_name": "mini_unet",
            "epochs": 3, "batch_size": 4, "subset_size": 16, "device_preference": "cpu",
        },
        sweep_params=[{"param": "learning_rate", "values": [0.001, 0.005]}],
    )
    sweep_completed_cleanly = (
        len(summary["trials"]) == 2 and
        all(t["checkpoint_path"] is not None for t in summary["trials"])
    )
    print(f"[Check 4] Real sweep completes cleanly with fixed seeding + GPU cleanup wired in -> "
          f"{'PASS' if sweep_completed_cleanly else 'FAIL'}")
    checks_passed &= sweep_completed_cleanly
    cleanup()

    print("\n" + "=" * 50)
    print("ALL CHECKS PASSED" if checks_passed else "SOME CHECKS FAILED — see above")


if __name__ == "__main__":
    main()
